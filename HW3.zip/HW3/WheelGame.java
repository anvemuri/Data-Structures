import java.io.*;
import java.util.*; 

public class WheelGame
{
	private int[] wheelArray;
	private int currentIndex;
	private int currentValue;
	private int numPlayers;
	private int maxSpins;
	private CircularLList2<Player> playerList;
	
	public WheelGame(Scanner infile, int numPlyrs)
	{
		numPlayers = numPlyrs;
		maxSpins = numPlayers*10;
		readWheelFromFile(infile);
		createCircularList();
	}
	
	public void spinWheel()
	{
		currentIndex = (int)(Math.random()* wheelArray.length); // 0 to size - 1 inclusive
		currentValue = wheelArray[currentIndex];
	}
	
	public int getCurrentValue()
	{
		return currentValue;
	}
	public int getNumPlayers()
	{
		return numPlayers;
	}
	public void playGame()
	{
		int spinCounter = 0;
		playerList.startIterator();
		while (numPlayers != 1 && spinCounter < maxSpins)
		{
			spinCounter++;
			Player prev = playerList.peekPrev();
			Player curr = playerList.next();
			System.out.print("\nSpinning Wheel for ID # " + curr.getId());
			spinWheel();
			System.out.println("...... and it's " + currentValue + "!");
			
			if (currentValue < 0)
			{
				System.out.println("Reducing the previous Player's total by this amount");
				// add the negative amount to total of the Player who is BEFORE you (previous Player already saved) (effectively subtracting)
				prev.setTotal(prev.getTotal() + currentValue);	
				System.out.println("The previous player with ID# " + prev.getId() + " now has a total of " + prev.getTotal());
				
				curr.setCurrentValue(currentValue);

				if (prev.getTotal() < 0)
				{
					System.out.println("!!!!! Removing player with ID# " + prev.getId() + "!!!!!");
					playerList.remove(prev);
					numPlayers--;
				}
				
			}
			
			else if (currentValue > 0)
			{
				System.out.println("Adding the wheel's current value to this Player");
				// add that amount to the current Player's total
				curr.setTotal(currentValue + curr.getTotal());				
				System.out.println("This player now has " + curr.getTotal());
				
				curr.setCurrentValue(currentValue);
			}
			
			else // if (currentValue == 0)
			{
				System.out.println("Subtracting the last of this Player's value from the Player's total");
				// subtract the current Player's currentValue from his total
				curr.setTotal(curr.getTotal()-curr.getCurrentValue());				
				System.out.println("Now the total is " + curr.getTotal());
				
				curr.setCurrentValue(currentValue);
				
				if (curr.getTotal() < 0)
				{
					System.out.println("!!!!! Removing player with ID# " + curr.getId() + "!!!!!");
					playerList.remove(curr);
					numPlayers--;
				}
			}	
		}
		
		if (numPlayers==1)//playerList.getLength()==1)
		{
			System.out.println("\nWinner: " + playerList.getEntry(1) + "\n");
		}
		else
		{
			System.out.println("\nTimed out, no winner.\n");
		}
	}
	private void readWheelFromFile(Scanner infile)
	{
		/* first read the first number in the file 
		store it in the arraySize member variable, allocate memory
		for an array of the size you just read, then read into the array until you
		reach the end of the array or the end of file (whichever comes first) */
		if (infile != null)
		{
			int arraySize;
			arraySize = infile.nextInt();
			wheelArray = new int[arraySize];
			
			for (int i = 0; i < arraySize && infile.hasNext(); i++)
			{
				wheelArray[i] = infile.nextInt();
			}
		}
	}
	private void createCircularList()
	{
		/* in a loop, add numPlayers
		Players to the END of the list one at a time, where each has an ID# of the
		loop counter (starting with 1), each total is initialized to 500 and the
		currentValue is initialized to 0. */
		playerList = new CircularLList2<>();
		for (int i = 1; i <= numPlayers; i++)
		{
			playerList.add(new Player (i, 500, 0));
		}
	}
}