
import java.util.*; 
import java.io.*;

public class Driver
{
	public static Scanner userScanner = new Scanner(System.in);
	
	public static void main(String[] args)
	{
		Scanner fileScanner = openInputFile();
		if (fileScanner == null)
			return;
		WheelGame wheel = new WheelGame(fileScanner, 5);
		wheel.playGame();
		testCircularList();
	}
	
	public static Scanner openInputFile()
	{
		String filename;
        	Scanner scanner=null;
        
		System.out.print("Enter the input filename: ");
		filename = userScanner.nextLine();
        	File file= new File(filename);

        	try{
        		scanner = new Scanner(file);
        	}// end try
        	catch(FileNotFoundException fe){
        	   System.out.println("Can't open input file\n");
       	    return null; // array of 0 elements
        	} // end catch
        	return scanner;
	}

	// TEST CircularLList2: CALL FROM MAIN (at the end of main):
	public static void testCircularList()
	{
		String strArray[] = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
		CircularLList2<String> list;
		String tempStr1;

		list = new CircularLList2<String>();
		for (int i = 0; i < strArray.length ; ++i)
		{
			list.add(i+1, strArray[i]);
		}
		System.out.println( "\nThe test list has:" );
		list.display();
		tempStr1 = list.getEntry("Tuesday");
		if (tempStr1 != null)
			System.out.println( "Found " + tempStr1 + " in the list!");
		else
			System.out.println( "Error in the program: Tuesday wasn't found");
		if (list.remove("Monday"))
			System.out.println( "Monday was successfully removed from the list!");
		else
			System.out.println( "Error in the program: Monday couldn't be removed");
		if (list.remove("Sunday"))
			System.out.println(  "Sunday was successfully removed from the list!");
		else
			System.out.println( "Error in the program: Sunday couldn't be removed");
		if (list.remove("Thursday"))
			System.out.println( "Thursday was successfully removed from the list!");
		else
			System.out.println(  "Error in the program: Thursday couldn't be removed");
		System.out.println( "\nNow the test list has:");
		list.display();
		tempStr1 = list.getEntry("Mardi");
		if (tempStr1 != null)
			System.out.println( "Found " + tempStr1 + " in the list????");
		else
			System.out.println( "Good: Mardi wasn't found");

	}
}
/*

Microsoft Windows [Version 10.0.14393]
(c) 2016 Microsoft Corporation. All rights reserved.

C:\Users\soso1>cd C:\Users\soso1\Desktop\Classes\cis 22c\HW3 Code File, Input Files, Test Runs

C:\Users\soso1\Desktop\Classes\cis 22c\HW3 Code File, Input Files, Test Runs>javac Driver.java

C:\Users\soso1\Desktop\Classes\cis 22c\HW3 Code File, Input Files, Test Runs>java Driver
Enter the input filename: HW3TestInput1.txt

Spinning Wheel for ID # 1...... and it's 450!
Adding the wheel's current value to this Player
This player now has 950

Spinning Wheel for ID # 2...... and it's 250!
Adding the wheel's current value to this Player
This player now has 750

Spinning Wheel for ID # 3...... and it's 550!
Adding the wheel's current value to this Player
This player now has 1050

Spinning Wheel for ID # 4...... and it's 0!
Subtracting the last of this Player's value from the Player's total
Now the total is 500

Spinning Wheel for ID # 5...... and it's 300!
Adding the wheel's current value to this Player
This player now has 800

Spinning Wheel for ID # 1...... and it's 550!
Adding the wheel's current value to this Player
This player now has 1500

Spinning Wheel for ID # 2...... and it's 0!
Subtracting the last of this Player's value from the Player's total
Now the total is 500

Spinning Wheel for ID # 3...... and it's 400!
Adding the wheel's current value to this Player
This player now has 1450

Spinning Wheel for ID # 4...... and it's -650!
Reducing the previous Player's total by this amount
The previous player with ID# 3 now has a total of 800

Spinning Wheel for ID # 5...... and it's -600!
Reducing the previous Player's total by this amount
The previous player with ID# 4 now has a total of -100
!!!!! Removing player with ID# 4!!!!!

Spinning Wheel for ID # 1...... and it's 900!
Adding the wheel's current value to this Player
This player now has 2400

Spinning Wheel for ID # 2...... and it's 350!
Adding the wheel's current value to this Player
This player now has 850

Spinning Wheel for ID # 3...... and it's 350!
Adding the wheel's current value to this Player
This player now has 1150

Spinning Wheel for ID # 5...... and it's 150!
Adding the wheel's current value to this Player
This player now has 950

Spinning Wheel for ID # 1...... and it's 200!
Adding the wheel's current value to this Player
This player now has 2600

Spinning Wheel for ID # 2...... and it's 0!
Subtracting the last of this Player's value from the Player's total
Now the total is 500

Spinning Wheel for ID # 3...... and it's 0!
Subtracting the last of this Player's value from the Player's total
Now the total is 800

Spinning Wheel for ID # 5...... and it's 300!
Adding the wheel's current value to this Player
This player now has 1250

Spinning Wheel for ID # 1...... and it's 300!
Adding the wheel's current value to this Player
This player now has 2900

Spinning Wheel for ID # 2...... and it's -600!
Reducing the previous Player's total by this amount
The previous player with ID# 1 now has a total of 2300

Spinning Wheel for ID # 3...... and it's -650!
Reducing the previous Player's total by this amount
The previous player with ID# 2 now has a total of -150
!!!!! Removing player with ID# 2!!!!!

Spinning Wheel for ID # 5...... and it's 450!
Adding the wheel's current value to this Player
This player now has 1700

Spinning Wheel for ID # 1...... and it's 800!
Adding the wheel's current value to this Player
This player now has 3100

Spinning Wheel for ID # 3...... and it's 550!
Adding the wheel's current value to this Player
This player now has 1350

Spinning Wheel for ID # 5...... and it's 800!
Adding the wheel's current value to this Player
This player now has 2500

Spinning Wheel for ID # 1...... and it's 300!
Adding the wheel's current value to this Player
This player now has 3400

Spinning Wheel for ID # 3...... and it's 700!
Adding the wheel's current value to this Player
This player now has 2050

Spinning Wheel for ID # 5...... and it's 850!
Adding the wheel's current value to this Player
This player now has 3350

Spinning Wheel for ID # 1...... and it's 950!
Adding the wheel's current value to this Player
This player now has 4350

Spinning Wheel for ID # 3...... and it's 100!
Adding the wheel's current value to this Player
This player now has 2150

Spinning Wheel for ID # 5...... and it's -500!
Reducing the previous Player's total by this amount
The previous player with ID# 3 now has a total of 1650

Spinning Wheel for ID # 1...... and it's 400!
Adding the wheel's current value to this Player
This player now has 4750

Spinning Wheel for ID # 3...... and it's 950!
Adding the wheel's current value to this Player
This player now has 2600

Spinning Wheel for ID # 5...... and it's 400!
Adding the wheel's current value to this Player
This player now has 3750

Spinning Wheel for ID # 1...... and it's 750!
Adding the wheel's current value to this Player
This player now has 5500

Spinning Wheel for ID # 3...... and it's 150!
Adding the wheel's current value to this Player
This player now has 2750

Spinning Wheel for ID # 5...... and it's 900!
Adding the wheel's current value to this Player
This player now has 4650

Spinning Wheel for ID # 1...... and it's 750!
Adding the wheel's current value to this Player
This player now has 6250

Spinning Wheel for ID # 3...... and it's 50!
Adding the wheel's current value to this Player
This player now has 2800

Spinning Wheel for ID # 5...... and it's 400!
Adding the wheel's current value to this Player
This player now has 5050

Spinning Wheel for ID # 1...... and it's 900!
Adding the wheel's current value to this Player
This player now has 7150

Spinning Wheel for ID # 3...... and it's 100!
Adding the wheel's current value to this Player
This player now has 2900

Spinning Wheel for ID # 5...... and it's -500!
Reducing the previous Player's total by this amount
The previous player with ID# 3 now has a total of 2400

Spinning Wheel for ID # 1...... and it's 850!
Adding the wheel's current value to this Player
This player now has 8000

Spinning Wheel for ID # 3...... and it's -600!
Reducing the previous Player's total by this amount
The previous player with ID# 1 now has a total of 7400

Spinning Wheel for ID # 5...... and it's 800!
Adding the wheel's current value to this Player
This player now has 5850

Spinning Wheel for ID # 1...... and it's 950!
Adding the wheel's current value to this Player
This player now has 8350

Spinning Wheel for ID # 3...... and it's 150!
Adding the wheel's current value to this Player
This player now has 2550

Spinning Wheel for ID # 5...... and it's 200!
Adding the wheel's current value to this Player
This player now has 6050

Spinning Wheel for ID # 1...... and it's 950!
Adding the wheel's current value to this Player
This player now has 9300

Timed out, no winner.


The test list has:
Monday
Tuesday
Wednesday
Thursday
Friday
Saturday
Sunday
Found Tuesday in the list!
Monday was successfully removed from the list!
Sunday was successfully removed from the list!
Thursday was successfully removed from the list!

Now the test list has:
Tuesday
Wednesday
Friday
Saturday
Good: Mardi wasn't found

C:\Users\soso1\Desktop\Classes\cis 22c\HW3 Code File, Input Files, Test Runs>java Driver-------------------------
Enter the input filename: HW3TestInput2.txt

Spinning Wheel for ID # 1...... and it's 340!
Adding the wheel's current value to this Player
This player now has 840

Spinning Wheel for ID # 2...... and it's 800!
Adding the wheel's current value to this Player
This player now has 1300

Spinning Wheel for ID # 3...... and it's 1600!
Adding the wheel's current value to this Player
This player now has 2100

Spinning Wheel for ID # 4...... and it's 340!
Adding the wheel's current value to this Player
This player now has 840

Spinning Wheel for ID # 5...... and it's 1800!
Adding the wheel's current value to this Player
This player now has 2300

Spinning Wheel for ID # 1...... and it's 400!
Adding the wheel's current value to this Player
This player now has 1240

Spinning Wheel for ID # 2...... and it's 460!
Adding the wheel's current value to this Player
This player now has 1760

Spinning Wheel for ID # 3...... and it's -3000!
Reducing the previous Player's total by this amount
The previous player with ID# 2 now has a total of -1240
!!!!! Removing player with ID# 2!!!!!

Spinning Wheel for ID # 4...... and it's 0!
Subtracting the last of this Player's value from the Player's total
Now the total is 500

Spinning Wheel for ID # 5...... and it's 0!
Subtracting the last of this Player's value from the Player's total
Now the total is 500

Spinning Wheel for ID # 1...... and it's 400!
Adding the wheel's current value to this Player
This player now has 1640

Spinning Wheel for ID # 3...... and it's -1200!
Reducing the previous Player's total by this amount
The previous player with ID# 1 now has a total of 440

Spinning Wheel for ID # 4...... and it's 240!
Adding the wheel's current value to this Player
This player now has 740

Spinning Wheel for ID # 5...... and it's -4800!
Reducing the previous Player's total by this amount
The previous player with ID# 4 now has a total of -4060
!!!!! Removing player with ID# 4!!!!!

Spinning Wheel for ID # 1...... and it's -3000!
Reducing the previous Player's total by this amount
The previous player with ID# 5 now has a total of -2500
!!!!! Removing player with ID# 5!!!!!

Spinning Wheel for ID # 3...... and it's 3200!
Adding the wheel's current value to this Player
This player now has 5300

Spinning Wheel for ID # 1...... and it's 260!
Adding the wheel's current value to this Player
This player now has 700

Spinning Wheel for ID # 3...... and it's 1600!
Adding the wheel's current value to this Player
This player now has 6900

Spinning Wheel for ID # 1...... and it's 420!
Adding the wheel's current value to this Player
This player now has 1120

Spinning Wheel for ID # 3...... and it's 540!
Adding the wheel's current value to this Player
This player now has 7440

Spinning Wheel for ID # 1...... and it's 380!
Adding the wheel's current value to this Player
This player now has 1500

Spinning Wheel for ID # 3...... and it's -5200!
Reducing the previous Player's total by this amount
The previous player with ID# 1 now has a total of -3700
!!!!! Removing player with ID# 1!!!!!

Winner: Player: ID# 3, Total = 7440, Current value = -5200


The test list has:
Monday
Tuesday
Wednesday
Thursday
Friday
Saturday
Sunday
Found Tuesday in the list!
Monday was successfully removed from the list!
Sunday was successfully removed from the list!
Thursday was successfully removed from the list!

Now the test list has:
Tuesday
Wednesday
Friday
Saturday
Good: Mardi wasn't found

*/