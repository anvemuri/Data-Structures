
public class MyIterator {

}
