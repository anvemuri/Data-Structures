package hw4;

//MonthVisitor class visits each date in the BST.
public class MonthVisitor implements Visitor<Date> {

	/**
	* visit method prints out the date parameter by calling the original toString method
	*/
	@Override
	public void visit(Date mDate) {
		System.out.println(mDate.toString());	
	}

}