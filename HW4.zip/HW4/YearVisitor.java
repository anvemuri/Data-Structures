package hw4;

//YearVisitor visits the date class.
public class YearVisitor implements Visitor<Date> {

	/**
	* Visit method prints out the date parameter in this format: yyyy-mm-dd
	*/
	@Override	
	public void visit(Date yDate) {	
		System.out.println(yDate.getYear() + "-" + yDate.getMonth() + "-" + yDate.getDay());
	}

}