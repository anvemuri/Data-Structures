package hw4;

// YearComparator compares the dates
import java.util.Comparator;

public class YearComparator implements Comparator<Date> {
	/**
	* compare two date classes by calling date class's compareTo
	*/
	
	public int compare(Date left, Date right) {
		return left.compareTo(right);
	}

}