package hw4;

import java.util.Comparator;

public class MonthComparator implements Comparator<Date> {

/**
* compares two date parameters, first through month, then day, then year.
*/

	public int compare(Date left, Date right) {
		int difference = left.getMonth() - right.getMonth();
	
		if (difference == 0) {	
			difference = left.getDay() - right.getDay();	
		}
		
		if (difference == 0) {	
			difference = left.getYear() - right.getYear();	
		}
		
		return difference;	
	}
}