import java.util.Comparator;

class ColorCodeComparator implements Comparator<Color>
{
	
	/** 
	 * Compares the codes of the Colors by taking their difference.
     * @param colorOne  holds one Color.
     * @param  colorTwo  holds the other Color.
     * @return an integer that is the difference of the two Color codes.
     */
	@Override
	public int compare(Color colorOne, Color colorTwo) {
		
		int diff;//diff->holds the difference of the Color codes, to be returned.
	
		diff = colorOne.getCode() - colorTwo.getCode();
		
		return diff;
	}
	
}