class ColorNameHasher1 implements Hasher<Color>
{
	/** 
	 * Hashes the Color by its name with the built in String hasher.
     * @param  elem  holds one Color.
     * @return an integer that is the hash value of the name of the Color parameter.
     */
	@Override
	public int hash(Color elem) {
		
		String theName = elem.getName();//theName->holds the name of Color parameter
		
		int theHashVal;//theHashVal->holds the hash value of the name.
		theHashVal = theName.hashCode();
		
		return theHashVal;
	}
	
}