import java.util.Comparator;

class ColorNameComparator implements Comparator<Color>
{
	
	/** 
	 * Compares the names of the Colors.
     * @param  nameOne  holds one Color.
     * @param  nameTwo  holds the other Color.
     * @return an integer that determines which string(name of a Color) is greater.
     */
	@Override
	public int compare(Color nameOne, Color nameTwo) {
		
		String firstName = nameOne.getName();//firstName->holds the name of the first Color.
		String secondName = nameTwo.getName();//secondName->holds the name of the second Color.

		return 	firstName.compareToIgnoreCase(secondName);
	}
}