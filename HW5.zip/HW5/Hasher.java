public interface Hasher<E> {
    public int hash(E elem);
}
