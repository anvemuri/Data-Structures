import java.io.File;  
import java.io.FileNotFoundException;
import java.util.*;

public class Driver {

	public static void main(String[] args) {

		HashTable<Color> myColorOne = null;//myColorOne->holds an instance of the HashQP.
		HashTable<Color> myColorTwo = null;//myColorTwo->holds an instance of one HasHSC.
		HashTable<Color> myColorThree = null;//myColorThree->holds an instance of the other HashSC.
	
		myColorOne = new HashQP<>(new ColorCodeHasher(), new ColorCodeComparator());
		myColorTwo = new HashSC<>( new ColorNameHasher1 (), new ColorNameComparator());
		myColorThree = new HashSC<>(new ColorNameHasher2(), new ColorNameComparator());
		
		//filling colors with data on input file
		fileCheck(myColorOne, myColorTwo, myColorThree);
		
		//displaying first part.
		System.out.printf("HashQP with the int key has: \n");
		displayingColor(myColorOne);
		
		System.out.printf("\n\nHashSC #1 with the String key has: \n");
		displayingColor(myColorTwo);
		
		System.out.printf("\nHashSC #2 with the String key has: \n");
		displayingColor(myColorThree);
		
		//using testHashTables.
		System.out.printf("\n");
		testHashTables(myColorOne, myColorTwo);
		
		//using displayTable.
		System.out.printf("\nHashQP with the int key now has:\n");
		myColorOne.displayTable();
		
		System.out.printf("\nHashSC #1 with the String key now has:\n");
		myColorTwo.displayTable();
		
		System.out.println("\nHashSC #2 with the String key now has:");
		myColorThree.displayTable();
		
	}

		// Include the following methods in the main class:		
		// Remember to import the correct package for Scanner and Files
		public static Scanner userScanner = new Scanner(System.in);

	    // opens a text file for input, returns a Scanner:
	    public static Scanner openInputFile()
	    {
	        String filename;
	            Scanner scanner=null;
	        
	        System.out.print("Enter the input filename: ");
	        filename = userScanner.nextLine();
	            File file= new File(filename);

	            try{
	                scanner = new Scanner(file);
	            }// end try
	            catch(FileNotFoundException fe){
	               System.out.println("Can't open input file\n");
	                   return null; // array of 0 elements
	            } // end catch
	            return scanner;
	    }
	    
	    /** 
	     * Tests the HashQP and one HashSC table by checking if there is a certain Color in them.
		 * @param tablsQP holds the HashQP table to be further tested.
		 * @param tableSC holds a HashSC table to be further tested.
		 * @param tempColor holds a Color object passed to parameter.
	     * @return the copy of the Color parameter that we are using to check if parameter Color is inside both tables.
	     */
	    public static Color testContains(HashTable<Color> tableQP, HashTable<Color> tableSC, Color tempColor)
	    {
	        // YOU FINISH SO IT CREATES A COPY OF tempColor (new Color,
	        //    NOT assigning the same reference, but another Color with
	        //    the same code and name), then call contains for tableQP
	        //    passing the copy Color and display the return value as
	        //    shown in the test run.  
	        // Now call contains for tableSC (pass the same copy Color) and
	        //    display the return value as shown in the test run.
	        // Return the copy Color
		
	    	int tempCode = tempColor.getCode();//tempCode-> holds the code of the Color parameter.
	    	String tempName = tempColor.getName();//tempName-> holds the name of the Color parameter.
	    	Color copyOfTemp = new Color(tempCode, tempName);//copyOfTemp-> copy of the Color parameter.
	    	
	    
			boolean containedQP = tableQP.contains(copyOfTemp);//containedQP->holds true if Color parameter is in the HashQP table parameter.
			                                                   //We are using a copy of Color parameter to make that determination.
				
			System.out.println("Result of calling contains for " + copyOfTemp.getName() + " in HashQP = " + containedQP);
			
			boolean containedSC = tableSC.contains(copyOfTemp);//containedSC->holds true if Color parameter is in the HashSC table parameter.
            												 
			System.out.println("Result of calling contains for " + copyOfTemp.getName() + " in HashSC = " + containedSC);
			
			
			return copyOfTemp;
	    }

	    // Call the following in main for both HashTables (in one call):
	    public static void testHashTables(HashTable<Color> tableQP,
	            HashTable<Color> tableSC)
	    {
	        Color tempColorQP, tempColorSC;
	        Color targetColor1=null, targetColor2=null;


	        Iterator<Color> iter = tableQP.iterator(); // get Color from HashQP
	        if( iter.hasNext()  ){
	            tempColorQP = iter.next();
	            targetColor1 = testContains(tableQP, tableSC, tempColorQP);// YOU WRITE
	        }

	        iter = tableSC.iterator(); // get Color from HashSC
	        if( iter.hasNext()  ){
	            tempColorSC = iter.next();
	            targetColor2 = testContains(tableQP, tableSC, tempColorSC);// YOU WRITE
	        }
	        // found a Color in table1 in table2, now test getEntry and remove methods

	        tempColorQP = tableQP.getEntry(targetColor1);
	        if( tempColorQP != null )
	        {
	            System.out.println("Retrieved in HashQP, Color: " + tempColorQP.getName() + ", now trying to delete it");
	            // now delete it 
	            if( tableQP.remove(targetColor1))
	                System.out.println("Successfully removed from HashQP: " + targetColor1.getName());
	            else
	                System.out.println("Unsuccessful attempt to remove from HashQP: " + targetColor1.getName());
	        }else
	            System.out.println("Error in HashQP: can't retrieve "+ targetColor1.getName());

	        tempColorSC = tableSC.getEntry(targetColor2);
	        if( tempColorSC != null )
	        {
	            System.out.println("Retrieved in HashSC, Color: " + tempColorSC.getName() + ", now trying to delete it");
	            // now delete it 
	            if( tableSC.remove(targetColor2))
	                System.out.println("Successfully removed from HashSC: " + targetColor2.getName());
	            else
	                System.out.println("Unsuccessful attempt to remove from HashSC: " + targetColor2.getName());
	        }
	        else
	            System.out.println("Error in HashSC: can't retrieve "+ targetColor2.getName());

	    } // testHashTables
	    
	    /** 
	     * Fills all three Hash Tables with Color data from input file.
		 * @param theColorOne    holds the HashQP object.
		 * @param theColorTwo	 holds the first HashSC object.
		 * @param theColorThree  holds the second HashSC object. 
	     * @return True if all Colors from input file are inserted to the HashTables. 
	     */
	    public static boolean fillHashTable(HashTable<Color> theColorOne, HashTable<Color> theColorTwo, HashTable<Color> theColorThree)
	    {
	    	Scanner theFile = openInputFile();//theFile->holds the Scanned and openedFile.
	    	int num;//num->holds the hex number that a Color has.
	    	String line;//line->holds the name and all other information of a Color. 
	    	
	    	if(theFile == null)
	    	{
	    		return false;
	    	}
	    	else
	    	{
	    		while(theFile.hasNext())
	    		{
	    			num = theFile.nextInt(16); 
	    			line = theFile.nextLine();
	    			line = line.trim();
	    			
	    			Color theColor = new Color(num, line);//holds a Color object with a specific hex number and name.
	    		
	    			theColorOne.insert(theColor);
	    			theColorTwo.insert(theColor);
	    			theColorThree.insert(theColor);
	    		}
	    		
	    	}
	    	
	    	theFile.close();
	    	return true;
	    }
	    
	    /** 
	     * Checks that file was opened correctly. Calls the method to fill in the tables if file was opened. Ends program if file was not opened correctly
		 * @param  myColorOne  holds the HashQP object.
		 * @param  myColorTwo  holds the first HashSC object.
		 * @param  myColorThree  holds the second HashSC object. 
	     */
	    public static void fileCheck(HashTable<Color> myColorOne, HashTable<Color> myColorTwo, HashTable<Color> myColorThree)
	    {
	    	boolean testingFile = fillHashTable(myColorOne, myColorTwo, myColorThree);//testingFile->holds true if Colors were inserted correctly to all tables.
	    	
	    	if( !(testingFile))
	    	{
	    		System.out.print("ending program");
	    		System.exit(0);
	    	}
	    }
	    
	    /** 
		 * Displays the Colors of the Hash Table parameter.
	     * @param  colorsTable holds the Colors HashTable passed to parameter.
	     */
	    public static void displayingColor(HashTable<Color> colorsTable)
	    {
	    	Iterator<Color> myItr = colorsTable.iterator();//myItr->holds HashTable parameter's iterator.
	    	Color nextColor;//nextColot->holds the next Color found by iterator.
	        
	    	while(myItr.hasNext())
	    	{
	    		nextColor = myItr.next();
	    		
	    		if(nextColor != null)
	    		{
	    			System.out.println(nextColor.toString());
	    		}
	    		
	    	}
	    
	    	colorsTable.displayStatistics();
	    }
}

/* Output:
 
	Enter the input filename: HW5 Test Input1.txt
	HashQP with the int key has: 
	Color: Magenta = FF00FF
	Color: Black = 000000
	Color: Brown = A52A2A
	Color: Light Blue = ADD8E6
	Color: Olive = 808000
	Color: Yellow = FFFF00
	Color: Red = FF0000
	Color: Silver = C0C0C0
	Color: Maroon = 800000
	Color: Cyan = 00FFFF
	Color: Blue = 0000FF
	Color: Gray = 808080
	Color: Dark Blue = 0000A0
	Color: Purple = 800080
	Color: Orange = FFA500
	Color: Green = 008000
	Color: White = FFFFFF
	Color: Lime = 00FF00
	
	In the HashQP class:
	
	Table Size = 97
	Number of entries = 18
	Load factor = 0.18556701030927836
	Number of collisions = 5
	Longest Collision Run = 2
	
	
	HashSC #1 with the String key has: 
	Color: Brown = A52A2A
	Color: Cyan = 00FFFF
	Color: Black = 000000
	Color: Maroon = 800000
	Color: Olive = 808000
	Color: Green = 008000
	Color: Light Blue = ADD8E6
	Color: Gray = 808080
	Color: Purple = 800080
	Color: Lime = 00FF00
	Color: Magenta = FF00FF
	Color: Dark Blue = 0000A0
	Color: Blue = 0000FF
	Color: Orange = FFA500
	Color: Red = FF0000
	Color: Silver = C0C0C0
	Color: White = FFFFFF
	Color: Yellow = FFFF00
	
	In the HashSC class:
	
	Table Size = 97
	Number of entries = 18
	Load factor = 0.18556701030927836
	Number of collisions = 2
	Longest Linked List = 2
	
	HashSC #2 with the String key has: 
	Color: Green = 008000
	Color: Gray = 808080
	Color: White = FFFFFF
	Color: Purple = 800080
	Color: Magenta = FF00FF
	Color: Black = 000000
	Color: Yellow = FFFF00
	Color: Lime = 00FF00
	Color: Olive = 808000
	Color: Dark Blue = 0000A0
	Color: Silver = C0C0C0
	Color: Light Blue = ADD8E6
	Color: Brown = A52A2A
	Color: Blue = 0000FF
	Color: Red = FF0000
	Color: Orange = FFA500
	Color: Maroon = 800000
	Color: Cyan = 00FFFF
	
	In the HashSC class:
	
	Table Size = 97
	Number of entries = 18
	Load factor = 0.18556701030927836
	Number of collisions = 0
	Longest Linked List = 1
	
	Result of calling contains for Magenta in HashQP = true
	Result of calling contains for Magenta in HashSC = true
	Result of calling contains for Brown in HashQP = true
	Result of calling contains for Brown in HashSC = true
	Retrieved in HashQP, Color: Magenta, now trying to delete it
	Successfully removed from HashQP: Magenta
	Retrieved in HashSC, Color: Brown, now trying to delete it
	Successfully removed from HashSC: Brown
	
	HashQP with the int key now has:
	1 Color: Black = 000000
	4 Color: Brown = A52A2A
	22 Color: Light Blue = ADD8E6
	30 Color: Olive = 808000
	34 Color: Yellow = FFFF00
	35 Color: Red = FF0000
	43 Color: Silver = C0C0C0
	48 Color: Maroon = 800000
	60 Color: Cyan = 00FFFF
	61 Color: Blue = 0000FF
	62 Color: Gray = 808080
	63 Color: Dark Blue = 0000A0
	79 Color: Purple = 800080
	80 Color: Orange = FFA500
	83 Color: Green = 008000
	95 Color: White = FFFFFF
	96 Color: Lime = 00FF00
	
	HashSC #1 with the String key now has:
	19  Color: Cyan = 00FFFF 
	21  Color: Black = 000000 
	31  Color: Maroon = 800000 
	33  Color: Olive = 808000 
	42  Color: Green = 008000 
	44  Color: Light Blue = ADD8E6 ---> Color: Gray = 808080 
	52  Color: Purple = 800080 ---> Color: Lime = 00FF00 
	53  Color: Magenta = FF00FF 
	54  Color: Dark Blue = 0000A0 
	56  Color: Blue = 0000FF 
	61  Color: Orange = FFA500 
	68  Color: Red = FF0000 
	75  Color: Silver = C0C0C0 
	86  Color: White = FFFFFF 
	90  Color: Yellow = FFFF00 
	
	HashSC #2 with the String key now has:
	1  Color: Green = 008000 
	8  Color: Gray = 808080 
	9  Color: White = FFFFFF 
	22  Color: Purple = 800080 
	23  Color: Magenta = FF00FF 
	34  Color: Black = 000000 
	35  Color: Yellow = FFFF00 
	40  Color: Lime = 00FF00 
	64  Color: Olive = 808000 
	66  Color: Dark Blue = 0000A0 
	67  Color: Silver = C0C0C0 
	74  Color: Light Blue = ADD8E6 
	75  Color: Brown = A52A2A 
	82  Color: Blue = 0000FF 
	83  Color: Red = FF0000 
	84  Color: Orange = FFA500 
	91  Color: Maroon = 800000 
	95  Color: Cyan = 00FFFF 


-----------------------------------------------------------------------------


	Enter the input filename: HW5 Test Input2.txt
	HashQP with the int key has: 
	Color: Pink Lace = FFDDF4
	Color: Pale Gold = FDDE6C
	Color: Toupe = C7AC7D
	Color: Violet Tulle = C693C7
	Color: Pale Chestnut = DDADAF
	Color: Rusty Red = AF2F0D
	Color: Rose White = FFF6F5
	Color: Sand Brown = CBA560
	Color: Sunflower = FFC512
	Color: Sunshine Yellow = FFFD37
	Color: Purple/pink = D725DE
	Color: Vibrant Purple = AD03DE
	Color: Orangey Yellow = FDB915
	Color: Pictorial Carmine = C30B4E
	Color: Purple Blue = 632DE9
	Color: Pale Green-yellow = F1E788
	Color: Sickly Green = 94B21C
	Color: Pale Green = C7FDB5
	Color: New York Pink = D7837F
	Color: Red Pink = FA2A55
	Color: True Green = 089404
	Color: Purple Pizzazz = FE4EDA
	Color: Steel Grey = 6F828A
	Color: Vegas Gold = C5B358
	Color: Vivid Tangerine = FF9980
	Color: Pale Light Green = B1FC99
	Color: Vomit Green = 89A203
	Color: Taupe Brown = 674C47
	Color: Silver Chalice = ACACAC
	Color: Vivid Violet = 9F00FF
	Color: Vermillion = F4320C
	Color: Soft Purple = A66FB5
	Color: Palatinate Blue = 273BE2
	Color: Orchid Ice = DFD2DF
	Color: Turkish Rose = B57281
	Color: School Bus Yellow = FFD800
	Color: Warm Brown = 964E02
	Color: Wine Red = 7B0323
	Color: Olive Drab = 6F7632
	Color: Orange Brown = BE6400
	Color: Seafoam Blue = 78D1B6
	Color: Pearl Violet = 8683A1
	Color: Shiraz = B20931
	Color: Very Light Brown = D3B683
	Color: Water = 96ABA5
	Color: Simply Taupe = ABA092
	Color: Vivid Green = 2FEF10
	Color: Wintergreen Dream = 56887D
	Color: Ruby = E0115F
	Color: Shamrock Green = 02C14D
	Color: Pale Grey = FDFDFE
	Color: Red Violet = 9E0168
	Color: Ua Red = D9004C
	Color: Urobilin = E1AD21
	Color: Seal Brown = 321414
	Color: Pinkish Grey = C8ACA9
	Color: Purple Reign = 54446C
	Color: Orange Tan = FAA76C
	Color: Pistachio = 93C572
	Color: Royal Azure = 0038A8
	Color: Robin's Egg Blue = 98EFF9
	Color: Powder Pink = FFB2D0
	Color: Purply Blue = 661AEE
	Color: Pale Goldenrod = EEE8AA
	Color: Victoria Plum = 002C39
	Color: Peach-yellow = FADFAD
	Color: Pea Soup Green = 94A617
	Color: Primary Blue = 0804F9
	Color: Neon Blue = 04D9FF
	Color: Thulian Pink = DE6FA1
	Color: Outrageous Orange = FF6E4A
	Color: Rich Orange = FF681F
	Color: Ucla Gold = FFB300
	Color: Pink Light = FFE4E9
	Color: Navajo White = FFDEAD
	Color: Silver Sand = BFC1C2
	Color: Old Silver = 848482
	Color: Pale Blush = F4BBCF
	Color: Rich Tyrian Purple = 9E0E40
	Color: Red Devil = 860111
	Color: Purpley Pink = C83CB9
	Color: Pale Lilac = E4CBFF
	Color: Ruddy Brown = BB6528
	Color: Tyrian Purple = 66023C
	Color: "Tangerine Yellow, Usc Gold" = FFCC00
	Color: Pullman Brown = 644117
	Color: Yellow (ryb) = FEFE33
	Color: Pale Lavender = EECFFE
	Color: Off Green = 6BA353
	Color: Prussian Blue = 004577
	Color: Violet Purple = 926EAE
	Color: Pale Violet Red = DB7093
	Color: Windsor Tan = AE6838
	Color: Orchid = DA70D6
	Color: Purple Brown = 673A3F
	Color: Seance = 731E8F
	Color: Studio = 714AB2
	Color: Violet Red = A50055
	Color: Neon Purple = BC13FE
	Color: Platinum = E5E4E2
	Color: Sonic Silver = 757575
	Color: Peach Bisque = A87C6D
	Color: Pink Sherbet = F78FA7
	Color: Night Shadz = AA375A
	Color: Orange Yellow = FFAD01
	Color: Sunglow = FFCC33
	Color: Pigment Blue = 333399
	Color: Persian Orange = D99058
	Color: Shadow Lime = D4E29B
	Color: Zinnwaldite Brown = 2C1608
	Color: Tangerine = FF9408
	Color: Olive Brown = 645403
	Color: Tuscan Red = 7C4848
	Color: Ruddy Pink = E18E96
	Color: Vintage Indigo = 664D64
	Color: Robin's Egg = 6DEDFD
	Color: Selago = F0EEFD
	Color: Salmon Pink = FE7B7C
	Color: Wintergreen = 20F986
	Color: Phthalo Green = 123524
	Color: Purple Orchid = AE4F93
	Color: Pale Persian Lilac = D597AE
	Color: Pastel Violet = A47D90
	Color: Twilight Blue = 0A437A
	Color: Rust = B7410E
	Color: Sun Yellow = FFDF22
	Color: Pumpkin = FF7518
	Color: Veronica = A020F0
	Color: Very Dark Blue = 000133
	Color: Peachy Pink = FF9A8A
	Color: Ocean Boat Blue = 0077BE
	Color: Orangish = FC824A
	Color: Wild Lime = CBD862
	Color: Toxic Green = 61DE2A
	Color: Sabria Pink = FC0585
	Color: Old Burgundy = 43302E
	Color: Powder Blue = B1D1FC
	Color: Vivid Strawberry = F70077
	Color: Red Wine = 8C0034
	Color: Rich Lilac = B666D2
	Color: Pastel Yellow = FFFE71
	Color: Saddle Brown = 8B4513
	Color: Wenge = 645452
	Color: Wisteria = C9A0DC
	Color: Terracota = CB6843
	Color: Rich Raspberry = D72D5C
	Color: Old Lavender = 796878
	Color: Rose Red = BE013C
	Color: Peach-orange = FFCC99
	Color: Pink = FF81C0
	Color: Tea = 65AB7C
	Color: Violet (ryb) = 8601AF
	Color: Royal = 0C1793
	Color: Telemagenta = D72D6D
	Color: Tea Rose = F4C2C2
	Color: Pink Pearl = E7ACCF
	Color: Selective Yellow = FFBA00
	Color: Pale Peach = FFE5AD
	Color: Rouge = AB1239
	Color: Pale Copper = DA8A67
	Color: Silver Pink = C4AEAD
	Color: Peach = FFE5B4
	Color: Raw Umber = A75E09
	Color: Periwinkle = 8E82FE
	Color: Pale Orange = FFA756
	Color: Yellow (ncs) = FFD300
	Color: Ugly Blue = 31668A
	Color: Unicorn = 9F91CF
	Color: Pink Purple = DB4BDA
	Color: Smokey Topaz = 933D41
	Color: Pastel Red = DB5856
	Color: Pacific Blue = 1CA9C9
	Color: Sienna = 882D17
	Color: Poo Brown = 885F01
	Color: Slate = 516572
	Color: Rich Maroon = B03060
	Color: Nice Blue = 107AB0
	Color: Purplish Grey = 7A687F
	Color: Pale Robin Egg Blue = 96DED1
	Color: Racing Green = 014600
	Color: Sickly Yellow = D0E429
	Color: Purple Taupe = 50404D
	Color: Wild Strawberry = FF43A4
	Color: Orange Pink = FF6F52
	Color: Rich Purple = 720058
	Color: Red (pigment) = ED1C24
	Color: Very Light Purple = F6CEFC
	Color: Raspberry Pink = E25098
	Color: Navy Green = 35530A
	Color: Pastel Purple = CAA0FF
	Color: Sheen Green = 8FD400
	Color: Soft Green = 6FC276
	Color: Queen Pink = E8CC07
	Color: Straw = E4D96F
	Color: Verdigris = 43B3AE
	Color: Pale Olive Green = B1D27B
	Color: Up Maroon = 7B1113
	Color: Ua Blue = 0033AA
	Color: Yellowish Brown = 9B7A01
	Color: Water Blue = 0E87CC
	Color: Rose Taupe = 905D5D
	Color: Pale Cerulean = 9BC4E2
	Color: Vomit = A2A415
	Color: Persian Blue = 1C39BB
	Color: Petrol = 005F6A
	Color: Usumbara Chameleon Harlequin = 50B708
	Color: Perfume = D0BEF8
	Color: Vomit Yellow = C7C10C
	Color: Tiffany Blue = 0ABAB5
	Color: Rich Black = 004040
	Color: North Texas Green = 059033
	Color: Pear Sorbet = F4EED7
	Color: Sapphire = 2138AB
	Color: Peach Tan = B4745E
	Color: Sunny Orange = FC5110
	Color: Peach Blossom Pink = EA9399
	Color: Taupe = 483C32
	Color: Ukrainian Azure = 42ADDE
	Color: Outer Space = 414A4C
	Color: Vivid Blue = 152EFF
	Color: Screamin' Green = 76FF7A
	Color: Zaffre = 0014A8
	Color: Palatinate Purple = 682860
	Color: Pumpkin Orange = FB7D07
	Color: Traffic Purple = A03472
	Color: Pale Silver = C9C0BB
	Color: Very Pale Green = CFFDBC
	Color: Ocean Blue = 03719C
	Color: Regalia = 522D80
	Color: Washed Out Green = BCF5A6
	Color: Ocre = C69C04
	Color: Tan = D1B26F
	Color: Rosebud Cherry = 892D52
	Color: Pansy Purple = 78184A
	Color: Neon Green = 0CFF0C
	Color: Waterspout = A4F4F9
	Color: Pale Cornflower Blue = ABCDEF
	Color: Yellow = FFFF33
	Color: Oxford Blue = 002147
	Color: Slate Blue = 5B7C99
	Color: Stormcloud = 4F666A
	Color: Royal Maroon = 5A3839
	Color: Rich Periwinkle = 9999FF
	Color: Snot = ACBB0D
	Color: Vanda = 9842E3
	Color: Tomato = FF6347
	Color: Purplish = 94568C
	Color: Satin Sheen Gold = CBA135
	Color: Princeton Orange = FF8F00
	Color: Scuba Blue = D0B2CA
	Color: Sky = 82CAFC
	Color: Turquoise Green = 04F489
	Color: Sunny Yellow = FFF917
	Color: Pakistan Green = 006600
	Color: Purplish Red = B0054B
	Color: Yellow Orange = FFAE42
	Color: Slime Green = 99CC04
	Color: Yellow Green = C0FB2D
	Color: Ultramarine = 120A8F
	Color: Zydeco = 02402C
	Color: Unmellow Yellow = FFFF66
	Color: Olive Green = 677A04
	Color: Pastel Pink = FFBACD
	Color: Orchid Pink = F2BDCD
	Color: Tropical Green = 008B87
	Color: Squash = F2AB15
	Color: Sunflower Yellow = FFDA03
	Color: Tokyo Purple = 5A004A
	Color: Royal Blue (web) = 4169E1
	Color: Ultra Pink = FF6FFF
	Color: Napier Green = 3B7E00
	Color: Tickle Me Pink = FC89AC
	Color: Rich Pink-orange = ED999C
	Color: Pale Yellow = FFFF84
	Color: Ube = 8878C3
	Color: Padua = ADE6C4
	Color: Razzmatazz = E3256B
	Color: Taos Taupe = BFAA80
	Color: Windows Blue = 3778BF
	Color: Plum (traditional) = 8E4585
	Color: Rose Ebony = 674846
	Color: Sandstone = C9AE74
	Color: Very Dark Brown = 1D0200
	Color: Pale Taupe = BC987E
	Color: Pale Canary Yellow = FFFF99
	Color: Psychedelic Purple = DF00FF
	Color: Raw Sienna = 9A6200
	Color: Pig Pink = E78EA5
	Color: Sangria = 92000A
	Color: Slate Green = 658D6D
	Color: Vibrant Blue = 0339F8
	Color: Rich Apricot = FAB5F7
	Color: Purple Magic = 693B71
	Color: Pale Rose = FDC1C5
	Color: Opera Mauve = CA82AF
	Color: Ugly Pink = CD7584
	Color: Viridian = 1E9167
	Color: Olivine = 9AB973
	Color: Peach Sand = C1B6B3
	Color: Persian Lilac = C17E91
	Color: Red = FF0000
	Color: Rosebloom = E38FB7
	Color: University Of California Gold = B78727
	Color: Turquoise = 06C2AC
	Color: Violet-red = F7468A
	Color: Patina = 639A8F
	Color: Pale Italian Apricot = FFE6E6
	Color: Puce = CC8899
	Color: Spanish Fuchsia = E30052
	Color: Vivid Carmine Pink = FF5771
	Color: Paars = AA00FF
	Color: Off White = FFFFE4
	Color: Rose Violet = C24C92
	Color: Navy = 01153E
	Color: Violet = 8F00FF
	Color: Yellow Mist = FFFFE0
	Color: Sand Yellow = FCE166
	Color: Off Blue = 5684AE
	Color: Pinky Red = FC2647
	Color: Ruddy = FF0028
	Color: Wistful Mauve = 976F7B
	Color: Online Lime = 4B8740
	Color: Rich Lavender = A76BCF
	Color: Rabbit Eye = FF0033
	Color: Yellowish = FAEE66
	Color: Pale Teal = 82CBB2
	Color: Purple Wine = 8E3975
	Color: Sky Blue = 75BBFD
	Color: White = FFFFFF
	Color: Steel Blue = 5A7D9A
	Color: Pink Champagne = F1DDCF
	Color: Saffron = F4C430
	Color: Pale Turquoise = A5FBD5
	Color: Pale = FFF9D0
	Color: Seaweed = 18D17B
	Color: Rose Gold = B76E79
	Color: Ruby Red = 9B111E
	Color: Purple Heart = 69359C
	Color: Violet Eggplant = 991199
	Color: Rose Neyron = FF0057
	Color: Pale Light French Lavender = D8D0F5
	Color: Pastel Green = B0FF9D
	Color: Reddish Grey = 997570
	Color: White Smoke = F5F5F5
	Color: Pale Lime Green = B1FF65
	Color: Orange-red = FF4500
	Color: Process Cyan = 00B7EB
	Color: Peach Puff = FFDAB9
	Color: Sick Green = 9DB92C
	Color: Piss Yellow = DDD618
	Color: Rich Spring Green = 00E39A
	Color: Yellow Brown = B79400
	Color: Reddish Pink = FE2C54
	Color: Purpleish = 98568D
	Color: Phthalo Blue = 000F89
	Color: Spiro Disco Ball = 0FC0FC
	Color: Terra Cotta = C9643B
	Color: Paradise Pink = E63E62
	Color: Violent Violet = 290C5E
	Color: Pigment Green = 00A550
	Color: Rose = FF007F
	Color: Pale Electric Hollywood Cerise = FFC1E8
	Color: Olive Yellow = C2B709
	Color: Pale Spring Bud = ECEBBD
	Color: Rich Magenta = CA1F7B
	Color: Purple Pink = E03FD8
	Color: Process Magenta = FF0090
	Color: Radiant Orchid = B163A3
	Color: Purplish Blue = 601EF9
	Color: Pastel Orange = FF964F
	Color: Office Green = 008000
	Color: Smoky Black = 100C08
	Color: Tenn (tawny) = CD5700
	Color: Red Brown = 8B2E16
	Color: Neon Yellow = CFFF04
	Color: Striking Purple = 98508E
	Color: Pine = 2B5D34
	Color: Seafoam Green = 7AF9AB
	Color: Pale Rose Light = FFF3FA
	Color: Pale Red = D9544D
	Color: Yellow (munsell) = EFCC00
	Color: Pearly Purple = B768A2
	Color: Rust Red = AA2704
	Color: Tumbleweed = DEAA88
	Color: Taupe Gray = 8B8589
	Color: Tangelo = F94D00
	Color: Rocket Metallic = 8A7F8D
	Color: Puke = A5A502
	Color: Puke Brown = 947706
	Color: Rosewood Light = B00049
	Color: Slate Grey = 59656D
	Color: Scarlet = FF2000
	Color: Red-orange = FF3F34
	Color: Shadow = 8A795D
	Color: Raspberry Radiance = 82305A
	Color: Powder Blue (web) = B0E0E6
	Color: Starship = ECF245
	Color: Pansy = 7700FF
	Color: Vivid Burgundy = 9F1D35
	Color: Rich Blue = 021BF9
	Color: Ultra Blue = A3E3ED
	Color: Purple Rain = 4B308D
	Color: Pale Blue = D0FEFE
	Color: Strong Blue = 0C06F7
	Color: Pale Magenta = D767AD
	Color: Tan Brown = AB7E4C
	Color: True Blue = 0073CF
	Color: Pale Blue-green = 00DDDD
	Color: Spring Bud = A7FC00
	Color: Teal Green = 25A36F
	Color: Tufts Blue = 417DC1
	Color: Sandy Yellow = FDEE73
	Color: Vivid Plum = 9400A5
	Color: Olive Drab 7 = 3C341F
	Color: Tealish = 24BCA8
	Color: Pale Sky Blue = BDF6FE
	Color: Purplish Brown = 6B4247
	Color: Neon Red = FF073A
	Color: Raspberry Rose = B3446C
	Color: Vivid Electric Blue = 00A5D2
	Color: Pinkish Purple = D648D7
	Color: Sunny Lime = E2EE83
	Color: Quartz = 51484F
	Color: Plaza Taupe = A79E8B
	Color: Yellow-green = 9ACD32
	Color: Puke Green = 9AAE07
	Color: Upsdell Red = AE2029
	Color: Vermilion = F34234
	Color: Reddish Brown = 7F2B0A
	Color: Red (ncs) = C40233
	Color: Very Dark Green = 062E03
	Color: Teal = 008080
	Color: Pigment Violet = 9400D3
	Color: Persian Pink = F77FBE
	Color: Prelude = D0C0E5
	Color: Swamp Green = 748500
	Color: Royal Fuchsia = CA2C92
	Color: Sapphire Blue = 0067A5
	Color: Pale Olive = B9CC81
	Color: Pharlap = A3807B
	Color: Warm Black = 004242
	Color: Nyanza = E9FFDB
	Color: Pink/purple = EF1DE7
	Color: Ugly Yellow = D0C101
	Color: Supernova Light = FFE816
	Color: Pontiff = AF00FF
	Color: Watermelon = FD4659
	Color: Torch Red = FD0E35
	Color: Purplish Pink = CE5DAE
	Color: Strong Pink = FF0789
	Color: Ufo Green = 3CD070
	Color: Rainshower = EDFEFF
	Color: Reddy Brown = 6E1005
	Color: Puke Yellow = C2BE0E
	Color: Raspberry Wine = B63157
	Color: Non-photo Blue = A4DDED
	Color: Spruce = 0A5F38
	Color: Ochre = CC7722
	Color: Orange = F97306
	Color: Teal Deer = 99E6B3
	Color: Neon Pink = FE019A
	Color: Peacock Blue = 016795
	Color: Soft Blue = 6488EA
	Color: Supernova = FFC901
	Color: Peach Cream = FAD6A5
	Color: "Persian Plum, Prune" = 701C1C
	Color: Red (ryb) = FE2712
	Color: Pale Lime = BEFD73
	Color: Pastel Lavender = E0B0FF
	Color: Ou Crimson = 990000
	Color: Shit Brown = 7B5804
	Color: New Silver = BFB8A5
	Color: Velvet = 750851
	Color: Snow = FFFAFA
	Color: Pale Violet = CEAEFA
	Color: Violet Pink = FB5FFC
	Color: Steel = 738595
	Color: Titanium Yellow = EEE600
	Color: Skobeloff = 007474
	Color: Vivid Auburn = 922724
	Color: Pea Green = 8EAB12
	Color: Westminster = 5F00FF
	Color: Sandy Taupe = 967117
	Color: Yellow Ochre = CB9D06
	Color: Orangish Red = F43605
	Color: Night Blue = 040348
	Color: Spanish Crimson = E51A4C
	Color: Pearl = EAE0C8
	Color: Soft Pink = FDB0C0
	Color: Swedish Azure = 005B99
	Color: Venetian Red = C80815
	Color: Very Light Pink = FFF4F2
	Color: Umber = 635147
	Color: Timberwolf = DBD7D2
	Color: Sap Green = 5C8B15
	Color: Space Cadet = 1D2951
	Color: Resolution Blue = 002387
	Color: Pure Blue = 0203E2
	Color: Pea = A4BF20
	Color: Old Gold = CFB53B
	Color: Rufous = A81C07
	Color: Persian Green = 00A693
	Color: Wine Dregs = 673147
	Color: Wild Watermelon = FC6C85
	Color: Vivid Orchid = CC00FF
	Color: Raspberry = B00149
	Color: Ultra Green = 66FF66
	Color: Nasty Green = 70B23F
	Color: Sepia = 985E2B
	Color: Yellowy Green = BFF128
	Color: Ugly Green = 7A9703
	Color: Tuscany = C09999
	Color: Red-violet Eggplant = 990066
	Color: Very Light Green = D1FFBD
	Color: Turquoise Blue = 06B1C4
	Color: Steel Teal = 5F8A8B
	Color: Toolbox = 746CC0
	Color: Poo = 8F7303
	Color: Radioactive Green = 2CFA1F
	Color: Queen Blue = 436B95
	Color: Reddish Orange = F8481C
	Color: Rich Carmine Red = EB003C
	Color: Pastel Brown = 836953
	Color: Razzle Dazzle Rose = FF33CC
	Color: Royal Heath = AB3472
	Color: Peridot = E6E200
	Color: Violet Blue = 510AC9
	Color: Pinky Purple = C94CBE
	Color: Process Yellow = FFEF00
	Color: Plum Purple = 4E0550
	Color: Ugly Brown = 7D7103
	Color: Thistle = D8BFD8
	Color: Rosewood = 65000B
	Color: Snot Green = 9DC100
	Color: Ugly Purple = A442A0
	Color: Pale Lime Yellow = EAEDA6
	Color: Pale Pink = FFCFDC
	Color: Pinkish Orange = FF724C
	Color: Persian Red = CC3333
	Color: Rajah = FBAB60
	Color: Popstar = BE4F62
	Color: Rouge Light = D58EB5
	Color: Pale Amaranth Pink = DDBEC3
	Color: Slate Gray = 708090
	Color: Yellowy Brown = AE8B0C
	Color: Very Dark Purple = 2A0134
	Color: Peach Beige = C09396
	Color: Rose Quartz = AA98A9
	Color: Seafoam = 80F9AD
	Color: Seaweed Green = 35AD6B
	Color: Purpley Grey = 947E94
	Color: Usafa Blue = 004F98
	Color: Poop = 7F5E00
	Color: Pastel Blue = A2BFFE
	Color: Old Lace = FDF5E6
	Color: Tree Green = 2A7E19
	Color: Purply Pink = F075E6
	Color: Spanish Carmine = D10047
	Color: Navy Blue = 001146
	Color: Pearl Aqua = 88D8C0
	Color: Stormy Blue = 507B9C
	Color: Tan Green = A9BE70
	Color: Safety Orange = FF6600
	Color: Sirocco ) = 718080
	Color: Poop Brown = 7A5901
	Color: Rubine Red = D10056
	Color: Wheat = FBDD7E
	Color: Orange (color Wheel) = FF7F00
	Color: Wine = 722F37
	Color: Sand = C2B280
	Color: Tealish Green = 0CDC73
	Color: Warm Grey = 978A84
	Color: Vivid Cerise = DA1D81
	Color: Orange Red = FD411E
	Color: Yellowish Tan = FCFC81
	Color: Topaz = 13BBAF
	Color: Sage Green = 88B378
	Color: Pale Cyan = B7FFFA
	Color: Orange (ryb) = FB9902
	Color: Vibrant Green = 0ADD08
	Color: Red-violet = C71585
	Color: Xanadu = 738678
	Color: Shocking Pink = FE02A2
	Color: Orangish Brown = B25F03
	Color: Plum = 843179
	Color: Persian Indigo = 32127A
	Color: Purple = 800080
	Color: Nightclub = 660045
	Color: Rose White Light = FFFBFB
	Color: Tropical Rain Forest = 00755E
	Color: Vivid Purple = 9900FA
	Color: Polished Pine = 5DA493
	Color: Olivetone = 716E10
	Color: Peach Schnapps = FFDCD6
	Color: Pale Aqua = B8FFEB
	Color: Pastel Magenta = F49AC2
	Color: Sea Green = 20B2AA
	Color: Violet-blue = 324AB2
	Color: Persimmon = EC5800
	Color: Purply = 983FB2
	Color: Purple Grey = 866F85
	Color: Olive = 6E750E
	Color: Rich Mauve = E285FF
	Color: Rich Electric Blue = 0892D0
	Color: Sacramento State Green = 00563F
	Color: Purple Plum = 9C5186
	Color: Pixie Green = C0D8B6
	Color: Old Pink = C77986
	Color: Old Rose = C87F89
	Color: Sea = 3C9992
	Color: Rosso Corsa = D40000
	Color: Rich Brilliant Lavender = F1A7FE
	Color: Sea Blue = 047495
	Color: Star Command Blue = 007BBB
	Color: Utah Crimson = D3003F
	Color: Orangey Red = FA4224
	Color: Peach Red = F99379
	Color: Royal Purple = 4B006E
	Color: Steel Pink = CC33CC
	Color: Shit Green = 758000
	Color: Tea Green = BDF8A3
	Color: Winter Pear = 8A9A5B
	Color: Vivid Lavender = DF73FF
	Color: Seashell = FFF5EE
	Color: Ultra Orange = FF6037
	Color: Ocean = 017B92
	Color: Rusty Orange = CD5909
	Color: Quicksilver = A6A6A6
	Color: Wild Blue Yonder = A2ADD0
	Color: Ultramarine Blue = 1805DB
	Color: Rosy Pink = F6688E
	Color: Reddish Purple = 910951
	Color: Pale Brown = B1916E
	Color: Ocean Green = 3D9973
	Color: Pigment Indigo = 4B0082
	Color: Ucla Blue = 536895
	Color: Rich Harlequin = 3AE500
	Color: Red-brown = A52A2A
	Color: Yellowgreen = BBF90F
	Color: Purple/blue = 5D21D0
	Color: Rosy Brown Light = E2CACA
	Color: Purple Red = 990147
	Color: Terracotta = CA6641
	Color: Reddish = C44240
	Color: Violet (color Wheel) = 7F00FF
	Color: Rose Pink = F7879A
	Color: Warm Blue = 4B57DB
	Color: Warm Taupe = B29784
	Color: Neon Fuchsia = FE4164
	Color: Papaya Whip = FFEFD5
	Color: Purpleish Pink = DF4EC8
	Color: Turtle Green = 75B84F
	Color: Really Light Blue = D4FFFF
	Color: Perrywinkle = 8F8CE7
	Color: Orange (web Color) = FFA500
	Color: Pinkish Red = F10C45
	Color: Rust Orange = C45508
	Color: Rose Vale = AB4E52
	Color: Twilight Lavender = 8A496B
	Color: Sky Magenta = CF71AF
	Color: Pinkish Brown = B17261
	Color: Rose Bonbon = F9429E
	Color: Pastel Taupe = AF9E89
	Color: Yaffle Green = CECF72
	Color: Yellow Tan = FFE36E
	Color: Portland Orange = FF5A36
	Color: Prince Fan Purple = 6600B7
	Color: Pale Mauve = FED0FC
	Color: Strawberry = FB2943
	Color: Raindrop = 33FFCC
	Color: Parchment = FEFCAF
	Color: Robin Egg Blue = 8AF1FE
	Color: Pale Salmon = FFB19A
	Color: Panama Blue = B3BCE2
	Color: Purple Mountain Majesty = 9678B6
	Color: Smitten = C84186
	Color: Vietnamese Mauve = 993366
	Color: Roman Silver = 838996
	Color: Zinnwaldite = EBC2AF
	Color: Off Yellow = F1F33F
	Color: Pinky = FC86AA
	Color: Persian Rose = FE28A2
	Color: Pink Red = F5054F
	Color: Pinkish = D46A7E
	Color: Sandstorm = ECD540
	Color: Yellowish Orange = FFAB0F
	Color: Raspberry Sorbet = CC3A71
	Color: Very Light Blue = D5FFFF
	Color: Rouge Red = E44165
	Color: Rose Pearl = F03865
	Color: Tuscan Tan = A67B5B
	Color: Vulgar Purple = 3E2F84
	Color: Orange Peel = FF9F00
	Color: United Nations Blue = 5B92E5
	Color: Ocher = BF9B0C
	Color: Sandy Brown = C4A661
	Color: Peach Rust = C86D51
	Color: Swamp = 698339
	Color: Tiger's Eye = E08D3C
	Color: Purpley = 8756E4
	Color: Piggy Pink = FDDDE6
	Color: Pea Soup = 929901
	Color: Shit = 7F5F00
	Color: Orchid Mist = C3A6B1
	Color: Sandy = F1DA7A
	Color: Sinopia = CB410B
	Color: Twilight Mauve = 896F73
	Color: Stone = ADA587
	Color: Salmon = FF8C69
	Color: Orangey Brown = B16002
	Color: Pine Green = 0A481E
	Color: Pink Flamingo = FF66FF
	Color: Safety Orange (blaze Orange) = FF6700
	Color: Royal Blue = 0504AA
	Color: Peru = CD853F
	Color: Poison Green = 40FD14
	Color: Patina Light = AFD0CA
	Color: Tomato Red = EC2D01
	Color: Sugar Plum = 914E75
	Color: Spearmint = 1EF876
	Color: Teal Blue = 01889F
	Color: Shamrock = 01B44C
	Color: Weird Green = 3AE57F
	Color: St. Patrick's Blue = 23297A
	Color: Very Pale Blue = D6FFFE
	Color: Yellowish Green = B0DD16
	Color: Nadeshiko Pink = F6ADC6
	Color: Pinkish Tan = D99B82
	Color: Pale Plum = DDA0DD
	Color: Sage = 87AE73
	Color: Pastel Gray = CFCFC4
	Color: Twilight = 4E518B
	Color: Spring Green = 00FF7F
	Color: Rosy Brown = BC8F8F
	Color: Raspberry Red = C51D34
	Color: Zomp = 39A78E
	Color: Periwinkle Blue = 8F99FB
	Color: Rosa = FE86A4
	Color: Russet = 80461B
	Color: Warm Purple = 952E8F
	Color: Red Orange = FD3C06
	Color: Red Purple = 820747
	Color: Onyx = 353839
	Color: Orangered = FE420F
	Color: Unbleached Silk = FFDDCA
	Color: Rifle Green = 414833
	Color: Radical Red = FF355E
	Color: Signal Violet = 924E7D
	Color: Pale Purple = B790D4
	Color: Rose Dust = 9E5E6F
	Color: Poop Green = 6F7C00
	Color: Red (munsell) = F2003C
	Color: Neon Carrot = FF9933
	Color: Pear = D1E231
	Color: Warm Pink = FB5581
	Color: Watusi = FFDDCF
	Color: Rich Carmine = D70040
	Color: Yellow/green = C8FD3D
	Color: Peach Gray = ECD5C5
	Color: Yale Blue = 0F4D92
	Color: Purpley Blue = 5F34E7
	Color: Peru Tan = 7F3A02
	Color: Silver = C0C0C0
	Color: Rust Brown = 8B3103
	Color: Purpleish Blue = 6140EF
	Color: Violine = A10684
	Color: Orangeish = FD8D49
	Color: Purple (munsell) = 9F00C5
	Color: Putty = BEAE8A
	Color: Wild Orchid = D770A2
	
	In the HashQP class:
	
	Table Size = 1597
	Number of entries = 770
	Load factor = 0.48215403882279273
	Number of collisions = 323
	Longest Collision Run = 10
	
	
	HashSC #1 with the String key has: 
	Color: Sunflower = FFC512
	Color: Neon Yellow = CFFF04
	Color: Yellowish Brown = 9B7A01
	Color: Purplish Pink = CE5DAE
	Color: Yellow Brown = B79400
	Color: Pinkish Orange = FF724C
	Color: Sienna = 882D17
	Color: Scarlet = FF2000
	Color: Pale Italian Apricot = FFE6E6
	Color: Smokey Topaz = 933D41
	Color: Rich Magenta = CA1F7B
	Color: Steel Blue = 5A7D9A
	Color: Pale Gold = FDDE6C
	Color: Pear = D1E231
	Color: Vomit Green = 89A203
	Color: Warm Taupe = B29784
	Color: Yellow/green = C8FD3D
	Color: Tufts Blue = 417DC1
	Color: Sabria Pink = FC0585
	Color: Soft Purple = A66FB5
	Color: Paars = AA00FF
	Color: Purple/pink = D725DE
	Color: Wild Watermelon = FC6C85
	Color: Pale Canary Yellow = FFFF99
	Color: Pale Lime Yellow = EAEDA6
	Color: Shadow Lime = D4E29B
	Color: Taupe = 483C32
	Color: Slate Gray = 708090
	Color: Ultra Green = 66FF66
	Color: Pink/purple = EF1DE7
	Color: Pigment Green = 00A550
	Color: Regalia = 522D80
	Color: Thulian Pink = DE6FA1
	Color: Ultra Blue = A3E3ED
	Color: Tomato Red = EC2D01
	Color: Rich Brilliant Lavender = F1A7FE
	Color: Piggy Pink = FDDDE6
	Color: Yellow Tan = FFE36E
	Color: Peach Gray = ECD5C5
	Color: Orange Tan = FAA76C
	Color: Rich Raspberry = D72D5C
	Color: Strong Pink = FF0789
	Color: Studio = 714AB2
	Color: Red-violet = C71585
	Color: Swedish Azure = 005B99
	Color: Popstar = BE4F62
	Color: Winter Pear = 8A9A5B
	Color: Yellowish Orange = FFAB0F
	Color: Red (pigment) = ED1C24
	Color: Ultramarine = 120A8F
	Color: Platinum = E5E4E2
	Color: Purple Magic = 693B71
	Color: Off White = FFFFE4
	Color: Spanish Crimson = E51A4C
	Color: Rosewood = 65000B
	Color: Olive Drab 7 = 3C341F
	Color: Outer Space = 414A4C
	Color: Vivid Strawberry = F70077
	Color: Wheat = FBDD7E
	Color: Violine = A10684
	Color: Rubine Red = D10056
	Color: Rose Neyron = FF0057
	Color: Pale Orange = FFA756
	Color: Ua Red = D9004C
	Color: Warm Brown = 964E02
	Color: Vermilion = F34234
	Color: Pale Light French Lavender = D8D0F5
	Color: Reddish Purple = 910951
	Color: Purpleish Pink = DF4EC8
	Color: Very Light Green = D1FFBD
	Color: Silver Sand = BFC1C2
	Color: Pansy Purple = 78184A
	Color: Terracota = CB6843
	Color: Really Light Blue = D4FFFF
	Color: Old Rose = C87F89
	Color: Seance = 731E8F
	Color: Shit = 7F5F00
	Color: Royal = 0C1793
	Color: Warm Purple = 952E8F
	Color: Pastel Purple = CAA0FF
	Color: Wintergreen = 20F986
	Color: Pinkish = D46A7E
	Color: Pale Turquoise = A5FBD5
	Color: Rich Carmine Red = EB003C
	Color: Old Lavender = 796878
	Color: Process Cyan = 00B7EB
	Color: Very Light Brown = D3B683
	Color: Tenn (tawny) = CD5700
	Color: Sheen Green = 8FD400
	Color: Wine Dregs = 673147
	Color: Prussian Blue = 004577
	Color: Ruby = E0115F
	Color: Purplish Grey = 7A687F
	Color: Vibrant Purple = AD03DE
	Color: Peach Cream = FAD6A5
	Color: Wisteria = C9A0DC
	Color: Orange (color Wheel) = FF7F00
	Color: Yellowish Tan = FCFC81
	Color: Pig Pink = E78EA5
	Color: Persian Pink = F77FBE
	Color: Xanadu = 738678
	Color: Shiraz = B20931
	Color: Orangeish = FD8D49
	Color: Piss Yellow = DDD618
	Color: Royal Azure = 0038A8
	Color: Signal Violet = 924E7D
	Color: Timberwolf = DBD7D2
	Color: Radical Red = FF355E
	Color: Sea = 3C9992
	Color: Warm Black = 004242
	Color: Purply Blue = 661AEE
	Color: Pale Cyan = B7FFFA
	Color: Radiant Orchid = B163A3
	Color: Perrywinkle = 8F8CE7
	Color: Raspberry Pink = E25098
	Color: Red Pink = FA2A55
	Color: Orangish Red = F43605
	Color: Purple (munsell) = 9F00C5
	Color: Pale Copper = DA8A67
	Color: Navajo White = FFDEAD
	Color: Sun Yellow = FFDF22
	Color: Pastel Taupe = AF9E89
	Color: Purpleish = 98568D
	Color: Ultra Orange = FF6037
	Color: Petrol = 005F6A
	Color: Purplish Red = B0054B
	Color: Sandstone = C9AE74
	Color: Persian Lilac = C17E91
	Color: Pictorial Carmine = C30B4E
	Color: "Tangerine Yellow, Usc Gold" = FFCC00
	Color: Rose Gold = B76E79
	Color: North Texas Green = 059033
	Color: Washed Out Green = BCF5A6
	Color: Sonic Silver = 757575
	Color: Rocket Metallic = 8A7F8D
	Color: Pale Plum = DDA0DD
	Color: Stone = ADA587
	Color: Reddy Brown = 6E1005
	Color: Ruddy = FF0028
	Color: Neon Fuchsia = FE4164
	Color: Pastel Green = B0FF9D
	Color: Spruce = 0A5F38
	Color: Red (munsell) = F2003C
	Color: Slate Grey = 59656D
	Color: Office Green = 008000
	Color: Shit Green = 758000
	Color: Pale Violet = CEAEFA
	Color: Ocean = 017B92
	Color: Pale Cerulean = 9BC4E2
	Color: Yellow = FFFF33
	Color: Nyanza = E9FFDB
	Color: Twilight = 4E518B
	Color: Teal Deer = 99E6B3
	Color: Poop Green = 6F7C00
	Color: Soft Pink = FDB0C0
	Color: Skobeloff = 007474
	Color: Pastel Magenta = F49AC2
	Color: Wild Strawberry = FF43A4
	Color: Navy Blue = 001146
	Color: Tan = D1B26F
	Color: Red (ryb) = FE2712
	Color: Pastel Brown = 836953
	Color: Vulgar Purple = 3E2F84
	Color: Seafoam = 80F9AD
	Color: Plum (traditional) = 8E4585
	Color: Zinnwaldite Brown = 2C1608
	Color: Red-brown = A52A2A
	Color: Rose Ebony = 674846
	Color: Resolution Blue = 002387
	Color: Ugly Blue = 31668A
	Color: Process Magenta = FF0090
	Color: Nightclub = 660045
	Color: Saddle Brown = 8B4513
	Color: Shit Brown = 7B5804
	Color: Persian Orange = D99058
	Color: Tropical Rain Forest = 00755E
	Color: Poop Brown = 7A5901
	Color: Violet (ryb) = 8601AF
	Color: Neon Green = 0CFF0C
	Color: Sapphire Blue = 0067A5
	Color: Orange (ryb) = FB9902
	Color: Vivid Electric Blue = 00A5D2
	Color: Razzmatazz = E3256B
	Color: Sugar Plum = 914E75
	Color: Prince Fan Purple = 6600B7
	Color: Quicksilver = A6A6A6
	Color: Pinky Red = FC2647
	Color: Olive = 6E750E
	Color: Plum = 843179
	Color: Pakistan Green = 006600
	Color: Water Blue = 0E87CC
	Color: Pale Salmon = FFB19A
	Color: Tomato = FF6347
	Color: Spanish Carmine = D10047
	Color: Rich Electric Blue = 0892D0
	Color: Ocean Blue = 03719C
	Color: Peach Puff = FFDAB9
	Color: Pale Chestnut = DDADAF
	Color: Violet Red = A50055
	Color: Pale Amaranth Pink = DDBEC3
	Color: Toxic Green = 61DE2A
	Color: Pinkish Grey = C8ACA9
	Color: Olive Drab = 6F7632
	Color: Quartz = 51484F
	Color: Warm Pink = FB5581
	Color: Sunny Lime = E2EE83
	Color: Soft Green = 6FC276
	Color: Navy = 01153E
	Color: Patina = 639A8F
	Color: Waterspout = A4F4F9
	Color: White Smoke = F5F5F5
	Color: Snot Green = 9DC100
	Color: Peach-yellow = FADFAD
	Color: Pure Blue = 0203E2
	Color: Turquoise = 06C2AC
	Color: Striking Purple = 98508E
	Color: True Green = 089404
	Color: Sea Green = 20B2AA
	Color: Purple Blue = 632DE9
	Color: Pale Pink = FFCFDC
	Color: Pink Sherbet = F78FA7
	Color: Seafoam Blue = 78D1B6
	Color: Ruby Red = 9B111E
	Color: Rosy Pink = F6688E
	Color: Orange-red = FF4500
	Color: Peacock Blue = 016795
	Color: Tangerine = FF9408
	Color: Pistachio = 93C572
	Color: Venetian Red = C80815
	Color: Pigment Blue = 333399
	Color: Rich Blue = 021BF9
	Color: Vivid Purple = 9900FA
	Color: Sap Green = 5C8B15
	Color: Rich Mauve = E285FF
	Color: Very Light Blue = D5FFFF
	Color: Pale Lime Green = B1FF65
	Color: Violet Pink = FB5FFC
	Color: Sky Blue = 75BBFD
	Color: New Silver = BFB8A5
	Color: Veronica = A020F0
	Color: Straw = E4D96F
	Color: Persian Rose = FE28A2
	Color: Night Shadz = AA375A
	Color: Plaza Taupe = A79E8B
	Color: Sand Yellow = FCE166
	Color: Old Lace = FDF5E6
	Color: Taupe Brown = 674C47
	Color: Purplish = 94568C
	Color: Pastel Blue = A2BFFE
	Color: Unbleached Silk = FFDDCA
	Color: Rose Taupe = 905D5D
	Color: Zydeco = 02402C
	Color: Vivid Green = 2FEF10
	Color: Peach Bisque = A87C6D
	Color: Raspberry = B00149
	Color: Twilight Mauve = 896F73
	Color: Pink Pearl = E7ACCF
	Color: Sandstorm = ECD540
	Color: Raspberry Rose = B3446C
	Color: Queen Pink = E8CC07
	Color: Vivid Cerise = DA1D81
	Color: St. Patrick's Blue = 23297A
	Color: Wine Red = 7B0323
	Color: Olivine = 9AB973
	Color: Polished Pine = 5DA493
	Color: Zomp = 39A78E
	Color: Pine = 2B5D34
	Color: Portland Orange = FF5A36
	Color: University Of California Gold = B78727
	Color: Toupe = C7AC7D
	Color: Orangey Brown = B16002
	Color: Pink = FF81C0
	Color: Vivid Burgundy = 9F1D35
	Color: Tea = 65AB7C
	Color: Twilight Lavender = 8A496B
	Color: Purple Wine = 8E3975
	Color: Sickly Yellow = D0E429
	Color: Traffic Purple = A03472
	Color: Scuba Blue = D0B2CA
	Color: Night Blue = 040348
	Color: Stormcloud = 4F666A
	Color: Ugly Green = 7A9703
	Color: Spearmint = 1EF876
	Color: Tiger's Eye = E08D3C
	Color: Rose Bonbon = F9429E
	Color: Outrageous Orange = FF6E4A
	Color: Vivid Auburn = 922724
	Color: Yellow Orange = FFAE42
	Color: Royal Heath = AB3472
	Color: Warm Grey = 978A84
	Color: Supernova Light = FFE816
	Color: Tealish = 24BCA8
	Color: Puce = CC8899
	Color: Ultramarine Blue = 1805DB
	Color: Usumbara Chameleon Harlequin = 50B708
	Color: Yellow (ncs) = FFD300
	Color: Navy Green = 35530A
	Color: Orange = F97306
	Color: Rainshower = EDFEFF
	Color: Neon Carrot = FF9933
	Color: Ugly Brown = 7D7103
	Color: Weird Green = 3AE57F
	Color: Neon Pink = FE019A
	Color: Yale Blue = 0F4D92
	Color: Purpley Blue = 5F34E7
	Color: Yellow Ochre = CB9D06
	Color: Teal Green = 25A36F
	Color: Sea Blue = 047495
	Color: Pale Grey = FDFDFE
	Color: Ugly Purple = A442A0
	Color: Raindrop = 33FFCC
	Color: Pale Lilac = E4CBFF
	Color: Sinopia = CB410B
	Color: Nice Blue = 107AB0
	Color: Pea Green = 8EAB12
	Color: Sky Magenta = CF71AF
	Color: Red Orange = FD3C06
	Color: Violet Eggplant = 991199
	Color: Sky = 82CAFC
	Color: Zinnwaldite = EBC2AF
	Color: Rich Pink-orange = ED999C
	Color: Swamp = 698339
	Color: Sandy = F1DA7A
	Color: Rich Black = 004040
	Color: Thistle = D8BFD8
	Color: Utah Crimson = D3003F
	Color: Neon Red = FF073A
	Color: Yaffle Green = CECF72
	Color: Very Pale Blue = D6FFFE
	Color: Ruddy Pink = E18E96
	Color: Palatinate Blue = 273BE2
	Color: Windsor Tan = AE6838
	Color: Rose Pink = F7879A
	Color: Phthalo Green = 123524
	Color: Velvet = 750851
	Color: Wild Lime = CBD862
	Color: Onyx = 353839
	Color: Orangered = FE420F
	Color: Pear Sorbet = F4EED7
	Color: Ube = 8878C3
	Color: Pale Green-yellow = F1E788
	Color: Steel Pink = CC33CC
	Color: Purple Taupe = 50404D
	Color: Powder Blue = B1D1FC
	Color: Pinkish Purple = D648D7
	Color: Victoria Plum = 002C39
	Color: Royal Maroon = 5A3839
	Color: Peach-orange = FFCC99
	Color: Pearl Violet = 8683A1
	Color: Old Burgundy = 43302E
	Color: Pale Spring Bud = ECEBBD
	Color: Taupe Gray = 8B8589
	Color: Orange Peel = FF9F00
	Color: Red Brown = 8B2E16
	Color: Ochre = CC7722
	Color: Pale Rose = FDC1C5
	Color: Pale Olive Green = B1D27B
	Color: Ultra Pink = FF6FFF
	Color: Vermillion = F4320C
	Color: Pinky = FC86AA
	Color: Vivid Orchid = CC00FF
	Color: Pale Teal = 82CBB2
	Color: Pink Lace = FFDDF4
	Color: Shocking Pink = FE02A2
	Color: Usafa Blue = 004F98
	Color: Pinky Purple = C94CBE
	Color: Sirocco ) = 718080
	Color: Pale Cornflower Blue = ABCDEF
	Color: Very Dark Blue = 000133
	Color: Vibrant Green = 0ADD08
	Color: Pigment Violet = 9400D3
	Color: Tropical Green = 008B87
	Color: Pastel Yellow = FFFE71
	Color: Orange Brown = BE6400
	Color: Vivid Blue = 152EFF
	Color: Violet (color Wheel) = 7F00FF
	Color: Rifle Green = 414833
	Color: Teal Blue = 01889F
	Color: Ua Blue = 0033AA
	Color: Online Lime = 4B8740
	Color: Pale Blue-green = 00DDDD
	Color: Pixie Green = C0D8B6
	Color: Rosy Brown Light = E2CACA
	Color: Persian Indigo = 32127A
	Color: Slate = 516572
	Color: Rouge = AB1239
	Color: Racing Green = 014600
	Color: Violet = 8F00FF
	Color: Sepia = 985E2B
	Color: Purple Brown = 673A3F
	Color: Peach Beige = C09396
	Color: Sand Brown = CBA560
	Color: Pale Aqua = B8FFEB
	Color: Poo Brown = 885F01
	Color: Pale Purple = B790D4
	Color: Powder Blue (web) = B0E0E6
	Color: Off Green = 6BA353
	Color: Rosa = FE86A4
	Color: Verdigris = 43B3AE
	Color: Rose = FF007F
	Color: Sunglow = FFCC33
	Color: Pea = A4BF20
	Color: Tea Rose = F4C2C2
	Color: Tangelo = F94D00
	Color: Peach Rust = C86D51
	Color: Tuscan Red = 7C4848
	Color: Sacramento State Green = 00563F
	Color: Teal = 008080
	Color: Ucla Blue = 536895
	Color: Plum Purple = 4E0550
	Color: Saffron = F4C430
	Color: Pearl = EAE0C8
	Color: Pastel Red = DB5856
	Color: Wintergreen Dream = 56887D
	Color: Titanium Yellow = EEE600
	Color: Salmon = FF8C69
	Color: Rich Maroon = B03060
	Color: Unmellow Yellow = FFFF66
	Color: Telemagenta = D72D6D
	Color: Sandy Yellow = FDEE73
	Color: Steel Grey = 6F828A
	Color: Rich Orange = FF681F
	Color: Sage = 87AE73
	Color: Very Light Purple = F6CEFC
	Color: Space Cadet = 1D2951
	Color: Sick Green = 9DB92C
	Color: Rose Dust = 9E5E6F
	Color: Snot = ACBB0D
	Color: Princeton Orange = FF8F00
	Color: Violent Violet = 290C5E
	Color: Snow = FFFAFA
	Color: Rose Quartz = AA98A9
	Color: Orangey Yellow = FDB915
	Color: Purply Pink = F075E6
	Color: Vivid Tangerine = FF9980
	Color: Safety Orange (blaze Orange) = FF6700
	Color: Periwinkle = 8E82FE
	Color: Persian Green = 00A693
	Color: Pacific Blue = 1CA9C9
	Color: Urobilin = E1AD21
	Color: Raw Umber = A75E09
	Color: Very Dark Purple = 2A0134
	Color: Peach Sand = C1B6B3
	Color: Squash = F2AB15
	Color: Tan Green = A9BE70
	Color: Primary Blue = 0804F9
	Color: Vibrant Blue = 0339F8
	Color: Seafoam Green = 7AF9AB
	Color: Peridot = E6E200
	Color: Rosebloom = E38FB7
	Color: Persian Red = CC3333
	Color: Purplish Blue = 601EF9
	Color: Reddish Brown = 7F2B0A
	Color: Yellowgreen = BBF90F
	Color: Purple Plum = 9C5186
	Color: Putty = BEAE8A
	Color: Up Maroon = 7B1113
	Color: Silver Pink = C4AEAD
	Color: Raspberry Sorbet = CC3A71
	Color: Stormy Blue = 507B9C
	Color: Upsdell Red = AE2029
	Color: Purple/blue = 5D21D0
	Color: Tan Brown = AB7E4C
	Color: Yellowy Green = BFF128
	Color: Peachy Pink = FF9A8A
	Color: Razzle Dazzle Rose = FF33CC
	Color: Vietnamese Mauve = 993366
	Color: Pale = FFF9D0
	Color: Spanish Fuchsia = E30052
	Color: White = FFFFFF
	Color: Rusty Red = AF2F0D
	Color: Rose White Light = FFFBFB
	Color: Sunny Orange = FC5110
	Color: Ocean Boat Blue = 0077BE
	Color: Vanda = 9842E3
	Color: New York Pink = D7837F
	Color: Poop = 7F5E00
	Color: Peach Red = F99379
	Color: Purple Rain = 4B308D
	Color: Neon Purple = BC13FE
	Color: Pale Blush = F4BBCF
	Color: Strong Blue = 0C06F7
	Color: Silver Chalice = ACACAC
	Color: Pink Purple = DB4BDA
	Color: Steel Teal = 5F8A8B
	Color: Orange Pink = FF6F52
	Color: Yellowy Brown = AE8B0C
	Color: Pullman Brown = 644117
	Color: Pale Sky Blue = BDF6FE
	Color: Sangria = 92000A
	Color: Ugly Pink = CD7584
	Color: Pigment Indigo = 4B0082
	Color: Orange (web Color) = FFA500
	Color: Old Gold = CFB53B
	Color: Ruddy Brown = BB6528
	Color: Reddish Orange = F8481C
	Color: Pale Robin Egg Blue = 96DED1
	Color: Water = 96ABA5
	Color: Slate Blue = 5B7C99
	Color: Orchid Pink = F2BDCD
	Color: Purpleish Blue = 6140EF
	Color: Purple Reign = 54446C
	Color: Radioactive Green = 2CFA1F
	Color: Orangish = FC824A
	Color: Royal Blue = 0504AA
	Color: Pastel Orange = FF964F
	Color: Selective Yellow = FFBA00
	Color: Simply Taupe = ABA092
	Color: Rust Orange = C45508
	Color: Pale Silver = C9C0BB
	Color: Toolbox = 746CC0
	Color: Pinkish Brown = B17261
	Color: Pink Flamingo = FF66FF
	Color: Puke = A5A502
	Color: Pale Peach = FFE5AD
	Color: Peru = CD853F
	Color: Reddish Pink = FE2C54
	Color: Ucla Gold = FFB300
	Color: Pinkish Red = F10C45
	Color: Pastel Gray = CFCFC4
	Color: Process Yellow = FFEF00
	Color: Pale Goldenrod = EEE8AA
	Color: Purple Orchid = AE4F93
	Color: Sickly Green = 94B21C
	Color: Rajah = FBAB60
	Color: Raspberry Red = C51D34
	Color: Purplish Brown = 6B4247
	Color: Salmon Pink = FE7B7C
	Color: Papaya Whip = FFEFD5
	Color: Rouge Light = D58EB5
	Color: Nadeshiko Pink = F6ADC6
	Color: Raspberry Radiance = 82305A
	Color: Purple Pink = E03FD8
	Color: Rich Lavender = A76BCF
	Color: Persian Blue = 1C39BB
	Color: Sandy Taupe = 967117
	Color: Pink Light = FFE4E9
	Color: Rufous = A81C07
	Color: Rich Periwinkle = 9999FF
	Color: Violet-blue = 324AB2
	Color: Viridian = 1E9167
	Color: Reddish = C44240
	Color: Rich Tyrian Purple = 9E0E40
	Color: Safety Orange = FF6600
	Color: Rosso Corsa = D40000
	Color: Purple Mountain Majesty = 9678B6
	Color: Pale Lime = BEFD73
	Color: Pearl Aqua = 88D8C0
	Color: Tree Green = 2A7E19
	Color: Ocean Green = 3D9973
	Color: Very Dark Green = 062E03
	Color: Very Light Pink = FFF4F2
	Color: Pale Red = D9544D
	Color: Orchid Mist = C3A6B1
	Color: Starship = ECF245
	Color: Robin's Egg Blue = 98EFF9
	Color: Shamrock = 01B44C
	Color: Off Blue = 5684AE
	Color: Very Pale Green = CFFDBC
	Color: Seaweed = 18D17B
	Color: Yellow-green = 9ACD32
	Color: Pastel Pink = FFBACD
	Color: Padua = ADE6C4
	Color: Star Command Blue = 007BBB
	Color: Pea Soup = 929901
	Color: Olive Yellow = C2B709
	Color: Rose Red = BE013C
	Color: Turkish Rose = B57281
	Color: Very Dark Brown = 1D0200
	Color: Pansy = 7700FF
	Color: Sapphire = 2138AB
	Color: Wild Blue Yonder = A2ADD0
	Color: Puke Yellow = C2BE0E
	Color: Selago = F0EEFD
	Color: Topaz = 13BBAF
	Color: Royal Blue (web) = 4169E1
	Color: Old Silver = 848482
	Color: Paradise Pink = E63E62
	Color: Yellow (ryb) = FEFE33
	Color: Panama Blue = B3BCE2
	Color: Olive Green = 677A04
	Color: Shadow = 8A795D
	Color: Roman Silver = 838996
	Color: Red-violet Eggplant = 990066
	Color: Sandy Brown = C4A661
	Color: Watermelon = FD4659
	Color: Violet-red = F7468A
	Color: True Blue = 0073CF
	Color: Pale Rose Light = FFF3FA
	Color: Spiro Disco Ball = 0FC0FC
	Color: Patina Light = AFD0CA
	Color: Turquoise Blue = 06B1C4
	Color: Steel = 738595
	Color: Pale Taupe = BC987E
	Color: Rust = B7410E
	Color: Tealish Green = 0CDC73
	Color: Ugly Yellow = D0C101
	Color: Soft Blue = 6488EA
	Color: Pastel Violet = A47D90
	Color: Pale Mauve = FED0FC
	Color: Orange Red = FD411E
	Color: Olive Brown = 645403
	Color: Rich Carmine = D70040
	Color: Purpley = 8756E4
	Color: Raspberry Wine = B63157
	Color: Vomit Yellow = C7C10C
	Color: Red Wine = 8C0034
	Color: Orangey Red = FA4224
	Color: United Nations Blue = 5B92E5
	Color: Non-photo Blue = A4DDED
	Color: Tuscan Tan = A67B5B
	Color: Rose Violet = C24C92
	Color: Reddish Grey = 997570
	Color: Vivid Plum = 9400A5
	Color: Peach Schnapps = FFDCD6
	Color: Pale Green = C7FDB5
	Color: Terracotta = CA6641
	Color: Nasty Green = 70B23F
	Color: Pine Green = 0A481E
	Color: Purple = 800080
	Color: Rosy Brown = BC8F8F
	Color: Screamin' Green = 76FF7A
	Color: Purpley Pink = C83CB9
	Color: Sunflower Yellow = FFDA03
	Color: Purple Grey = 866F85
	Color: Palatinate Purple = 682860
	Color: Smitten = C84186
	Color: Sunshine Yellow = FFFD37
	Color: Rouge Red = E44165
	Color: Rose Pearl = F03865
	Color: "Persian Plum, Prune" = 701C1C
	Color: Windows Blue = 3778BF
	Color: Opera Mauve = CA82AF
	Color: Pale Violet Red = DB7093
	Color: Rosebud Cherry = 892D52
	Color: Red (ncs) = C40233
	Color: Sand = C2B280
	Color: Pale Brown = B1916E
	Color: Supernova = FFC901
	Color: Red Purple = 820747
	Color: Royal Fuchsia = CA2C92
	Color: Pharlap = A3807B
	Color: Slime Green = 99CC04
	Color: Purply = 983FB2
	Color: Purple Red = 990147
	Color: Oxford Blue = 002147
	Color: Peach Blossom Pink = EA9399
	Color: Pink Champagne = F1DDCF
	Color: Russet = 80461B
	Color: Warm Blue = 4B57DB
	Color: Pink Red = F5054F
	Color: Wistful Mauve = 976F7B
	Color: Raw Sienna = 9A6200
	Color: Rust Brown = 8B3103
	Color: Pastel Lavender = E0B0FF
	Color: Poison Green = 40FD14
	Color: Perfume = D0BEF8
	Color: Yellow (munsell) = EFCC00
	Color: Slate Green = 658D6D
	Color: Pontiff = AF00FF
	Color: Pale Blue = D0FEFE
	Color: Shamrock Green = 02C14D
	Color: Pea Soup Green = 94A617
	Color: Unicorn = 9F91CF
	Color: Taos Taupe = BFAA80
	Color: Powder Pink = FFB2D0
	Color: Tea Green = BDF8A3
	Color: Sunny Yellow = FFF917
	Color: Pale Magenta = D767AD
	Color: Robin's Egg = 6DEDFD
	Color: Tuscany = C09999
	Color: Smoky Black = 100C08
	Color: Spring Green = 00FF7F
	Color: Pearly Purple = B768A2
	Color: Ocre = C69C04
	Color: Rich Spring Green = 00E39A
	Color: Violet Blue = 510AC9
	Color: Orange Yellow = FFAD01
	Color: Pale Yellow = FFFF84
	Color: Spring Bud = A7FC00
	Color: Royal Purple = 4B006E
	Color: Peach Tan = B4745E
	Color: Satin Sheen Gold = CBA135
	Color: Tokyo Purple = 5A004A
	Color: Rose White = FFF6F5
	Color: Seaweed Green = 35AD6B
	Color: Queen Blue = 436B95
	Color: Old Pink = C77986
	Color: Orangish Brown = B25F03
	Color: Rich Lilac = B666D2
	Color: Tyrian Purple = 66023C
	Color: Robin Egg Blue = 8AF1FE
	Color: Torch Red = FD0E35
	Color: Pale Light Green = B1FC99
	Color: Purpley Grey = 947E94
	Color: Seal Brown = 321414
	Color: Tiffany Blue = 0ABAB5
	Color: Terra Cotta = C9643B
	Color: Red Devil = 860111
	Color: Prelude = D0C0E5
	Color: Poo = 8F7303
	Color: Rich Apricot = FAB5F7
	Color: Persimmon = EC5800
	Color: Vomit = A2A415
	Color: Ukrainian Azure = 42ADDE
	Color: Vivid Carmine Pink = FF5771
	Color: Red = FF0000
	Color: Strawberry = FB2943
	Color: Westminster = 5F00FF
	Color: Zaffre = 0014A8
	Color: Red-orange = FF3F34
	Color: Vintage Indigo = 664D64
	Color: Puke Green = 9AAE07
	Color: Vegas Gold = C5B358
	Color: Yellow Mist = FFFFE0
	Color: Sage Green = 88B378
	Color: Watusi = FFDDCF
	Color: Off Yellow = F1F33F
	Color: Ufo Green = 3CD070
	Color: Psychedelic Purple = DF00FF
	Color: Peach = FFE5B4
	Color: Phthalo Blue = 000F89
	Color: Purple Pizzazz = FE4EDA
	Color: Turtle Green = 75B84F
	Color: Pale Electric Hollywood Cerise = FFC1E8
	Color: Periwinkle Blue = 8F99FB
	Color: Rabbit Eye = FF0033
	Color: Pale Lavender = EECFFE
	Color: Tumbleweed = DEAA88
	Color: Rosewood Light = B00049
	Color: Red Violet = 9E0168
	Color: Pinkish Tan = D99B82
	Color: Ou Crimson = 990000
	Color: Neon Blue = 04D9FF
	Color: Puke Brown = 947706
	Color: Twilight Blue = 0A437A
	Color: Parchment = FEFCAF
	Color: Pale Persian Lilac = D597AE
	Color: Rich Harlequin = 3AE500
	Color: Seashell = FFF5EE
	Color: Rose Vale = AB4E52
	Color: Ocher = BF9B0C
	Color: Peru Tan = 7F3A02
	Color: Orchid Ice = DFD2DF
	Color: Pale Olive = B9CC81
	Color: Violet Purple = 926EAE
	Color: School Bus Yellow = FFD800
	Color: Pumpkin Orange = FB7D07
	Color: Napier Green = 3B7E00
	Color: Orchid = DA70D6
	Color: Rusty Orange = CD5909
	Color: Wild Orchid = D770A2
	Color: Tickle Me Pink = FC89AC
	Color: Rich Purple = 720058
	Color: Purple Heart = 69359C
	Color: Swamp Green = 748500
	Color: Olivetone = 716E10
	Color: Silver = C0C0C0
	Color: Turquoise Green = 04F489
	Color: Vivid Violet = 9F00FF
	Color: Vivid Lavender = DF73FF
	Color: Wine = 722F37
	Color: Yellowish Green = B0DD16
	Color: Rust Red = AA2704
	Color: Yellow Green = C0FB2D
	Color: Pumpkin = FF7518
	Color: Violet Tulle = C693C7
	Color: Wenge = 645452
	Color: Umber = 635147
	Color: Yellowish = FAEE66
	
	In the HashSC class:
	
	Table Size = 797
	Number of entries = 770
	Load factor = 0.9661229611041405
	Number of collisions = 379
	Longest Linked List = 5
	
	HashSC #2 with the String key has: 
	Color: Teal Green = 25A36F
	Color: Orchid Ice = DFD2DF
	Color: Pigment Blue = 333399
	Color: Orchid Pink = F2BDCD
	Color: Unmellow Yellow = FFFF66
	Color: Very Dark Brown = 1D0200
	Color: Wheat = FBDD7E
	Color: Pastel Violet = A47D90
	Color: Spanish Fuchsia = E30052
	Color: Slate Grey = 59656D
	Color: Rose Pink = F7879A
	Color: Pale Gold = FDDE6C
	Color: Pale Violet = CEAEFA
	Color: Rosebud Cherry = 892D52
	Color: Rich Spring Green = 00E39A
	Color: Prelude = D0C0E5
	Color: Vivid Blue = 152EFF
	Color: Pigment Indigo = 4B0082
	Color: Rufous = A81C07
	Color: Olive Brown = 645403
	Color: Purply Blue = 661AEE
	Color: Pure Blue = 0203E2
	Color: Razzle Dazzle Rose = FF33CC
	Color: Rouge = AB1239
	Color: Navy Green = 35530A
	Color: Persian Blue = 1C39BB
	Color: Rosso Corsa = D40000
	Color: Red Devil = 860111
	Color: Pastel Blue = A2BFFE
	Color: Salmon Pink = FE7B7C
	Color: Ruddy = FF0028
	Color: Purple Orchid = AE4F93
	Color: Very Pale Blue = D6FFFE
	Color: Pea Soup = 929901
	Color: Pastel Taupe = AF9E89
	Color: Vivid Burgundy = 9F1D35
	Color: Puce = CC8899
	Color: Queen Pink = E8CC07
	Color: Wenge = 645452
	Color: Vivid Violet = 9F00FF
	Color: Soft Purple = A66FB5
	Color: Rainshower = EDFEFF
	Color: Pea Green = 8EAB12
	Color: Ocean = 017B92
	Color: Purple Rain = 4B308D
	Color: New York Pink = D7837F
	Color: Ucla Blue = 536895
	Color: Water = 96ABA5
	Color: Tufts Blue = 417DC1
	Color: Yellow Brown = B79400
	Color: Pale Red = D9544D
	Color: Sangria = 92000A
	Color: Tealish Green = 0CDC73
	Color: Skobeloff = 007474
	Color: Teal Deer = 99E6B3
	Color: Purple Red = 990147
	Color: Watermelon = FD4659
	Color: Poop Green = 6F7C00
	Color: Pastel Lavender = E0B0FF
	Color: Vivid Auburn = 922724
	Color: Neon Yellow = CFFF04
	Color: Purpleish = 98568D
	Color: Old Burgundy = 43302E
	Color: Tea = 65AB7C
	Color: Weird Green = 3AE57F
	Color: Raw Sienna = 9A6200
	Color: Rajah = FBAB60
	Color: Powder Blue (web) = B0E0E6
	Color: Vivid Carmine Pink = FF5771
	Color: Pale Canary Yellow = FFFF99
	Color: Palatinate Purple = 682860
	Color: Selective Yellow = FFBA00
	Color: Spearmint = 1EF876
	Color: Ugly Pink = CD7584
	Color: Pastel Red = DB5856
	Color: Ultra Orange = FF6037
	Color: Nightclub = 660045
	Color: Pale Green-yellow = F1E788
	Color: Rust Orange = C45508
	Color: Pale Cerulean = 9BC4E2
	Color: Violet (color Wheel) = 7F00FF
	Color: Red Purple = 820747
	Color: Orangish = FC824A
	Color: Popstar = BE4F62
	Color: Sunshine Yellow = FFFD37
	Color: Pumpkin = FF7518
	Color: Panama Blue = B3BCE2
	Color: Pale = FFF9D0
	Color: Strong Blue = 0C06F7
	Color: Rose White Light = FFFBFB
	Color: Olive Drab = 6F7632
	Color: Wild Watermelon = FC6C85
	Color: Tomato = FF6347
	Color: Vivid Lavender = DF73FF
	Color: Tiffany Blue = 0ABAB5
	Color: Slate = 516572
	Color: Rich Pink-orange = ED999C
	Color: Persian Orange = D99058
	Color: Yellow-green = 9ACD32
	Color: Pale Rose Light = FFF3FA
	Color: Scuba Blue = D0B2CA
	Color: Seafoam = 80F9AD
	Color: Silver Chalice = ACACAC
	Color: Nice Blue = 107AB0
	Color: Steel Blue = 5A7D9A
	Color: Ruby = E0115F
	Color: Peridot = E6E200
	Color: Quartz = 51484F
	Color: Terracota = CB6843
	Color: Yellow = FFFF33
	Color: Smoky Black = 100C08
	Color: Violine = A10684
	Color: Pastel Brown = 836953
	Color: Neon Fuchsia = FE4164
	Color: Nasty Green = 70B23F
	Color: Vermillion = F4320C
	Color: True Blue = 0073CF
	Color: Warm Taupe = B29784
	Color: Old Lavender = 796878
	Color: School Bus Yellow = FFD800
	Color: Vivid Green = 2FEF10
	Color: Purplish = 94568C
	Color: Plum (traditional) = 8E4585
	Color: Zydeco = 02402C
	Color: Purple/blue = 5D21D0
	Color: Red-violet Eggplant = 990066
	Color: Vanda = 9842E3
	Color: Tumbleweed = DEAA88
	Color: Rosebloom = E38FB7
	Color: Olive Yellow = C2B709
	Color: Utah Crimson = D3003F
	Color: Orange Red = FD411E
	Color: Red (munsell) = F2003C
	Color: Turquoise = 06C2AC
	Color: Steel Teal = 5F8A8B
	Color: Tropical Green = 008B87
	Color: Radioactive Green = 2CFA1F
	Color: Violet Tulle = C693C7
	Color: Vintage Indigo = 664D64
	Color: Swamp Green = 748500
	Color: Orangish Brown = B25F03
	Color: Pale Sky Blue = BDF6FE
	Color: Zinnwaldite = EBC2AF
	Color: Yaffle Green = CECF72
	Color: Peach Beige = C09396
	Color: Velvet = 750851
	Color: Space Cadet = 1D2951
	Color: Yellowish Green = B0DD16
	Color: Peachy Pink = FF9A8A
	Color: Rose Violet = C24C92
	Color: Rich Mauve = E285FF
	Color: Rose Dust = 9E5E6F
	Color: Purple Heart = 69359C
	Color: Very Light Green = D1FFBD
	Color: Sage Green = 88B378
	Color: Pastel Gray = CFCFC4
	Color: White Smoke = F5F5F5
	Color: Verdigris = 43B3AE
	Color: Pale Robin Egg Blue = 96DED1
	Color: Pea = A4BF20
	Color: Rose Gold = B76E79
	Color: Sea Blue = 047495
	Color: Tenn (tawny) = CD5700
	Color: Rich Raspberry = D72D5C
	Color: Topaz = 13BBAF
	Color: Violet Blue = 510AC9
	Color: Putty = BEAE8A
	Color: Red (ncs) = C40233
	Color: Ultra Pink = FF6FFF
	Color: Pink Purple = DB4BDA
	Color: Sap Green = 5C8B15
	Color: Puke Brown = 947706
	Color: Perrywinkle = 8F8CE7
	Color: Peach Red = F99379
	Color: Tan Brown = AB7E4C
	Color: Orange (ryb) = FB9902
	Color: Screamin' Green = 76FF7A
	Color: Warm Blue = 4B57DB
	Color: Twilight = 4E518B
	Color: Sickly Yellow = D0E429
	Color: Rich Brilliant Lavender = F1A7FE
	Color: Yellow Ochre = CB9D06
	Color: Vomit Green = 89A203
	Color: Red Orange = FD3C06
	Color: Windsor Tan = AE6838
	Color: Tyrian Purple = 66023C
	Color: Wisteria = C9A0DC
	Color: Viridian = 1E9167
	Color: Sapphire Blue = 0067A5
	Color: Pinkish = D46A7E
	Color: Raspberry Red = C51D34
	Color: Rich Magenta = CA1F7B
	Color: Racing Green = 014600
	Color: Purpley = 8756E4
	Color: Neon Red = FF073A
	Color: Westminster = 5F00FF
	Color: Pinkish Brown = B17261
	Color: Peach-yellow = FADFAD
	Color: Snot = ACBB0D
	Color: Warm Brown = 964E02
	Color: Robin's Egg Blue = 98EFF9
	Color: Royal Blue (web) = 4169E1
	Color: Snow = FFFAFA
	Color: "Persian Plum, Prune" = 701C1C
	Color: Pale Plum = DDA0DD
	Color: Wild Lime = CBD862
	Color: Yellowish = FAEE66
	Color: Ocre = C69C04
	Color: Royal Fuchsia = CA2C92
	Color: Sandy Taupe = 967117
	Color: Soft Green = 6FC276
	Color: Piss Yellow = DDD618
	Color: Pale Goldenrod = EEE8AA
	Color: Vivid Strawberry = F70077
	Color: Peru = CD853F
	Color: Rusty Orange = CD5909
	Color: Olive Drab 7 = 3C341F
	Color: Orange Yellow = FFAD01
	Color: Resolution Blue = 002387
	Color: Portland Orange = FF5A36
	Color: Plaza Taupe = A79E8B
	Color: Old Lace = FDF5E6
	Color: Pale Electric Hollywood Cerise = FFC1E8
	Color: Pale Chestnut = DDADAF
	Color: Rich Harlequin = 3AE500
	Color: Night Blue = 040348
	Color: Wild Blue Yonder = A2ADD0
	Color: Paradise Pink = E63E62
	Color: Twilight Lavender = 8A496B
	Color: Sand Brown = CBA560
	Color: Patina = 639A8F
	Color: Off White = FFFFE4
	Color: Orangered = FE420F
	Color: Pale Mauve = FED0FC
	Color: Radiant Orchid = B163A3
	Color: Sirocco ) = 718080
	Color: Taos Taupe = BFAA80
	Color: Ocean Boat Blue = 0077BE
	Color: Purply Pink = F075E6
	Color: Peacock Blue = 016795
	Color: Poop = 7F5E00
	Color: Persimmon = EC5800
	Color: Persian Pink = F77FBE
	Color: Supernova Light = FFE816
	Color: Orangey Brown = B16002
	Color: Squash = F2AB15
	Color: Pastel Pink = FFBACD
	Color: Yellowy Brown = AE8B0C
	Color: Pea Soup Green = 94A617
	Color: Persian Green = 00A693
	Color: Wild Strawberry = FF43A4
	Color: Phthalo Green = 123524
	Color: Stone = ADA587
	Color: Stormy Blue = 507B9C
	Color: Peru Tan = 7F3A02
	Color: Swedish Azure = 005B99
	Color: Rosewood = 65000B
	Color: Terracotta = CA6641
	Color: Persian Red = CC3333
	Color: Robin Egg Blue = 8AF1FE
	Color: Sand Yellow = FCE166
	Color: Orange-red = FF4500
	Color: Yellow Tan = FFE36E
	Color: Yellowish Orange = FFAB0F
	Color: Venetian Red = C80815
	Color: Oxford Blue = 002147
	Color: Red Violet = 9E0168
	Color: Peach Gray = ECD5C5
	Color: Pale Green = C7FDB5
	Color: Sunny Lime = E2EE83
	Color: Purplish Blue = 601EF9
	Color: Russet = 80461B
	Color: Rich Black = 004040
	Color: Princeton Orange = FF8F00
	Color: Neon Carrot = FF9933
	Color: Pale Violet Red = DB7093
	Color: Rosy Brown = BC8F8F
	Color: Sonic Silver = 757575
	Color: Saddle Brown = 8B4513
	Color: Sea = 3C9992
	Color: Rich Electric Blue = 0892D0
	Color: Taupe Gray = 8B8589
	Color: Sky Magenta = CF71AF
	Color: Royal Heath = AB3472
	Color: Very Light Blue = D5FFFF
	Color: Shiraz = B20931
	Color: Pastel Yellow = FFFE71
	Color: Sandy Brown = C4A661
	Color: Spring Green = 00FF7F
	Color: Sienna = 882D17
	Color: Peach Sand = C1B6B3
	Color: Off Yellow = F1F33F
	Color: Starship = ECF245
	Color: Scarlet = FF2000
	Color: Red-orange = FF3F34
	Color: Pale Yellow = FFFF84
	Color: Rich Purple = 720058
	Color: Reddish Brown = 7F2B0A
	Color: Paars = AA00FF
	Color: Rose Pearl = F03865
	Color: Violent Violet = 290C5E
	Color: Torch Red = FD0E35
	Color: Spring Bud = A7FC00
	Color: North Texas Green = 059033
	Color: Purple Plum = 9C5186
	Color: Rich Carmine Red = EB003C
	Color: Ocher = BF9B0C
	Color: Old Rose = C87F89
	Color: Strong Pink = FF0789
	Color: Periwinkle = 8E82FE
	Color: Shamrock = 01B44C
	Color: Seashell = FFF5EE
	Color: Psychedelic Purple = DF00FF
	Color: Purple (munsell) = 9F00C5
	Color: Puke = A5A502
	Color: Raspberry Sorbet = CC3A71
	Color: Nadeshiko Pink = F6ADC6
	Color: Ugly Yellow = D0C101
	Color: Pale Rose = FDC1C5
	Color: Steel Pink = CC33CC
	Color: Titanium Yellow = EEE600
	Color: Shamrock Green = 02C14D
	Color: Orange Tan = FAA76C
	Color: Peach Rust = C86D51
	Color: Plum = 843179
	Color: Sea Green = 20B2AA
	Color: Pigment Violet = 9400D3
	Color: Neon Green = 0CFF0C
	Color: Royal Purple = 4B006E
	Color: Night Shadz = AA375A
	Color: Red (ryb) = FE2712
	Color: Rich Blue = 021BF9
	Color: Wistful Mauve = 976F7B
	Color: Purple Magic = 693B71
	Color: Raspberry Rose = B3446C
	Color: Neon Purple = BC13FE
	Color: Pale Turquoise = A5FBD5
	Color: Purpley Blue = 5F34E7
	Color: University Of California Gold = B78727
	Color: Very Dark Blue = 000133
	Color: Salmon = FF8C69
	Color: Sandstone = C9AE74
	Color: Violet (ryb) = 8601AF
	Color: Papaya Whip = FFEFD5
	Color: Pacific Blue = 1CA9C9
	Color: Terra Cotta = C9643B
	Color: Purple/pink = D725DE
	Color: Yellow (ncs) = FFD300
	Color: Tangelo = F94D00
	Color: Purple Taupe = 50404D
	Color: Pale Cyan = B7FFFA
	Color: Tuscany = C09999
	Color: Spiro Disco Ball = 0FC0FC
	Color: Quicksilver = A6A6A6
	Color: Vomit = A2A415
	Color: Sapphire = 2138AB
	Color: Parchment = FEFCAF
	Color: Really Light Blue = D4FFFF
	Color: Slate Green = 658D6D
	Color: Toupe = C7AC7D
	Color: Pale Lime Green = B1FF65
	Color: Very Light Purple = F6CEFC
	Color: Wine Dregs = 673147
	Color: Pharlap = A3807B
	Color: Puke Yellow = C2BE0E
	Color: Timberwolf = DBD7D2
	Color: Peach Tan = B4745E
	Color: Rose Vale = AB4E52
	Color: Pear = D1E231
	Color: Poop Brown = 7A5901
	Color: Roman Silver = 838996
	Color: Navy = 01153E
	Color: Pink Sherbet = F78FA7
	Color: Sepia = 985E2B
	Color: Ufo Green = 3CD070
	Color: Pale Blue = D0FEFE
	Color: Steel Grey = 6F828A
	Color: Orangeish = FD8D49
	Color: Pixie Green = C0D8B6
	Color: Pale Light Green = B1FC99
	Color: Rabbit Eye = FF0033
	Color: Vivid Cerise = DA1D81
	Color: Rose Taupe = 905D5D
	Color: Pink/purple = EF1DE7
	Color: Red-violet = C71585
	Color: St. Patrick's Blue = 23297A
	Color: Twilight Mauve = 896F73
	Color: Silver Sand = BFC1C2
	Color: Violet Pink = FB5FFC
	Color: Purple = 800080
	Color: Traffic Purple = A03472
	Color: Onyx = 353839
	Color: Pale Olive Green = B1D27B
	Color: Unicorn = 9F91CF
	Color: Pale Lime = BEFD73
	Color: Rich Orange = FF681F
	Color: Rose White = FFF6F5
	Color: Yale Blue = 0F4D92
	Color: Up Maroon = 7B1113
	Color: Vivid Tangerine = FF9980
	Color: Warm Pink = FB5581
	Color: Pale Aqua = B8FFEB
	Color: Pullman Brown = 644117
	Color: Prussian Blue = 004577
	Color: Pale Light French Lavender = D8D0F5
	Color: Wintergreen Dream = 56887D
	Color: Ruby Red = 9B111E
	Color: Very Pale Green = CFFDBC
	Color: Red (pigment) = ED1C24
	Color: Online Lime = 4B8740
	Color: Pale Teal = 82CBB2
	Color: Orchid = DA70D6
	Color: Pinkish Purple = D648D7
	Color: Purply = 983FB2
	Color: Sickly Green = 94B21C
	Color: Powder Blue = B1D1FC
	Color: Old Silver = 848482
	Color: Ugly Green = 7A9703
	Color: Shadow = 8A795D
	Color: Sage = 87AE73
	Color: Tealish = 24BCA8
	Color: Sabria Pink = FC0585
	Color: Orangey Yellow = FDB915
	Color: Xanadu = 738678
	Color: Selago = F0EEFD
	Color: Sick Green = 9DB92C
	Color: Pale Blush = F4BBCF
	Color: Regalia = 522D80
	Color: Seaweed = 18D17B
	Color: Ocean Green = 3D9973
	Color: Pistachio = 93C572
	Color: Rosewood Light = B00049
	Color: Perfume = D0BEF8
	Color: Ucla Gold = FFB300
	Color: Yellow/green = C8FD3D
	Color: Upsdell Red = AE2029
	Color: Purple Brown = 673A3F
	Color: Orchid Mist = C3A6B1
	Color: Shit Green = 758000
	Color: Process Yellow = FFEF00
	Color: Purple Mountain Majesty = 9678B6
	Color: Sunny Yellow = FFF917
	Color: Studio = 714AB2
	Color: Very Dark Green = 062E03
	Color: Seance = 731E8F
	Color: Smitten = C84186
	Color: Rose Quartz = AA98A9
	Color: Very Dark Purple = 2A0134
	Color: Soft Blue = 6488EA
	Color: Violet Eggplant = 991199
	Color: Rosa = FE86A4
	Color: Warm Grey = 978A84
	Color: Patina Light = AFD0CA
	Color: Polished Pine = 5DA493
	Color: Rosy Brown Light = E2CACA
	Color: Rose = FF007F
	Color: Purplish Brown = 6B4247
	Color: Telemagenta = D72D6D
	Color: Periwinkle Blue = 8F99FB
	Color: Silver Pink = C4AEAD
	Color: Yellowgreen = BBF90F
	Color: Olive Green = 677A04
	Color: Pearl = EAE0C8
	Color: Veronica = A020F0
	Color: Olivine = 9AB973
	Color: Pakistan Green = 006600
	Color: Silver = C0C0C0
	Color: Tropical Rain Forest = 00755E
	Color: Purple Pizzazz = FE4EDA
	Color: Pale Italian Apricot = FFE6E6
	Color: Yellowish Brown = 9B7A01
	Color: Outer Space = 414A4C
	Color: Safety Orange (blaze Orange) = FF6700
	Color: Pine Green = 0A481E
	Color: Satin Sheen Gold = CBA135
	Color: Orange Brown = BE6400
	Color: Shadow Lime = D4E29B
	Color: United Nations Blue = 5B92E5
	Color: Violet Red = A50055
	Color: Very Light Brown = D3B683
	Color: Purple Reign = 54446C
	Color: Royal = 0C1793
	Color: True Green = 089404
	Color: Purple Blue = 632DE9
	Color: Pearly Purple = B768A2
	Color: Pale Lavender = EECFFE
	Color: Rust Brown = 8B3103
	Color: Orange (color Wheel) = FF7F00
	Color: Process Cyan = 00B7EB
	Color: Tree Green = 2A7E19
	Color: Usafa Blue = 004F98
	Color: Sunny Orange = FC5110
	Color: Slate Blue = 5B7C99
	Color: Raspberry Radiance = 82305A
	Color: Orangey Red = FA4224
	Color: Sandy = F1DA7A
	Color: Sugar Plum = 914E75
	Color: Violet Purple = 926EAE
	Color: Purpleish Blue = 6140EF
	Color: Orange = F97306
	Color: Rich Tyrian Purple = 9E0E40
	Color: Neon Blue = 04D9FF
	Color: Outrageous Orange = FF6E4A
	Color: Royal Azure = 0038A8
	Color: Pink Flamingo = FF66FF
	Color: Purplish Pink = CE5DAE
	Color: Purplish Red = B0054B
	Color: Turquoise Blue = 06B1C4
	Color: Tuscan Red = 7C4848
	Color: Rose Bonbon = F9429E
	Color: Sandstorm = ECD540
	Color: Yellow Green = C0FB2D
	Color: Pinkish Red = F10C45
	Color: Saffron = F4C430
	Color: Piggy Pink = FDDDE6
	Color: Red = FF0000
	Color: Navy Blue = 001146
	Color: Pale Taupe = BC987E
	Color: Ultra Green = 66FF66
	Color: Rich Carmine = D70040
	Color: Padua = ADE6C4
	Color: Taupe Brown = 674C47
	Color: Windows Blue = 3778BF
	Color: Pinkish Orange = FF724C
	Color: Reddish Purple = 910951
	Color: Rust Red = AA2704
	Color: Peach Schnapps = FFDCD6
	Color: Pictorial Carmine = C30B4E
	Color: Ube = 8878C3
	Color: Usumbara Chameleon Harlequin = 50B708
	Color: Ultramarine Blue = 1805DB
	Color: Orange Peel = FF9F00
	Color: Vegas Gold = C5B358
	Color: Very Light Pink = FFF4F2
	Color: Reddy Brown = 6E1005
	Color: Thulian Pink = DE6FA1
	Color: Rose Neyron = FF0057
	Color: Yellow (ryb) = FEFE33
	Color: Opera Mauve = CA82AF
	Color: Sky = 82CAFC
	Color: Simply Taupe = ABA092
	Color: Shit = 7F5F00
	Color: Ocean Blue = 03719C
	Color: Rich Lilac = B666D2
	Color: Seafoam Blue = 78D1B6
	Color: Rocket Metallic = 8A7F8D
	Color: Zinnwaldite Brown = 2C1608
	Color: Raspberry Wine = B63157
	Color: Ruddy Pink = E18E96
	Color: Watusi = FFDDCF
	Color: Pansy Purple = 78184A
	Color: Sunflower Yellow = FFDA03
	Color: Orangish Red = F43605
	Color: Poo = 8F7303
	Color: Teal = 008080
	Color: Tangerine = FF9408
	Color: Rouge Light = D58EB5
	Color: Pale Salmon = FFB19A
	Color: Pale Spring Bud = ECEBBD
	Color: Wild Orchid = D770A2
	Color: Peach Puff = FFDAB9
	Color: Spanish Crimson = E51A4C
	Color: Tea Green = BDF8A3
	Color: Taupe = 483C32
	Color: Teal Blue = 01889F
	Color: Purplish Grey = 7A687F
	Color: Navajo White = FFDEAD
	Color: Violet-blue = 324AB2
	Color: Radical Red = FF355E
	Color: White = FFFFFF
	Color: Yellow Mist = FFFFE0
	Color: Seafoam Green = 7AF9AB
	Color: Shocking Pink = FE02A2
	Color: Waterspout = A4F4F9
	Color: Pastel Green = B0FF9D
	Color: Rifle Green = 414833
	Color: Poo Brown = 885F01
	Color: Urobilin = E1AD21
	Color: Stormcloud = 4F666A
	Color: Purpley Pink = C83CB9
	Color: Spruce = 0A5F38
	Color: Steel = 738595
	Color: Red-brown = A52A2A
	Color: Non-photo Blue = A4DDED
	Color: Pastel Purple = CAA0FF
	Color: Raindrop = 33FFCC
	Color: Star Command Blue = 007BBB
	Color: Queen Blue = 436B95
	Color: Snot Green = 9DC100
	Color: Pigment Green = 00A550
	Color: Umber = 635147
	Color: Violet = 8F00FF
	Color: Persian Lilac = C17E91
	Color: Peach-orange = FFCC99
	Color: Pale Purple = B790D4
	Color: Old Pink = C77986
	Color: Tickle Me Pink = FC89AC
	Color: Zomp = 39A78E
	Color: Pale Brown = B1916E
	Color: Reddish Pink = FE2C54
	Color: Zaffre = 0014A8
	Color: Vulgar Purple = 3E2F84
	Color: Sandy Yellow = FDEE73
	Color: Signal Violet = 924E7D
	Color: Rich Maroon = B03060
	Color: Pansy = 7700FF
	Color: Vermilion = F34234
	Color: Platinum = E5E4E2
	Color: Peach Cream = FAD6A5
	Color: Pale Lilac = E4CBFF
	Color: New Silver = BFB8A5
	Color: Wintergreen = 20F986
	Color: Pinky Purple = C94CBE
	Color: Red Wine = 8C0034
	Color: Pear Sorbet = F4EED7
	Color: Vivid Plum = 9400A5
	Color: Pale Pink = FFCFDC
	Color: Ultramarine = 120A8F
	Color: Yellow Orange = FFAE42
	Color: Turkish Rose = B57281
	Color: Plum Purple = 4E0550
	Color: Reddish Orange = F8481C
	Color: Toxic Green = 61DE2A
	Color: Purple Wine = 8E3975
	Color: Violet-red = F7468A
	Color: Ou Crimson = 990000
	Color: Ukrainian Azure = 42ADDE
	Color: Ugly Blue = 31668A
	Color: Ugly Purple = A442A0
	Color: Thistle = D8BFD8
	Color: Vivid Purple = 9900FA
	Color: Royal Blue = 0504AA
	Color: Puke Green = 9AAE07
	Color: Rich Apricot = FAB5F7
	Color: Pale Lime Yellow = EAEDA6
	Color: Tan Green = A9BE70
	Color: Olivetone = 716E10
	Color: Rose Red = BE013C
	Color: Smokey Topaz = 933D41
	Color: Slate Gray = 708090
	Color: Raspberry Pink = E25098
	Color: Purpley Grey = 947E94
	Color: Pink Lace = FFDDF4
	Color: Pink Red = F5054F
	Color: Vivid Electric Blue = 00A5D2
	Color: Seaweed Green = 35AD6B
	Color: Phthalo Blue = 000F89
	Color: Safety Orange = FF6600
	Color: Vibrant Blue = 0339F8
	Color: Persian Indigo = 32127A
	Color: Toolbox = 746CC0
	Color: Vietnamese Mauve = 993366
	Color: Royal Maroon = 5A3839
	Color: Sinopia = CB410B
	Color: Vivid Orchid = CC00FF
	Color: Warm Purple = 952E8F
	Color: Pale Olive = B9CC81
	Color: Wine = 722F37
	Color: Red Brown = 8B2E16
	Color: Powder Pink = FFB2D0
	Color: Rosy Pink = F6688E
	Color: "Tangerine Yellow, Usc Gold" = FFCC00
	Color: Turtle Green = 75B84F
	Color: Tiger's Eye = E08D3C
	Color: Reddish Grey = 997570
	Color: Pinky = FC86AA
	Color: Rich Periwinkle = 9999FF
	Color: Strawberry = FB2943
	Color: Tea Rose = F4C2C2
	Color: Pale Peach = FFE5AD
	Color: Sunflower = FFC512
	Color: Off Blue = 5684AE
	Color: Palatinate Blue = 273BE2
	Color: Sacramento State Green = 00563F
	Color: Sun Yellow = FFDF22
	Color: Ruddy Brown = BB6528
	Color: Pale Silver = C9C0BB
	Color: Rouge Red = E44165
	Color: Pale Grey = FDFDFE
	Color: Peach Bisque = A87C6D
	Color: Pink Light = FFE4E9
	Color: Winter Pear = 8A9A5B
	Color: Sand = C2B280
	Color: Poison Green = 40FD14
	Color: Pig Pink = E78EA5
	Color: Pale Magenta = D767AD
	Color: Process Magenta = FF0090
	Color: Vibrant Purple = AD03DE
	Color: Pink Pearl = E7ACCF
	Color: Pastel Orange = FF964F
	Color: Soft Pink = FDB0C0
	Color: Razzmatazz = E3256B
	Color: Olive = 6E750E
	Color: Unbleached Silk = FFDDCA
	Color: Pale Orange = FFA756
	Color: Prince Fan Purple = 6600B7
	Color: Ua Red = D9004C
	Color: Vibrant Green = 0ADD08
	Color: Rich Lavender = A76BCF
	Color: Rose Ebony = 674846
	Color: Petrol = 005F6A
	Color: Pearl Aqua = 88D8C0
	Color: Sunglow = FFCC33
	Color: Peach = FFE5B4
	Color: Pinkish Grey = C8ACA9
	Color: Yellow (munsell) = EFCC00
	Color: Supernova = FFC901
	Color: Straw = E4D96F
	Color: Vomit Yellow = C7C10C
	Color: Pale Persian Lilac = D597AE
	Color: Tomato Red = EC2D01
	Color: Yellowy Green = BFF128
	Color: Red Pink = FA2A55
	Color: Tuscan Tan = A67B5B
	Color: Pinkish Tan = D99B82
	Color: Yellowish Tan = FCFC81
	Color: Swamp = 698339
	Color: Tan = D1B26F
	Color: Pastel Magenta = F49AC2
	Color: Purple Pink = E03FD8
	Color: Seal Brown = 321414
	Color: Rust = B7410E
	Color: Victoria Plum = 002C39
	Color: Pale Amaranth Pink = DDBEC3
	Color: Raw Umber = A75E09
	Color: Ultra Blue = A3E3ED
	Color: Striking Purple = 98508E
	Color: Pale Blue-green = 00DDDD
	Color: Office Green = 008000
	Color: Pale Copper = DA8A67
	Color: Nyanza = E9FFDB
	Color: Purpleish Pink = DF4EC8
	Color: Water Blue = 0E87CC
	Color: Robin's Egg = 6DEDFD
	Color: Wine Red = 7B0323
	Color: Neon Pink = FE019A
	Color: Tokyo Purple = 5A004A
	Color: Twilight Blue = 0A437A
	Color: Pine = 2B5D34
	Color: Pontiff = AF00FF
	Color: Pink Champagne = F1DDCF
	Color: Pink = FF81C0
	Color: Napier Green = 3B7E00
	Color: Rusty Red = AF2F0D
	Color: Ugly Brown = 7D7103
	Color: Warm Black = 004242
	Color: Orange Pink = FF6F52
	Color: Persian Rose = FE28A2
	Color: Peach Blossom Pink = EA9399
	Color: Sheen Green = 8FD400
	Color: Primary Blue = 0804F9
	Color: Pinky Red = FC2647
	Color: Raspberry = B00149
	Color: Ua Blue = 0033AA
	Color: Spanish Carmine = D10047
	Color: Pearl Violet = 8683A1
	Color: Pumpkin Orange = FB7D07
	Color: Reddish = C44240
	Color: Off Green = 6BA353
	Color: Old Gold = CFB53B
	Color: Washed Out Green = BCF5A6
	Color: Pale Cornflower Blue = ABCDEF
	Color: Orange (web Color) = FFA500
	Color: Purple Grey = 866F85
	Color: Rubine Red = D10056
	Color: Slime Green = 99CC04
	Color: Shit Brown = 7B5804
	Color: Ochre = CC7722
	Color: Sky Blue = 75BBFD
	Color: Turquoise Green = 04F489
	
	In the HashSC class:
	
	Table Size = 797
	Number of entries = 770
	Load factor = 0.9661229611041405
	Number of collisions = 353
	Longest Linked List = 4
	
	Result of calling contains for Pink Lace in HashQP = true
	Result of calling contains for Pink Lace in HashSC = true
	Result of calling contains for Sunflower in HashQP = true
	Result of calling contains for Sunflower in HashSC = true
	Retrieved in HashQP, Color: Pink Lace, now trying to delete it
	Successfully removed from HashQP: Pink Lace
	Retrieved in HashSC, Color: Sunflower, now trying to delete it
	Successfully removed from HashSC: Sunflower
	
	HashQP with the int key now has:
	2 Color: Pale Gold = FDDE6C
	3 Color: Toupe = C7AC7D
	6 Color: Violet Tulle = C693C7
	10 Color: Pale Chestnut = DDADAF
	12 Color: Rusty Red = AF2F0D
	13 Color: Rose White = FFF6F5
	15 Color: Sand Brown = CBA560
	18 Color: Sunflower = FFC512
	19 Color: Sunshine Yellow = FFFD37
	21 Color: Purple/pink = D725DE
	22 Color: Vibrant Purple = AD03DE
	25 Color: Orangey Yellow = FDB915
	26 Color: Pictorial Carmine = C30B4E
	27 Color: Purple Blue = 632DE9
	29 Color: Pale Green-yellow = F1E788
	30 Color: Sickly Green = 94B21C
	34 Color: Pale Green = C7FDB5
	35 Color: New York Pink = D7837F
	36 Color: Red Pink = FA2A55
	37 Color: True Green = 089404
	38 Color: Purple Pizzazz = FE4EDA
	42 Color: Steel Grey = 6F828A
	43 Color: Vegas Gold = C5B358
	44 Color: Vivid Tangerine = FF9980
	49 Color: Pale Light Green = B1FC99
	51 Color: Vomit Green = 89A203
	52 Color: Taupe Brown = 674C47
	54 Color: Silver Chalice = ACACAC
	55 Color: Vivid Violet = 9F00FF
	59 Color: Vermillion = F4320C
	63 Color: Soft Purple = A66FB5
	64 Color: Palatinate Blue = 273BE2
	66 Color: Orchid Ice = DFD2DF
	67 Color: Turkish Rose = B57281
	73 Color: School Bus Yellow = FFD800
	74 Color: Warm Brown = 964E02
	75 Color: Wine Red = 7B0323
	76 Color: Olive Drab = 6F7632
	79 Color: Orange Brown = BE6400
	80 Color: Seafoam Blue = 78D1B6
	81 Color: Pearl Violet = 8683A1
	83 Color: Shiraz = B20931
	84 Color: Very Light Brown = D3B683
	90 Color: Water = 96ABA5
	91 Color: Simply Taupe = ABA092
	93 Color: Vivid Green = 2FEF10
	94 Color: Wintergreen Dream = 56887D
	96 Color: Ruby = E0115F
	97 Color: Shamrock Green = 02C14D
	99 Color: Pale Grey = FDFDFE
	100 Color: Red Violet = 9E0168
	103 Color: Ua Red = D9004C
	104 Color: Urobilin = E1AD21
	105 Color: Seal Brown = 321414
	106 Color: Pinkish Grey = C8ACA9
	114 Color: Purple Reign = 54446C
	118 Color: Orange Tan = FAA76C
	130 Color: Pistachio = 93C572
	131 Color: Royal Azure = 0038A8
	133 Color: Robin's Egg Blue = 98EFF9
	135 Color: Powder Pink = FFB2D0
	136 Color: Purply Blue = 661AEE
	142 Color: Pale Goldenrod = EEE8AA
	143 Color: Victoria Plum = 002C39
	146 Color: Peach-yellow = FADFAD
	147 Color: Pea Soup Green = 94A617
	148 Color: Primary Blue = 0804F9
	149 Color: Neon Blue = 04D9FF
	153 Color: Thulian Pink = DE6FA1
	160 Color: Outrageous Orange = FF6E4A
	178 Color: Rich Orange = FF681F
	183 Color: Ucla Gold = FFB300
	184 Color: Pink Light = FFE4E9
	185 Color: Navajo White = FFDEAD
	186 Color: Silver Sand = BFC1C2
	188 Color: Old Silver = 848482
	192 Color: Pale Blush = F4BBCF
	194 Color: Rich Tyrian Purple = 9E0E40
	195 Color: Red Devil = 860111
	196 Color: Purpley Pink = C83CB9
	198 Color: Pale Lilac = E4CBFF
	199 Color: Ruddy Brown = BB6528
	202 Color: Tyrian Purple = 66023C
	204 Color: "Tangerine Yellow, Usc Gold" = FFCC00
	205 Color: Pullman Brown = 644117
	211 Color: Yellow (ryb) = FEFE33
	214 Color: Pale Lavender = EECFFE
	215 Color: Off Green = 6BA353
	216 Color: Prussian Blue = 004577
	217 Color: Violet Purple = 926EAE
	218 Color: Pale Violet Red = DB7093
	219 Color: Windsor Tan = AE6838
	226 Color: Orchid = DA70D6
	227 Color: Purple Brown = 673A3F
	235 Color: Seance = 731E8F
	237 Color: Studio = 714AB2
	238 Color: Violet Red = A50055
	240 Color: Neon Purple = BC13FE
	241 Color: Platinum = E5E4E2
	242 Color: Sonic Silver = 757575
	243 Color: Peach Bisque = A87C6D
	244 Color: Pink Sherbet = F78FA7
	245 Color: Night Shadz = AA375A
	246 Color: Orange Yellow = FFAD01
	247 Color: Sunglow = FFCC33
	248 Color: Pigment Blue = 333399
	249 Color: Persian Orange = D99058
	251 Color: Shadow Lime = D4E29B
	252 Color: Zinnwaldite Brown = 2C1608
	256 Color: Tangerine = FF9408
	258 Color: Olive Brown = 645403
	268 Color: Tuscan Red = 7C4848
	270 Color: Ruddy Pink = E18E96
	278 Color: Vintage Indigo = 664D64
	282 Color: Robin's Egg = 6DEDFD
	283 Color: Selago = F0EEFD
	285 Color: Salmon Pink = FE7B7C
	289 Color: Wintergreen = 20F986
	293 Color: Phthalo Green = 123524
	294 Color: Purple Orchid = AE4F93
	297 Color: Pale Persian Lilac = D597AE
	298 Color: Pastel Violet = A47D90
	301 Color: Twilight Blue = 0A437A
	302 Color: Rust = B7410E
	303 Color: Sun Yellow = FFDF22
	305 Color: Pumpkin = FF7518
	306 Color: Veronica = A020F0
	307 Color: Very Dark Blue = 000133
	309 Color: Peachy Pink = FF9A8A
	311 Color: Ocean Boat Blue = 0077BE
	312 Color: Orangish = FC824A
	313 Color: Wild Lime = CBD862
	314 Color: Toxic Green = 61DE2A
	315 Color: Sabria Pink = FC0585
	317 Color: Old Burgundy = 43302E
	319 Color: Powder Blue = B1D1FC
	320 Color: Vivid Strawberry = F70077
	327 Color: Red Wine = 8C0034
	329 Color: Rich Lilac = B666D2
	332 Color: Pastel Yellow = FFFE71
	333 Color: Saddle Brown = 8B4513
	337 Color: Wenge = 645452
	338 Color: Wisteria = C9A0DC
	340 Color: Terracota = CB6843
	342 Color: Rich Raspberry = D72D5C
	346 Color: Old Lavender = 796878
	347 Color: Rose Red = BE013C
	348 Color: Peach-orange = FFCC99
	351 Color: Pink = FF81C0
	352 Color: Tea = 65AB7C
	353 Color: Violet (ryb) = 8601AF
	355 Color: Royal = 0C1793
	359 Color: Telemagenta = D72D6D
	374 Color: Tea Rose = F4C2C2
	376 Color: Pink Pearl = E7ACCF
	378 Color: Selective Yellow = FFBA00
	380 Color: Pale Peach = FFE5AD
	381 Color: Rouge = AB1239
	383 Color: Pale Copper = DA8A67
	386 Color: Silver Pink = C4AEAD
	387 Color: Peach = FFE5B4
	389 Color: Raw Umber = A75E09
	390 Color: Periwinkle = 8E82FE
	391 Color: Pale Orange = FFA756
	394 Color: Yellow (ncs) = FFD300
	395 Color: Ugly Blue = 31668A
	396 Color: Unicorn = 9F91CF
	399 Color: Pink Purple = DB4BDA
	400 Color: Smokey Topaz = 933D41
	401 Color: Pastel Red = DB5856
	402 Color: Pacific Blue = 1CA9C9
	403 Color: Sienna = 882D17
	405 Color: Poo Brown = 885F01
	406 Color: Slate = 516572
	410 Color: Rich Maroon = B03060
	412 Color: Nice Blue = 107AB0
	413 Color: Purplish Grey = 7A687F
	414 Color: Pale Robin Egg Blue = 96DED1
	416 Color: Racing Green = 014600
	417 Color: Sickly Yellow = D0E429
	420 Color: Purple Taupe = 50404D
	421 Color: Wild Strawberry = FF43A4
	424 Color: Orange Pink = FF6F52
	426 Color: Rich Purple = 720058
	427 Color: Red (pigment) = ED1C24
	428 Color: Very Light Purple = F6CEFC
	429 Color: Raspberry Pink = E25098
	430 Color: Navy Green = 35530A
	432 Color: Pastel Purple = CAA0FF
	435 Color: Sheen Green = 8FD400
	436 Color: Soft Green = 6FC276
	442 Color: Queen Pink = E8CC07
	444 Color: Straw = E4D96F
	445 Color: Verdigris = 43B3AE
	446 Color: Pale Olive Green = B1D27B
	449 Color: Up Maroon = 7B1113
	450 Color: Ua Blue = 0033AA
	453 Color: Yellowish Brown = 9B7A01
	456 Color: Water Blue = 0E87CC
	457 Color: Rose Taupe = 905D5D
	458 Color: Pale Cerulean = 9BC4E2
	459 Color: Vomit = A2A415
	461 Color: Persian Blue = 1C39BB
	471 Color: Petrol = 005F6A
	472 Color: Usumbara Chameleon Harlequin = 50B708
	474 Color: Perfume = D0BEF8
	475 Color: Vomit Yellow = C7C10C
	477 Color: Tiffany Blue = 0ABAB5
	478 Color: Rich Black = 004040
	479 Color: North Texas Green = 059033
	480 Color: Pear Sorbet = F4EED7
	484 Color: Sapphire = 2138AB
	485 Color: Peach Tan = B4745E
	486 Color: Sunny Orange = FC5110
	487 Color: Peach Blossom Pink = EA9399
	494 Color: Taupe = 483C32
	495 Color: Ukrainian Azure = 42ADDE
	497 Color: Outer Space = 414A4C
	498 Color: Vivid Blue = 152EFF
	499 Color: Screamin' Green = 76FF7A
	501 Color: Zaffre = 0014A8
	502 Color: Palatinate Purple = 682860
	503 Color: Pumpkin Orange = FB7D07
	508 Color: Traffic Purple = A03472
	512 Color: Pale Silver = C9C0BB
	513 Color: Very Pale Green = CFFDBC
	515 Color: Ocean Blue = 03719C
	516 Color: Regalia = 522D80
	517 Color: Washed Out Green = BCF5A6
	518 Color: Ocre = C69C04
	519 Color: Tan = D1B26F
	521 Color: Rosebud Cherry = 892D52
	522 Color: Pansy Purple = 78184A
	523 Color: Neon Green = 0CFF0C
	524 Color: Waterspout = A4F4F9
	525 Color: Pale Cornflower Blue = ABCDEF
	526 Color: Yellow = FFFF33
	534 Color: Oxford Blue = 002147
	535 Color: Slate Blue = 5B7C99
	536 Color: Stormcloud = 4F666A
	539 Color: Royal Maroon = 5A3839
	540 Color: Rich Periwinkle = 9999FF
	541 Color: Snot = ACBB0D
	543 Color: Vanda = 9842E3
	544 Color: Tomato = FF6347
	545 Color: Purplish = 94568C
	546 Color: Satin Sheen Gold = CBA135
	549 Color: Princeton Orange = FF8F00
	550 Color: Scuba Blue = D0B2CA
	554 Color: Sky = 82CAFC
	555 Color: Turquoise Green = 04F489
	559 Color: Sunny Yellow = FFF917
	560 Color: Pakistan Green = 006600
	561 Color: Purplish Red = B0054B
	566 Color: Yellow Orange = FFAE42
	569 Color: Slime Green = 99CC04
	570 Color: Yellow Green = C0FB2D
	571 Color: Ultramarine = 120A8F
	576 Color: Zydeco = 02402C
	577 Color: Unmellow Yellow = FFFF66
	582 Color: Olive Green = 677A04
	583 Color: Pastel Pink = FFBACD
	584 Color: Orchid Pink = F2BDCD
	585 Color: Tropical Green = 008B87
	587 Color: Squash = F2AB15
	588 Color: Sunflower Yellow = FFDA03
	593 Color: Tokyo Purple = 5A004A
	597 Color: Royal Blue (web) = 4169E1
	598 Color: Ultra Pink = FF6FFF
	603 Color: Napier Green = 3B7E00
	605 Color: Tickle Me Pink = FC89AC
	606 Color: Rich Pink-orange = ED999C
	607 Color: Pale Yellow = FFFF84
	611 Color: Ube = 8878C3
	612 Color: Padua = ADE6C4
	614 Color: Razzmatazz = E3256B
	619 Color: Taos Taupe = BFAA80
	620 Color: Windows Blue = 3778BF
	623 Color: Plum (traditional) = 8E4585
	624 Color: Rose Ebony = 674846
	625 Color: Sandstone = C9AE74
	626 Color: Very Dark Brown = 1D0200
	627 Color: Pale Taupe = BC987E
	628 Color: Pale Canary Yellow = FFFF99
	636 Color: Psychedelic Purple = DF00FF
	637 Color: Raw Sienna = 9A6200
	639 Color: Pig Pink = E78EA5
	640 Color: Sangria = 92000A
	642 Color: Slate Green = 658D6D
	644 Color: Vibrant Blue = 0339F8
	647 Color: Rich Apricot = FAB5F7
	651 Color: Purple Magic = 693B71
	652 Color: Pale Rose = FDC1C5
	657 Color: Opera Mauve = CA82AF
	658 Color: Ugly Pink = CD7584
	665 Color: Viridian = 1E9167
	666 Color: Olivine = 9AB973
	667 Color: Peach Sand = C1B6B3
	669 Color: Persian Lilac = C17E91
	672 Color: Red = FF0000
	677 Color: Rosebloom = E38FB7
	680 Color: University Of California Gold = B78727
	683 Color: Turquoise = 06C2AC
	691 Color: Violet-red = F7468A
	692 Color: Patina = 639A8F
	693 Color: Pale Italian Apricot = FFE6E6
	696 Color: Puce = CC8899
	699 Color: Spanish Fuchsia = E30052
	700 Color: Vivid Carmine Pink = FF5771
	703 Color: Paars = AA00FF
	704 Color: Off White = FFFFE4
	705 Color: Rose Violet = C24C92
	706 Color: Navy = 01153E
	707 Color: Violet = 8F00FF
	708 Color: Yellow Mist = FFFFE0
	709 Color: Sand Yellow = FCE166
	712 Color: Off Blue = 5684AE
	713 Color: Pinky Red = FC2647
	716 Color: Ruddy = FF0028
	717 Color: Wistful Mauve = 976F7B
	721 Color: Online Lime = 4B8740
	722 Color: Rich Lavender = A76BCF
	723 Color: Rabbit Eye = FF0033
	725 Color: Yellowish = FAEE66
	727 Color: Pale Teal = 82CBB2
	729 Color: Purple Wine = 8E3975
	730 Color: Sky Blue = 75BBFD
	731 Color: White = FFFFFF
	733 Color: Steel Blue = 5A7D9A
	734 Color: Pink Champagne = F1DDCF
	740 Color: Saffron = F4C430
	742 Color: Pale Turquoise = A5FBD5
	744 Color: Pale = FFF9D0
	745 Color: Seaweed = 18D17B
	750 Color: Rose Gold = B76E79
	751 Color: Ruby Red = 9B111E
	755 Color: Purple Heart = 69359C
	756 Color: Violet Eggplant = 991199
	759 Color: Rose Neyron = FF0057
	760 Color: Pale Light French Lavender = D8D0F5
	762 Color: Pastel Green = B0FF9D
	763 Color: Reddish Grey = 997570
	764 Color: White Smoke = F5F5F5
	765 Color: Pale Lime Green = B1FF65
	769 Color: Orange-red = FF4500
	770 Color: Process Cyan = 00B7EB
	771 Color: Peach Puff = FFDAB9
	772 Color: Sick Green = 9DB92C
	773 Color: Piss Yellow = DDD618
	774 Color: Rich Spring Green = 00E39A
	775 Color: Yellow Brown = B79400
	782 Color: Reddish Pink = FE2C54
	783 Color: Purpleish = 98568D
	784 Color: Phthalo Blue = 000F89
	786 Color: Spiro Disco Ball = 0FC0FC
	787 Color: Terra Cotta = C9643B
	794 Color: Paradise Pink = E63E62
	795 Color: Violent Violet = 290C5E
	798 Color: Pigment Green = 00A550
	799 Color: Rose = FF007F
	805 Color: Pale Electric Hollywood Cerise = FFC1E8
	811 Color: Olive Yellow = C2B709
	812 Color: Pale Spring Bud = ECEBBD
	813 Color: Rich Magenta = CA1F7B
	814 Color: Purple Pink = E03FD8
	816 Color: Process Magenta = FF0090
	817 Color: Radiant Orchid = B163A3
	818 Color: Purplish Blue = 601EF9
	823 Color: Pastel Orange = FF964F
	828 Color: Office Green = 008000
	830 Color: Smoky Black = 100C08
	831 Color: Tenn (tawny) = CD5700
	835 Color: Red Brown = 8B2E16
	841 Color: Neon Yellow = CFFF04
	844 Color: Striking Purple = 98508E
	845 Color: Pine = 2B5D34
	846 Color: Seafoam Green = 7AF9AB
	847 Color: Pale Rose Light = FFF3FA
	848 Color: Pale Red = D9544D
	849 Color: Yellow (munsell) = EFCC00
	852 Color: Pearly Purple = B768A2
	854 Color: Rust Red = AA2704
	859 Color: Tumbleweed = DEAA88
	864 Color: Taupe Gray = 8B8589
	866 Color: Tangelo = F94D00
	870 Color: Rocket Metallic = 8A7F8D
	873 Color: Puke = A5A502
	874 Color: Puke Brown = 947706
	875 Color: Rosewood Light = B00049
	877 Color: Slate Grey = 59656D
	879 Color: Scarlet = FF2000
	882 Color: Red-orange = FF3F34
	883 Color: Shadow = 8A795D
	884 Color: Raspberry Radiance = 82305A
	885 Color: Powder Blue (web) = B0E0E6
	886 Color: Starship = ECF245
	888 Color: Pansy = 7700FF
	889 Color: Vivid Burgundy = 9F1D35
	891 Color: Rich Blue = 021BF9
	892 Color: Ultra Blue = A3E3ED
	893 Color: Purple Rain = 4B308D
	894 Color: Pale Blue = D0FEFE
	895 Color: Strong Blue = 0C06F7
	898 Color: Pale Magenta = D767AD
	899 Color: Tan Brown = AB7E4C
	901 Color: True Blue = 0073CF
	902 Color: Pale Blue-green = 00DDDD
	903 Color: Spring Bud = A7FC00
	904 Color: Teal Green = 25A36F
	910 Color: Tufts Blue = 417DC1
	911 Color: Sandy Yellow = FDEE73
	912 Color: Vivid Plum = 9400A5
	913 Color: Olive Drab 7 = 3C341F
	914 Color: Tealish = 24BCA8
	919 Color: Pale Sky Blue = BDF6FE
	922 Color: Purplish Brown = 6B4247
	925 Color: Neon Red = FF073A
	928 Color: Raspberry Rose = B3446C
	929 Color: Vivid Electric Blue = 00A5D2
	930 Color: Pinkish Purple = D648D7
	931 Color: Sunny Lime = E2EE83
	932 Color: Quartz = 51484F
	933 Color: Plaza Taupe = A79E8B
	934 Color: Yellow-green = 9ACD32
	936 Color: Puke Green = 9AAE07
	941 Color: Upsdell Red = AE2029
	942 Color: Vermilion = F34234
	944 Color: Reddish Brown = 7F2B0A
	948 Color: Red (ncs) = C40233
	954 Color: Very Dark Green = 062E03
	956 Color: Teal = 008080
	958 Color: Pigment Violet = 9400D3
	962 Color: Persian Pink = F77FBE
	967 Color: Prelude = D0C0E5
	968 Color: Swamp Green = 748500
	970 Color: Royal Fuchsia = CA2C92
	981 Color: Sapphire Blue = 0067A5
	985 Color: Pale Olive = B9CC81
	986 Color: Pharlap = A3807B
	992 Color: Warm Black = 004242
	993 Color: Nyanza = E9FFDB
	995 Color: Pink/purple = EF1DE7
	996 Color: Ugly Yellow = D0C101
	997 Color: Supernova Light = FFE816
	998 Color: Pontiff = AF00FF
	1000 Color: Watermelon = FD4659
	1001 Color: Torch Red = FD0E35
	1002 Color: Purplish Pink = CE5DAE
	1004 Color: Strong Pink = FF0789
	1005 Color: Ufo Green = 3CD070
	1009 Color: Rainshower = EDFEFF
	1010 Color: Reddy Brown = 6E1005
	1011 Color: Puke Yellow = C2BE0E
	1012 Color: Raspberry Wine = B63157
	1013 Color: Non-photo Blue = A4DDED
	1015 Color: Spruce = 0A5F38
	1016 Color: Ochre = CC7722
	1018 Color: Orange = F97306
	1021 Color: Teal Deer = 99E6B3
	1023 Color: Neon Pink = FE019A
	1024 Color: Peacock Blue = 016795
	1025 Color: Soft Blue = 6488EA
	1026 Color: Supernova = FFC901
	1028 Color: Peach Cream = FAD6A5
	1029 Color: "Persian Plum, Prune" = 701C1C
	1033 Color: Red (ryb) = FE2712
	1034 Color: Pale Lime = BEFD73
	1035 Color: Pastel Lavender = E0B0FF
	1042 Color: Ou Crimson = 990000
	1043 Color: Shit Brown = 7B5804
	1046 Color: New Silver = BFB8A5
	1047 Color: Velvet = 750851
	1051 Color: Snow = FFFAFA
	1053 Color: Pale Violet = CEAEFA
	1054 Color: Violet Pink = FB5FFC
	1057 Color: Steel = 738595
	1058 Color: Titanium Yellow = EEE600
	1066 Color: Skobeloff = 007474
	1067 Color: Vivid Auburn = 922724
	1068 Color: Pea Green = 8EAB12
	1069 Color: Westminster = 5F00FF
	1070 Color: Sandy Taupe = 967117
	1071 Color: Yellow Ochre = CB9D06
	1076 Color: Orangish Red = F43605
	1077 Color: Night Blue = 040348
	1079 Color: Spanish Crimson = E51A4C
	1082 Color: Pearl = EAE0C8
	1086 Color: Soft Pink = FDB0C0
	1091 Color: Swedish Azure = 005B99
	1093 Color: Venetian Red = C80815
	1095 Color: Very Light Pink = FFF4F2
	1096 Color: Umber = 635147
	1097 Color: Timberwolf = DBD7D2
	1108 Color: Sap Green = 5C8B15
	1109 Color: Space Cadet = 1D2951
	1110 Color: Resolution Blue = 002387
	1112 Color: Pure Blue = 0203E2
	1113 Color: Pea = A4BF20
	1116 Color: Old Gold = CFB53B
	1117 Color: Rufous = A81C07
	1121 Color: Persian Green = 00A693
	1125 Color: Wine Dregs = 673147
	1127 Color: Wild Watermelon = FC6C85
	1128 Color: Vivid Orchid = CC00FF
	1131 Color: Raspberry = B00149
	1132 Color: Ultra Green = 66FF66
	1135 Color: Nasty Green = 70B23F
	1136 Color: Sepia = 985E2B
	1140 Color: Yellowy Green = BFF128
	1141 Color: Ugly Green = 7A9703
	1142 Color: Tuscany = C09999
	1144 Color: Red-violet Eggplant = 990066
	1145 Color: Very Light Green = D1FFBD
	1146 Color: Turquoise Blue = 06B1C4
	1147 Color: Steel Teal = 5F8A8B
	1148 Color: Toolbox = 746CC0
	1149 Color: Poo = 8F7303
	1150 Color: Radioactive Green = 2CFA1F
	1151 Color: Queen Blue = 436B95
	1152 Color: Reddish Orange = F8481C
	1153 Color: Rich Carmine Red = EB003C
	1155 Color: Pastel Brown = 836953
	1156 Color: Razzle Dazzle Rose = FF33CC
	1157 Color: Royal Heath = AB3472
	1158 Color: Peridot = E6E200
	1161 Color: Violet Blue = 510AC9
	1162 Color: Pinky Purple = C94CBE
	1170 Color: Process Yellow = FFEF00
	1171 Color: Plum Purple = 4E0550
	1172 Color: Ugly Brown = 7D7103
	1174 Color: Thistle = D8BFD8
	1179 Color: Rosewood = 65000B
	1180 Color: Snot Green = 9DC100
	1181 Color: Ugly Purple = A442A0
	1182 Color: Pale Lime Yellow = EAEDA6
	1183 Color: Pale Pink = FFCFDC
	1186 Color: Pinkish Orange = FF724C
	1188 Color: Persian Red = CC3333
	1189 Color: Rajah = FBAB60
	1190 Color: Popstar = BE4F62
	1191 Color: Rouge Light = D58EB5
	1192 Color: Pale Amaranth Pink = DDBEC3
	1193 Color: Slate Gray = 708090
	1195 Color: Yellowy Brown = AE8B0C
	1198 Color: Very Dark Purple = 2A0134
	1200 Color: Peach Beige = C09396
	1201 Color: Rose Quartz = AA98A9
	1202 Color: Seafoam = 80F9AD
	1209 Color: Seaweed Green = 35AD6B
	1211 Color: Purpley Grey = 947E94
	1212 Color: Usafa Blue = 004F98
	1214 Color: Poop = 7F5E00
	1216 Color: Pastel Blue = A2BFFE
	1221 Color: Old Lace = FDF5E6
	1222 Color: Tree Green = 2A7E19
	1223 Color: Purply Pink = F075E6
	1224 Color: Spanish Carmine = D10047
	1228 Color: Navy Blue = 001146
	1229 Color: Pearl Aqua = 88D8C0
	1230 Color: Stormy Blue = 507B9C
	1231 Color: Tan Green = A9BE70
	1232 Color: Safety Orange = FF6600
	1235 Color: Sirocco ) = 718080
	1237 Color: Poop Brown = 7A5901
	1238 Color: Rubine Red = D10056
	1243 Color: Wheat = FBDD7E
	1244 Color: Orange (color Wheel) = FF7F00
	1246 Color: Wine = 722F37
	1247 Color: Sand = C2B280
	1248 Color: Tealish Green = 0CDC73
	1250 Color: Warm Grey = 978A84
	1251 Color: Vivid Cerise = DA1D81
	1254 Color: Orange Red = FD411E
	1256 Color: Yellowish Tan = FCFC81
	1258 Color: Topaz = 13BBAF
	1267 Color: Sage Green = 88B378
	1268 Color: Pale Cyan = B7FFFA
	1278 Color: Orange (ryb) = FB9902
	1279 Color: Vibrant Green = 0ADD08
	1280 Color: Red-violet = C71585
	1284 Color: Xanadu = 738678
	1287 Color: Shocking Pink = FE02A2
	1288 Color: Orangish Brown = B25F03
	1289 Color: Plum = 843179
	1292 Color: Persian Indigo = 32127A
	1293 Color: Purple = 800080
	1296 Color: Nightclub = 660045
	1299 Color: Rose White Light = FFFBFB
	1300 Color: Tropical Rain Forest = 00755E
	1301 Color: Vivid Purple = 9900FA
	1305 Color: Polished Pine = 5DA493
	1306 Color: Olivetone = 716E10
	1311 Color: Peach Schnapps = FFDCD6
	1312 Color: Pale Aqua = B8FFEB
	1313 Color: Pastel Magenta = F49AC2
	1314 Color: Sea Green = 20B2AA
	1315 Color: Violet-blue = 324AB2
	1318 Color: Persimmon = EC5800
	1319 Color: Purply = 983FB2
	1321 Color: Purple Grey = 866F85
	1322 Color: Olive = 6E750E
	1324 Color: Rich Mauve = E285FF
	1325 Color: Rich Electric Blue = 0892D0
	1327 Color: Sacramento State Green = 00563F
	1328 Color: Purple Plum = 9C5186
	1329 Color: Pixie Green = C0D8B6
	1330 Color: Old Pink = C77986
	1331 Color: Old Rose = C87F89
	1332 Color: Sea = 3C9992
	1333 Color: Rosso Corsa = D40000
	1334 Color: Rich Brilliant Lavender = F1A7FE
	1335 Color: Sea Blue = 047495
	1336 Color: Star Command Blue = 007BBB
	1337 Color: Utah Crimson = D3003F
	1339 Color: Orangey Red = FA4224
	1340 Color: Peach Red = F99379
	1341 Color: Royal Purple = 4B006E
	1342 Color: Steel Pink = CC33CC
	1343 Color: Shit Green = 758000
	1344 Color: Tea Green = BDF8A3
	1345 Color: Winter Pear = 8A9A5B
	1346 Color: Vivid Lavender = DF73FF
	1347 Color: Seashell = FFF5EE
	1348 Color: Ultra Orange = FF6037
	1350 Color: Ocean = 017B92
	1351 Color: Rusty Orange = CD5909
	1352 Color: Quicksilver = A6A6A6
	1353 Color: Wild Blue Yonder = A2ADD0
	1354 Color: Ultramarine Blue = 1805DB
	1355 Color: Rosy Pink = F6688E
	1358 Color: Reddish Purple = 910951
	1360 Color: Pale Brown = B1916E
	1361 Color: Ocean Green = 3D9973
	1362 Color: Pigment Indigo = 4B0082
	1363 Color: Ucla Blue = 536895
	1364 Color: Rich Harlequin = 3AE500
	1365 Color: Red-brown = A52A2A
	1366 Color: Yellowgreen = BBF90F
	1367 Color: Purple/blue = 5D21D0
	1368 Color: Rosy Brown Light = E2CACA
	1369 Color: Purple Red = 990147
	1373 Color: Terracotta = CA6641
	1375 Color: Reddish = C44240
	1376 Color: Violet (color Wheel) = 7F00FF
	1377 Color: Rose Pink = F7879A
	1380 Color: Warm Blue = 4B57DB
	1381 Color: Warm Taupe = B29784
	1383 Color: Neon Fuchsia = FE4164
	1384 Color: Papaya Whip = FFEFD5
	1385 Color: Purpleish Pink = DF4EC8
	1386 Color: Turtle Green = 75B84F
	1387 Color: Really Light Blue = D4FFFF
	1389 Color: Perrywinkle = 8F8CE7
	1390 Color: Orange (web Color) = FFA500
	1391 Color: Pinkish Red = F10C45
	1392 Color: Rust Orange = C45508
	1393 Color: Rose Vale = AB4E52
	1394 Color: Twilight Lavender = 8A496B
	1395 Color: Sky Magenta = CF71AF
	1396 Color: Pinkish Brown = B17261
	1402 Color: Rose Bonbon = F9429E
	1403 Color: Pastel Taupe = AF9E89
	1405 Color: Yaffle Green = CECF72
	1406 Color: Yellow Tan = FFE36E
	1408 Color: Portland Orange = FF5A36
	1410 Color: Prince Fan Purple = 6600B7
	1412 Color: Pale Mauve = FED0FC
	1417 Color: Strawberry = FB2943
	1419 Color: Raindrop = 33FFCC
	1420 Color: Parchment = FEFCAF
	1421 Color: Robin Egg Blue = 8AF1FE
	1422 Color: Pale Salmon = FFB19A
	1423 Color: Panama Blue = B3BCE2
	1424 Color: Purple Mountain Majesty = 9678B6
	1425 Color: Smitten = C84186
	1428 Color: Vietnamese Mauve = 993366
	1429 Color: Roman Silver = 838996
	1430 Color: Zinnwaldite = EBC2AF
	1431 Color: Off Yellow = F1F33F
	1432 Color: Pinky = FC86AA
	1433 Color: Persian Rose = FE28A2
	1441 Color: Pink Red = F5054F
	1442 Color: Pinkish = D46A7E
	1443 Color: Sandstorm = ECD540
	1444 Color: Yellowish Orange = FFAB0F
	1445 Color: Raspberry Sorbet = CC3A71
	1446 Color: Very Light Blue = D5FFFF
	1447 Color: Rouge Red = E44165
	1448 Color: Rose Pearl = F03865
	1449 Color: Tuscan Tan = A67B5B
	1450 Color: Vulgar Purple = 3E2F84
	1451 Color: Orange Peel = FF9F00
	1452 Color: United Nations Blue = 5B92E5
	1454 Color: Ocher = BF9B0C
	1456 Color: Sandy Brown = C4A661
	1457 Color: Peach Rust = C86D51
	1460 Color: Swamp = 698339
	1462 Color: Tiger's Eye = E08D3C
	1463 Color: Purpley = 8756E4
	1465 Color: Piggy Pink = FDDDE6
	1470 Color: Pea Soup = 929901
	1471 Color: Shit = 7F5F00
	1477 Color: Orchid Mist = C3A6B1
	1478 Color: Sandy = F1DA7A
	1479 Color: Sinopia = CB410B
	1480 Color: Twilight Mauve = 896F73
	1482 Color: Stone = ADA587
	1483 Color: Salmon = FF8C69
	1484 Color: Orangey Brown = B16002
	1485 Color: Pine Green = 0A481E
	1487 Color: Pink Flamingo = FF66FF
	1488 Color: Safety Orange (blaze Orange) = FF6700
	1489 Color: Royal Blue = 0504AA
	1490 Color: Peru = CD853F
	1491 Color: Poison Green = 40FD14
	1492 Color: Patina Light = AFD0CA
	1494 Color: Tomato Red = EC2D01
	1495 Color: Sugar Plum = 914E75
	1496 Color: Spearmint = 1EF876
	1497 Color: Teal Blue = 01889F
	1499 Color: Shamrock = 01B44C
	1503 Color: Weird Green = 3AE57F
	1504 Color: St. Patrick's Blue = 23297A
	1505 Color: Very Pale Blue = D6FFFE
	1506 Color: Yellowish Green = B0DD16
	1508 Color: Nadeshiko Pink = F6ADC6
	1509 Color: Pinkish Tan = D99B82
	1519 Color: Pale Plum = DDA0DD
	1520 Color: Sage = 87AE73
	1521 Color: Pastel Gray = CFCFC4
	1522 Color: Twilight = 4E518B
	1527 Color: Spring Green = 00FF7F
	1530 Color: Rosy Brown = BC8F8F
	1532 Color: Raspberry Red = C51D34
	1541 Color: Zomp = 39A78E
	1543 Color: Periwinkle Blue = 8F99FB
	1544 Color: Rosa = FE86A4
	1545 Color: Russet = 80461B
	1546 Color: Warm Purple = 952E8F
	1547 Color: Red Orange = FD3C06
	1548 Color: Red Purple = 820747
	1550 Color: Onyx = 353839
	1554 Color: Orangered = FE420F
	1555 Color: Unbleached Silk = FFDDCA
	1557 Color: Rifle Green = 414833
	1558 Color: Radical Red = FF355E
	1559 Color: Signal Violet = 924E7D
	1560 Color: Pale Purple = B790D4
	1561 Color: Rose Dust = 9E5E6F
	1562 Color: Poop Green = 6F7C00
	1563 Color: Red (munsell) = F2003C
	1564 Color: Neon Carrot = FF9933
	1565 Color: Pear = D1E231
	1568 Color: Warm Pink = FB5581
	1569 Color: Watusi = FFDDCF
	1570 Color: Rich Carmine = D70040
	1571 Color: Yellow/green = C8FD3D
	1575 Color: Peach Gray = ECD5C5
	1579 Color: Yale Blue = 0F4D92
	1581 Color: Purpley Blue = 5F34E7
	1582 Color: Peru Tan = 7F3A02
	1583 Color: Silver = C0C0C0
	1584 Color: Rust Brown = 8B3103
	1585 Color: Purpleish Blue = 6140EF
	1586 Color: Violine = A10684
	1589 Color: Orangeish = FD8D49
	1593 Color: Purple (munsell) = 9F00C5
	1594 Color: Putty = BEAE8A
	1595 Color: Wild Orchid = D770A2
	
	HashSC #1 with the String key now has:
	1  Color: Neon Yellow = CFFF04 
	2  Color: Yellowish Brown = 9B7A01 
	3  Color: Purplish Pink = CE5DAE --->Color: Yellow Brown = B79400 
	4  Color: Pinkish Orange = FF724C --->Color: Sienna = 882D17 
	6  Color: Scarlet = FF2000 --->Color: Pale Italian Apricot = FFE6E6 
	7  Color: Smokey Topaz = 933D41 --->Color: Rich Magenta = CA1F7B 
	8  Color: Steel Blue = 5A7D9A --->Color: Pale Gold = FDDE6C 
	10  Color: Pear = D1E231 --->Color: Vomit Green = 89A203 --->Color: Warm Taupe = B29784 
	11  Color: Yellow/green = C8FD3D 
	12  Color: Tufts Blue = 417DC1 
	13  Color: Sabria Pink = FC0585 
	14  Color: Soft Purple = A66FB5 --->Color: Paars = AA00FF 
	15  Color: Purple/pink = D725DE --->Color: Wild Watermelon = FC6C85 
	16  Color: Pale Canary Yellow = FFFF99 
	17  Color: Pale Lime Yellow = EAEDA6 
	18  Color: Shadow Lime = D4E29B 
	19  Color: Taupe = 483C32 --->Color: Slate Gray = 708090 --->Color: Ultra Green = 66FF66 
	22  Color: Pink/purple = EF1DE7 
	23  Color: Pigment Green = 00A550 --->Color: Regalia = 522D80 
	27  Color: Thulian Pink = DE6FA1 --->Color: Ultra Blue = A3E3ED 
	28  Color: Tomato Red = EC2D01 
	29  Color: Rich Brilliant Lavender = F1A7FE 
	31  Color: Piggy Pink = FDDDE6 --->Color: Yellow Tan = FFE36E 
	32  Color: Peach Gray = ECD5C5 
	33  Color: Orange Tan = FAA76C --->Color: Rich Raspberry = D72D5C --->Color: Strong Pink = FF0789 
	36  Color: Studio = 714AB2 --->Color: Red-violet = C71585 
	37  Color: Swedish Azure = 005B99 
	38  Color: Popstar = BE4F62 --->Color: Winter Pear = 8A9A5B --->Color: Yellowish Orange = FFAB0F 
	39  Color: Red (pigment) = ED1C24 --->Color: Ultramarine = 120A8F 
	40  Color: Platinum = E5E4E2 
	42  Color: Purple Magic = 693B71 
	44  Color: Off White = FFFFE4 --->Color: Spanish Crimson = E51A4C 
	47  Color: Rosewood = 65000B --->Color: Olive Drab 7 = 3C341F --->Color: Outer Space = 414A4C --->Color: Vivid Strawberry = F70077 --->Color: Wheat = FBDD7E 
	48  Color: Violine = A10684 
	50  Color: Rubine Red = D10056 
	51  Color: Rose Neyron = FF0057 
	52  Color: Pale Orange = FFA756 --->Color: Ua Red = D9004C --->Color: Warm Brown = 964E02 
	53  Color: Vermilion = F34234 
	55  Color: Pale Light French Lavender = D8D0F5 
	56  Color: Reddish Purple = 910951 
	57  Color: Purpleish Pink = DF4EC8 --->Color: Very Light Green = D1FFBD 
	59  Color: Silver Sand = BFC1C2 --->Color: Pansy Purple = 78184A 
	61  Color: Terracota = CB6843 --->Color: Really Light Blue = D4FFFF 
	63  Color: Old Rose = C87F89 
	64  Color: Seance = 731E8F --->Color: Shit = 7F5F00 
	67  Color: Royal = 0C1793 --->Color: Warm Purple = 952E8F 
	68  Color: Pastel Purple = CAA0FF 
	69  Color: Wintergreen = 20F986 
	71  Color: Pinkish = D46A7E --->Color: Pale Turquoise = A5FBD5 
	73  Color: Rich Carmine Red = EB003C 
	74  Color: Old Lavender = 796878 
	77  Color: Process Cyan = 00B7EB --->Color: Very Light Brown = D3B683 
	78  Color: Tenn (tawny) = CD5700 
	79  Color: Sheen Green = 8FD400 
	82  Color: Wine Dregs = 673147 
	86  Color: Prussian Blue = 004577 
	88  Color: Ruby = E0115F 
	90  Color: Purplish Grey = 7A687F --->Color: Vibrant Purple = AD03DE 
	92  Color: Peach Cream = FAD6A5 --->Color: Wisteria = C9A0DC 
	93  Color: Orange (color Wheel) = FF7F00 --->Color: Yellowish Tan = FCFC81 
	95  Color: Pig Pink = E78EA5 --->Color: Persian Pink = F77FBE --->Color: Xanadu = 738678 
	98  Color: Shiraz = B20931 
	99  Color: Orangeish = FD8D49 --->Color: Piss Yellow = DDD618 
	100  Color: Royal Azure = 0038A8 
	101  Color: Signal Violet = 924E7D --->Color: Timberwolf = DBD7D2 --->Color: Radical Red = FF355E 
	103  Color: Sea = 3C9992 --->Color: Warm Black = 004242 
	106  Color: Purply Blue = 661AEE 
	109  Color: Pale Cyan = B7FFFA --->Color: Radiant Orchid = B163A3 
	110  Color: Perrywinkle = 8F8CE7 --->Color: Raspberry Pink = E25098 
	111  Color: Red Pink = FA2A55 --->Color: Orangish Red = F43605 
	113  Color: Purple (munsell) = 9F00C5 
	114  Color: Pale Copper = DA8A67 
	115  Color: Navajo White = FFDEAD 
	116  Color: Sun Yellow = FFDF22 --->Color: Pastel Taupe = AF9E89 --->Color: Purpleish = 98568D 
	118  Color: Ultra Orange = FF6037 
	119  Color: Petrol = 005F6A 
	121  Color: Purplish Red = B0054B --->Color: Sandstone = C9AE74 
	123  Color: Persian Lilac = C17E91 
	124  Color: Pictorial Carmine = C30B4E 
	125  Color: "Tangerine Yellow, Usc Gold" = FFCC00 
	126  Color: Rose Gold = B76E79 
	127  Color: North Texas Green = 059033 --->Color: Washed Out Green = BCF5A6 
	128  Color: Sonic Silver = 757575 
	130  Color: Rocket Metallic = 8A7F8D 
	131  Color: Pale Plum = DDA0DD --->Color: Stone = ADA587 
	134  Color: Reddy Brown = 6E1005 
	135  Color: Ruddy = FF0028 
	136  Color: Neon Fuchsia = FE4164 
	138  Color: Pastel Green = B0FF9D 
	139  Color: Spruce = 0A5F38 
	141  Color: Red (munsell) = F2003C 
	143  Color: Slate Grey = 59656D --->Color: Office Green = 008000 
	144  Color: Shit Green = 758000 
	145  Color: Pale Violet = CEAEFA 
	147  Color: Ocean = 017B92 --->Color: Pale Cerulean = 9BC4E2 --->Color: Yellow = FFFF33 
	148  Color: Nyanza = E9FFDB 
	150  Color: Twilight = 4E518B 
	151  Color: Teal Deer = 99E6B3 --->Color: Poop Green = 6F7C00 
	153  Color: Soft Pink = FDB0C0 --->Color: Skobeloff = 007474 --->Color: Pastel Magenta = F49AC2 --->Color: Wild Strawberry = FF43A4 
	155  Color: Navy Blue = 001146 
	156  Color: Tan = D1B26F --->Color: Red (ryb) = FE2712 
	158  Color: Pastel Brown = 836953 --->Color: Vulgar Purple = 3E2F84 
	159  Color: Seafoam = 80F9AD --->Color: Plum (traditional) = 8E4585 --->Color: Zinnwaldite Brown = 2C1608 
	160  Color: Red-brown = A52A2A --->Color: Rose Ebony = 674846 
	161  Color: Resolution Blue = 002387 
	162  Color: Ugly Blue = 31668A 
	163  Color: Process Magenta = FF0090 --->Color: Nightclub = 660045 
	164  Color: Saddle Brown = 8B4513 --->Color: Shit Brown = 7B5804 
	166  Color: Persian Orange = D99058 
	169  Color: Tropical Rain Forest = 00755E 
	171  Color: Poop Brown = 7A5901 --->Color: Violet (ryb) = 8601AF 
	173  Color: Neon Green = 0CFF0C 
	174  Color: Sapphire Blue = 0067A5 --->Color: Orange (ryb) = FB9902 --->Color: Vivid Electric Blue = 00A5D2 
	175  Color: Razzmatazz = E3256B --->Color: Sugar Plum = 914E75 
	176  Color: Prince Fan Purple = 6600B7 --->Color: Quicksilver = A6A6A6 
	177  Color: Pinky Red = FC2647 
	178  Color: Olive = 6E750E 
	179  Color: Plum = 843179 
	181  Color: Pakistan Green = 006600 
	183  Color: Water Blue = 0E87CC 
	184  Color: Pale Salmon = FFB19A 
	187  Color: Tomato = FF6347 --->Color: Spanish Carmine = D10047 --->Color: Rich Electric Blue = 0892D0 --->Color: Ocean Blue = 03719C 
	190  Color: Peach Puff = FFDAB9 
	193  Color: Pale Chestnut = DDADAF 
	195  Color: Violet Red = A50055 
	196  Color: Pale Amaranth Pink = DDBEC3 --->Color: Toxic Green = 61DE2A 
	198  Color: Pinkish Grey = C8ACA9 --->Color: Olive Drab = 6F7632 
	199  Color: Quartz = 51484F 
	202  Color: Warm Pink = FB5581 
	204  Color: Sunny Lime = E2EE83 --->Color: Soft Green = 6FC276 
	205  Color: Navy = 01153E 
	206  Color: Patina = 639A8F 
	207  Color: Waterspout = A4F4F9 --->Color: White Smoke = F5F5F5 
	208  Color: Snot Green = 9DC100 
	209  Color: Peach-yellow = FADFAD 
	210  Color: Pure Blue = 0203E2 --->Color: Turquoise = 06C2AC 
	214  Color: Striking Purple = 98508E 
	216  Color: True Green = 089404 
	217  Color: Sea Green = 20B2AA --->Color: Purple Blue = 632DE9 --->Color: Pale Pink = FFCFDC 
	220  Color: Pink Sherbet = F78FA7 
	223  Color: Seafoam Blue = 78D1B6 --->Color: Ruby Red = 9B111E 
	224  Color: Rosy Pink = F6688E 
	226  Color: Orange-red = FF4500 
	227  Color: Peacock Blue = 016795 --->Color: Tangerine = FF9408 
	228  Color: Pistachio = 93C572 --->Color: Venetian Red = C80815 
	229  Color: Pigment Blue = 333399 
	230  Color: Rich Blue = 021BF9 
	231  Color: Vivid Purple = 9900FA 
	232  Color: Sap Green = 5C8B15 --->Color: Rich Mauve = E285FF --->Color: Very Light Blue = D5FFFF 
	235  Color: Pale Lime Green = B1FF65 --->Color: Violet Pink = FB5FFC 
	236  Color: Sky Blue = 75BBFD --->Color: New Silver = BFB8A5 --->Color: Veronica = A020F0 
	238  Color: Straw = E4D96F --->Color: Persian Rose = FE28A2 
	240  Color: Night Shadz = AA375A --->Color: Plaza Taupe = A79E8B 
	241  Color: Sand Yellow = FCE166 --->Color: Old Lace = FDF5E6 --->Color: Taupe Brown = 674C47 
	243  Color: Purplish = 94568C 
	244  Color: Pastel Blue = A2BFFE --->Color: Unbleached Silk = FFDDCA 
	245  Color: Rose Taupe = 905D5D 
	247  Color: Zydeco = 02402C 
	248  Color: Vivid Green = 2FEF10 
	249  Color: Peach Bisque = A87C6D 
	250  Color: Raspberry = B00149 --->Color: Twilight Mauve = 896F73 
	251  Color: Pink Pearl = E7ACCF 
	253  Color: Sandstorm = ECD540 --->Color: Raspberry Rose = B3446C --->Color: Queen Pink = E8CC07 --->Color: Vivid Cerise = DA1D81 
	254  Color: St. Patrick's Blue = 23297A 
	255  Color: Wine Red = 7B0323 
	256  Color: Olivine = 9AB973 
	257  Color: Polished Pine = 5DA493 
	258  Color: Zomp = 39A78E 
	259  Color: Pine = 2B5D34 
	260  Color: Portland Orange = FF5A36 
	261  Color: University Of California Gold = B78727 
	262  Color: Toupe = C7AC7D 
	263  Color: Orangey Brown = B16002 
	265  Color: Pink = FF81C0 --->Color: Vivid Burgundy = 9F1D35 
	267  Color: Tea = 65AB7C --->Color: Twilight Lavender = 8A496B 
	271  Color: Purple Wine = 8E3975 
	274  Color: Sickly Yellow = D0E429 --->Color: Traffic Purple = A03472 
	276  Color: Scuba Blue = D0B2CA --->Color: Night Blue = 040348 
	278  Color: Stormcloud = 4F666A --->Color: Ugly Green = 7A9703 
	279  Color: Spearmint = 1EF876 --->Color: Tiger's Eye = E08D3C 
	281  Color: Rose Bonbon = F9429E --->Color: Outrageous Orange = FF6E4A 
	283  Color: Vivid Auburn = 922724 
	284  Color: Yellow Orange = FFAE42 
	287  Color: Royal Heath = AB3472 
	289  Color: Warm Grey = 978A84 
	290  Color: Supernova Light = FFE816 
	292  Color: Tealish = 24BCA8 --->Color: Puce = CC8899 --->Color: Ultramarine Blue = 1805DB --->Color: Usumbara Chameleon Harlequin = 50B708 --->Color: Yellow (ncs) = FFD300 
	293  Color: Navy Green = 35530A 
	294  Color: Orange = F97306 --->Color: Rainshower = EDFEFF 
	297  Color: Neon Carrot = FF9933 
	298  Color: Ugly Brown = 7D7103 --->Color: Weird Green = 3AE57F 
	300  Color: Neon Pink = FE019A 
	301  Color: Yale Blue = 0F4D92 
	302  Color: Purpley Blue = 5F34E7 --->Color: Yellow Ochre = CB9D06 
	303  Color: Teal Green = 25A36F --->Color: Sea Blue = 047495 
	304  Color: Pale Grey = FDFDFE 
	305  Color: Ugly Purple = A442A0 
	307  Color: Raindrop = 33FFCC 
	308  Color: Pale Lilac = E4CBFF 
	310  Color: Sinopia = CB410B --->Color: Nice Blue = 107AB0 --->Color: Pea Green = 8EAB12 
	311  Color: Sky Magenta = CF71AF --->Color: Red Orange = FD3C06 
	312  Color: Violet Eggplant = 991199 
	313  Color: Sky = 82CAFC --->Color: Zinnwaldite = EBC2AF 
	314  Color: Rich Pink-orange = ED999C 
	315  Color: Swamp = 698339 --->Color: Sandy = F1DA7A 
	319  Color: Rich Black = 004040 
	325  Color: Thistle = D8BFD8 
	327  Color: Utah Crimson = D3003F 
	330  Color: Neon Red = FF073A --->Color: Yaffle Green = CECF72 
	331  Color: Very Pale Blue = D6FFFE 
	334  Color: Ruddy Pink = E18E96 --->Color: Palatinate Blue = 273BE2 --->Color: Windsor Tan = AE6838 
	335  Color: Rose Pink = F7879A --->Color: Phthalo Green = 123524 --->Color: Velvet = 750851 --->Color: Wild Lime = CBD862 
	340  Color: Onyx = 353839 --->Color: Orangered = FE420F 
	341  Color: Pear Sorbet = F4EED7 
	342  Color: Ube = 8878C3 
	343  Color: Pale Green-yellow = F1E788 
	345  Color: Steel Pink = CC33CC 
	346  Color: Purple Taupe = 50404D 
	347  Color: Powder Blue = B1D1FC --->Color: Pinkish Purple = D648D7 
	354  Color: Victoria Plum = 002C39 
	355  Color: Royal Maroon = 5A3839 
	356  Color: Peach-orange = FFCC99 
	357  Color: Pearl Violet = 8683A1 --->Color: Old Burgundy = 43302E 
	358  Color: Pale Spring Bud = ECEBBD --->Color: Taupe Gray = 8B8589 
	359  Color: Orange Peel = FF9F00 
	360  Color: Red Brown = 8B2E16 --->Color: Ochre = CC7722 --->Color: Pale Rose = FDC1C5 --->Color: Pale Olive Green = B1D27B 
	364  Color: Ultra Pink = FF6FFF 
	365  Color: Vermillion = F4320C 
	366  Color: Pinky = FC86AA --->Color: Vivid Orchid = CC00FF 
	367  Color: Pale Teal = 82CBB2 
	368  Color: Pink Lace = FFDDF4 --->Color: Shocking Pink = FE02A2 --->Color: Usafa Blue = 004F98 
	369  Color: Pinky Purple = C94CBE 
	371  Color: Sirocco ) = 718080 
	372  Color: Pale Cornflower Blue = ABCDEF --->Color: Very Dark Blue = 000133 --->Color: Vibrant Green = 0ADD08 
	373  Color: Pigment Violet = 9400D3 
	374  Color: Tropical Green = 008B87 
	375  Color: Pastel Yellow = FFFE71 
	378  Color: Orange Brown = BE6400 --->Color: Vivid Blue = 152EFF 
	379  Color: Violet (color Wheel) = 7F00FF 
	380  Color: Rifle Green = 414833 
	381  Color: Teal Blue = 01889F 
	382  Color: Ua Blue = 0033AA 
	384  Color: Online Lime = 4B8740 
	385  Color: Pale Blue-green = 00DDDD --->Color: Pixie Green = C0D8B6 
	386  Color: Rosy Brown Light = E2CACA --->Color: Persian Indigo = 32127A 
	387  Color: Slate = 516572 --->Color: Rouge = AB1239 --->Color: Racing Green = 014600 --->Color: Violet = 8F00FF 
	388  Color: Sepia = 985E2B --->Color: Purple Brown = 673A3F 
	390  Color: Peach Beige = C09396 
	392  Color: Sand Brown = CBA560 
	394  Color: Pale Aqua = B8FFEB --->Color: Poo Brown = 885F01 
	395  Color: Pale Purple = B790D4 
	402  Color: Powder Blue (web) = B0E0E6 --->Color: Off Green = 6BA353 
	404  Color: Rosa = FE86A4 
	406  Color: Verdigris = 43B3AE 
	408  Color: Rose = FF007F --->Color: Sunglow = FFCC33 --->Color: Pea = A4BF20 
	410  Color: Tea Rose = F4C2C2 
	413  Color: Tangelo = F94D00 
	414  Color: Peach Rust = C86D51 --->Color: Tuscan Red = 7C4848 
	415  Color: Sacramento State Green = 00563F --->Color: Teal = 008080 --->Color: Ucla Blue = 536895 
	416  Color: Plum Purple = 4E0550 
	417  Color: Saffron = F4C430 
	418  Color: Pearl = EAE0C8 
	420  Color: Pastel Red = DB5856 
	424  Color: Wintergreen Dream = 56887D 
	426  Color: Titanium Yellow = EEE600 --->Color: Salmon = FF8C69 --->Color: Rich Maroon = B03060 
	430  Color: Unmellow Yellow = FFFF66 
	431  Color: Telemagenta = D72D6D --->Color: Sandy Yellow = FDEE73 
	432  Color: Steel Grey = 6F828A --->Color: Rich Orange = FF681F 
	433  Color: Sage = 87AE73 --->Color: Very Light Purple = F6CEFC 
	436  Color: Space Cadet = 1D2951 --->Color: Sick Green = 9DB92C 
	437  Color: Rose Dust = 9E5E6F --->Color: Snot = ACBB0D --->Color: Princeton Orange = FF8F00 
	438  Color: Violent Violet = 290C5E 
	440  Color: Snow = FFFAFA 
	441  Color: Rose Quartz = AA98A9 
	442  Color: Orangey Yellow = FDB915 
	443  Color: Purply Pink = F075E6 --->Color: Vivid Tangerine = FF9980 
	446  Color: Safety Orange (blaze Orange) = FF6700 --->Color: Periwinkle = 8E82FE 
	447  Color: Persian Green = 00A693 --->Color: Pacific Blue = 1CA9C9 
	449  Color: Urobilin = E1AD21 
	451  Color: Raw Umber = A75E09 
	452  Color: Very Dark Purple = 2A0134 
	453  Color: Peach Sand = C1B6B3 --->Color: Squash = F2AB15 
	455  Color: Tan Green = A9BE70 
	456  Color: Primary Blue = 0804F9 --->Color: Vibrant Blue = 0339F8 
	457  Color: Seafoam Green = 7AF9AB 
	459  Color: Peridot = E6E200 
	461  Color: Rosebloom = E38FB7 
	462  Color: Persian Red = CC3333 
	463  Color: Purplish Blue = 601EF9 --->Color: Reddish Brown = 7F2B0A --->Color: Yellowgreen = BBF90F 
	468  Color: Purple Plum = 9C5186 
	471  Color: Putty = BEAE8A --->Color: Up Maroon = 7B1113 
	472  Color: Silver Pink = C4AEAD 
	473  Color: Raspberry Sorbet = CC3A71 --->Color: Stormy Blue = 507B9C --->Color: Upsdell Red = AE2029 
	475  Color: Purple/blue = 5D21D0 --->Color: Tan Brown = AB7E4C 
	476  Color: Yellowy Green = BFF128 
	477  Color: Peachy Pink = FF9A8A --->Color: Razzle Dazzle Rose = FF33CC --->Color: Vietnamese Mauve = 993366 
	479  Color: Pale = FFF9D0 
	480  Color: Spanish Fuchsia = E30052 --->Color: White = FFFFFF 
	481  Color: Rusty Red = AF2F0D 
	482  Color: Rose White Light = FFFBFB --->Color: Sunny Orange = FC5110 --->Color: Ocean Boat Blue = 0077BE --->Color: Vanda = 9842E3 
	486  Color: New York Pink = D7837F 
	488  Color: Poop = 7F5E00 
	490  Color: Peach Red = F99379 
	491  Color: Purple Rain = 4B308D --->Color: Neon Purple = BC13FE --->Color: Pale Blush = F4BBCF 
	493  Color: Strong Blue = 0C06F7 --->Color: Silver Chalice = ACACAC 
	495  Color: Pink Purple = DB4BDA --->Color: Steel Teal = 5F8A8B 
	496  Color: Orange Pink = FF6F52 --->Color: Yellowy Brown = AE8B0C 
	497  Color: Pullman Brown = 644117 
	498  Color: Pale Sky Blue = BDF6FE --->Color: Sangria = 92000A 
	499  Color: Ugly Pink = CD7584 
	500  Color: Pigment Indigo = 4B0082 
	503  Color: Orange (web Color) = FFA500 
	508  Color: Old Gold = CFB53B 
	509  Color: Ruddy Brown = BB6528 
	510  Color: Reddish Orange = F8481C 
	512  Color: Pale Robin Egg Blue = 96DED1 
	515  Color: Water = 96ABA5 
	516  Color: Slate Blue = 5B7C99 --->Color: Orchid Pink = F2BDCD 
	517  Color: Purpleish Blue = 6140EF --->Color: Purple Reign = 54446C 
	518  Color: Radioactive Green = 2CFA1F 
	519  Color: Orangish = FC824A 
	520  Color: Royal Blue = 0504AA 
	522  Color: Pastel Orange = FF964F --->Color: Selective Yellow = FFBA00 
	527  Color: Simply Taupe = ABA092 
	531  Color: Rust Orange = C45508 
	535  Color: Pale Silver = C9C0BB 
	536  Color: Toolbox = 746CC0 
	537  Color: Pinkish Brown = B17261 
	539  Color: Pink Flamingo = FF66FF 
	540  Color: Puke = A5A502 --->Color: Pale Peach = FFE5AD --->Color: Peru = CD853F 
	542  Color: Reddish Pink = FE2C54 
	543  Color: Ucla Gold = FFB300 
	544  Color: Pinkish Red = F10C45 --->Color: Pastel Gray = CFCFC4 --->Color: Process Yellow = FFEF00 
	545  Color: Pale Goldenrod = EEE8AA 
	548  Color: Purple Orchid = AE4F93 --->Color: Sickly Green = 94B21C --->Color: Rajah = FBAB60 
	549  Color: Raspberry Red = C51D34 
	550  Color: Purplish Brown = 6B4247 
	552  Color: Salmon Pink = FE7B7C --->Color: Papaya Whip = FFEFD5 --->Color: Rouge Light = D58EB5 
	553  Color: Nadeshiko Pink = F6ADC6 
	554  Color: Raspberry Radiance = 82305A --->Color: Purple Pink = E03FD8 
	555  Color: Rich Lavender = A76BCF --->Color: Persian Blue = 1C39BB 
	558  Color: Sandy Taupe = 967117 --->Color: Pink Light = FFE4E9 --->Color: Rufous = A81C07 
	559  Color: Rich Periwinkle = 9999FF 
	560  Color: Violet-blue = 324AB2 --->Color: Viridian = 1E9167 
	563  Color: Reddish = C44240 
	564  Color: Rich Tyrian Purple = 9E0E40 
	565  Color: Safety Orange = FF6600 --->Color: Rosso Corsa = D40000 
	566  Color: Purple Mountain Majesty = 9678B6 --->Color: Pale Lime = BEFD73 --->Color: Pearl Aqua = 88D8C0 
	567  Color: Tree Green = 2A7E19 
	568  Color: Ocean Green = 3D9973 --->Color: Very Dark Green = 062E03 
	569  Color: Very Light Pink = FFF4F2 
	570  Color: Pale Red = D9544D 
	571  Color: Orchid Mist = C3A6B1 
	572  Color: Starship = ECF245 --->Color: Robin's Egg Blue = 98EFF9 
	573  Color: Shamrock = 01B44C --->Color: Off Blue = 5684AE 
	579  Color: Very Pale Green = CFFDBC 
	580  Color: Seaweed = 18D17B --->Color: Yellow-green = 9ACD32 
	581  Color: Pastel Pink = FFBACD --->Color: Padua = ADE6C4 
	585  Color: Star Command Blue = 007BBB 
	586  Color: Pea Soup = 929901 
	587  Color: Olive Yellow = C2B709 --->Color: Rose Red = BE013C --->Color: Turkish Rose = B57281 
	588  Color: Very Dark Brown = 1D0200 
	589  Color: Pansy = 7700FF --->Color: Sapphire = 2138AB --->Color: Wild Blue Yonder = A2ADD0 
	591  Color: Puke Yellow = C2BE0E --->Color: Selago = F0EEFD 
	592  Color: Topaz = 13BBAF 
	594  Color: Royal Blue (web) = 4169E1 --->Color: Old Silver = 848482 
	596  Color: Paradise Pink = E63E62 --->Color: Yellow (ryb) = FEFE33 
	597  Color: Panama Blue = B3BCE2 --->Color: Olive Green = 677A04 
	599  Color: Shadow = 8A795D --->Color: Roman Silver = 838996 
	600  Color: Red-violet Eggplant = 990066 --->Color: Sandy Brown = C4A661 
	601  Color: Watermelon = FD4659 
	602  Color: Violet-red = F7468A 
	604  Color: True Blue = 0073CF 
	606  Color: Pale Rose Light = FFF3FA --->Color: Spiro Disco Ball = 0FC0FC 
	607  Color: Patina Light = AFD0CA --->Color: Turquoise Blue = 06B1C4 
	610  Color: Steel = 738595 --->Color: Pale Taupe = BC987E --->Color: Rust = B7410E 
	612  Color: Tealish Green = 0CDC73 --->Color: Ugly Yellow = D0C101 
	613  Color: Soft Blue = 6488EA 
	615  Color: Pastel Violet = A47D90 
	616  Color: Pale Mauve = FED0FC --->Color: Orange Red = FD411E 
	617  Color: Olive Brown = 645403 
	618  Color: Rich Carmine = D70040 
	622  Color: Purpley = 8756E4 
	624  Color: Raspberry Wine = B63157 --->Color: Vomit Yellow = C7C10C 
	625  Color: Red Wine = 8C0034 
	626  Color: Orangey Red = FA4224 --->Color: United Nations Blue = 5B92E5 
	627  Color: Non-photo Blue = A4DDED 
	628  Color: Tuscan Tan = A67B5B 
	629  Color: Rose Violet = C24C92 --->Color: Reddish Grey = 997570 --->Color: Vivid Plum = 9400A5 
	632  Color: Peach Schnapps = FFDCD6 --->Color: Pale Green = C7FDB5 
	633  Color: Terracotta = CA6641 --->Color: Nasty Green = 70B23F 
	636  Color: Pine Green = 0A481E 
	637  Color: Purple = 800080 --->Color: Rosy Brown = BC8F8F 
	638  Color: Screamin' Green = 76FF7A 
	639  Color: Purpley Pink = C83CB9 --->Color: Sunflower Yellow = FFDA03 
	641  Color: Purple Grey = 866F85 
	642  Color: Palatinate Purple = 682860 
	643  Color: Smitten = C84186 --->Color: Sunshine Yellow = FFFD37 --->Color: Rouge Red = E44165 
	644  Color: Rose Pearl = F03865 --->Color: "Persian Plum, Prune" = 701C1C --->Color: Windows Blue = 3778BF 
	646  Color: Opera Mauve = CA82AF 
	647  Color: Pale Violet Red = DB7093 --->Color: Rosebud Cherry = 892D52 
	649  Color: Red (ncs) = C40233 --->Color: Sand = C2B280 
	652  Color: Pale Brown = B1916E 
	653  Color: Supernova = FFC901 
	654  Color: Red Purple = 820747 --->Color: Royal Fuchsia = CA2C92 --->Color: Pharlap = A3807B 
	655  Color: Slime Green = 99CC04 
	657  Color: Purply = 983FB2 
	658  Color: Purple Red = 990147 
	659  Color: Oxford Blue = 002147 
	660  Color: Peach Blossom Pink = EA9399 --->Color: Pink Champagne = F1DDCF --->Color: Russet = 80461B 
	662  Color: Warm Blue = 4B57DB 
	663  Color: Pink Red = F5054F --->Color: Wistful Mauve = 976F7B 
	664  Color: Raw Sienna = 9A6200 
	665  Color: Rust Brown = 8B3103 
	670  Color: Pastel Lavender = E0B0FF --->Color: Poison Green = 40FD14 --->Color: Perfume = D0BEF8 
	671  Color: Yellow (munsell) = EFCC00 
	676  Color: Slate Green = 658D6D 
	677  Color: Pontiff = AF00FF --->Color: Pale Blue = D0FEFE --->Color: Shamrock Green = 02C14D 
	678  Color: Pea Soup Green = 94A617 
	680  Color: Unicorn = 9F91CF 
	682  Color: Taos Taupe = BFAA80 
	684  Color: Powder Pink = FFB2D0 
	685  Color: Tea Green = BDF8A3 --->Color: Sunny Yellow = FFF917 
	688  Color: Pale Magenta = D767AD --->Color: Robin's Egg = 6DEDFD --->Color: Tuscany = C09999 
	689  Color: Smoky Black = 100C08 
	690  Color: Spring Green = 00FF7F 
	691  Color: Pearly Purple = B768A2 --->Color: Ocre = C69C04 
	695  Color: Rich Spring Green = 00E39A --->Color: Violet Blue = 510AC9 
	701  Color: Orange Yellow = FFAD01 
	702  Color: Pale Yellow = FFFF84 
	703  Color: Spring Bud = A7FC00 
	704  Color: Royal Purple = 4B006E --->Color: Peach Tan = B4745E 
	705  Color: Satin Sheen Gold = CBA135 --->Color: Tokyo Purple = 5A004A 
	706  Color: Rose White = FFF6F5 
	707  Color: Seaweed Green = 35AD6B 
	713  Color: Queen Blue = 436B95 
	717  Color: Old Pink = C77986 
	720  Color: Orangish Brown = B25F03 
	721  Color: Rich Lilac = B666D2 --->Color: Tyrian Purple = 66023C 
	722  Color: Robin Egg Blue = 8AF1FE 
	723  Color: Torch Red = FD0E35 
	725  Color: Pale Light Green = B1FC99 
	726  Color: Purpley Grey = 947E94 --->Color: Seal Brown = 321414 --->Color: Tiffany Blue = 0ABAB5 
	727  Color: Terra Cotta = C9643B --->Color: Red Devil = 860111 
	732  Color: Prelude = D0C0E5 --->Color: Poo = 8F7303 
	734  Color: Rich Apricot = FAB5F7 --->Color: Persimmon = EC5800 
	735  Color: Vomit = A2A415 
	737  Color: Ukrainian Azure = 42ADDE 
	738  Color: Vivid Carmine Pink = FF5771 
	739  Color: Red = FF0000 --->Color: Strawberry = FB2943 --->Color: Westminster = 5F00FF --->Color: Zaffre = 0014A8 
	740  Color: Red-orange = FF3F34 --->Color: Vintage Indigo = 664D64 
	742  Color: Puke Green = 9AAE07 --->Color: Vegas Gold = C5B358 --->Color: Yellow Mist = FFFFE0 
	744  Color: Sage Green = 88B378 --->Color: Watusi = FFDDCF 
	745  Color: Off Yellow = F1F33F --->Color: Ufo Green = 3CD070 
	746  Color: Psychedelic Purple = DF00FF --->Color: Peach = FFE5B4 
	747  Color: Phthalo Blue = 000F89 --->Color: Purple Pizzazz = FE4EDA 
	748  Color: Turtle Green = 75B84F 
	749  Color: Pale Electric Hollywood Cerise = FFC1E8 
	750  Color: Periwinkle Blue = 8F99FB --->Color: Rabbit Eye = FF0033 --->Color: Pale Lavender = EECFFE --->Color: Tumbleweed = DEAA88 
	751  Color: Rosewood Light = B00049 
	754  Color: Red Violet = 9E0168 
	758  Color: Pinkish Tan = D99B82 --->Color: Ou Crimson = 990000 
	760  Color: Neon Blue = 04D9FF 
	762  Color: Puke Brown = 947706 
	763  Color: Twilight Blue = 0A437A 
	764  Color: Parchment = FEFCAF --->Color: Pale Persian Lilac = D597AE 
	765  Color: Rich Harlequin = 3AE500 
	766  Color: Seashell = FFF5EE 
	767  Color: Rose Vale = AB4E52 --->Color: Ocher = BF9B0C --->Color: Peru Tan = 7F3A02 
	769  Color: Orchid Ice = DFD2DF --->Color: Pale Olive = B9CC81 --->Color: Violet Purple = 926EAE 
	770  Color: School Bus Yellow = FFD800 --->Color: Pumpkin Orange = FB7D07 
	771  Color: Napier Green = 3B7E00 
	772  Color: Orchid = DA70D6 
	773  Color: Rusty Orange = CD5909 
	774  Color: Wild Orchid = D770A2 
	775  Color: Tickle Me Pink = FC89AC --->Color: Rich Purple = 720058 --->Color: Purple Heart = 69359C --->Color: Swamp Green = 748500 --->Color: Olivetone = 716E10 
	777  Color: Silver = C0C0C0 --->Color: Turquoise Green = 04F489 
	778  Color: Vivid Violet = 9F00FF 
	779  Color: Vivid Lavender = DF73FF --->Color: Wine = 722F37 --->Color: Yellowish Green = B0DD16 
	780  Color: Rust Red = AA2704 --->Color: Yellow Green = C0FB2D 
	784  Color: Pumpkin = FF7518 
	788  Color: Violet Tulle = C693C7 --->Color: Wenge = 645452 
	794  Color: Umber = 635147 
	795  Color: Yellowish = FAEE66 
	
	HashSC #2 with the String key now has:
	0  Color: Teal Green = 25A36F 
	2  Color: Orchid Ice = DFD2DF --->Color: Pigment Blue = 333399 --->Color: Orchid Pink = F2BDCD --->Color: Unmellow Yellow = FFFF66 
	3  Color: Very Dark Brown = 1D0200 --->Color: Wheat = FBDD7E 
	4  Color: Pastel Violet = A47D90 --->Color: Spanish Fuchsia = E30052 
	6  Color: Slate Grey = 59656D 
	10  Color: Rose Pink = F7879A --->Color: Pale Gold = FDDE6C 
	12  Color: Pale Violet = CEAEFA 
	13  Color: Rosebud Cherry = 892D52 
	17  Color: Rich Spring Green = 00E39A 
	19  Color: Prelude = D0C0E5 --->Color: Vivid Blue = 152EFF 
	20  Color: Pigment Indigo = 4B0082 
	21  Color: Rufous = A81C07 --->Color: Olive Brown = 645403 
	22  Color: Purply Blue = 661AEE 
	24  Color: Pure Blue = 0203E2 --->Color: Razzle Dazzle Rose = FF33CC 
	25  Color: Rouge = AB1239 
	28  Color: Navy Green = 35530A 
	29  Color: Persian Blue = 1C39BB 
	32  Color: Rosso Corsa = D40000 
	33  Color: Red Devil = 860111 
	34  Color: Pastel Blue = A2BFFE --->Color: Salmon Pink = FE7B7C 
	35  Color: Ruddy = FF0028 
	36  Color: Purple Orchid = AE4F93 
	38  Color: Very Pale Blue = D6FFFE 
	40  Color: Pea Soup = 929901 
	42  Color: Pastel Taupe = AF9E89 
	46  Color: Vivid Burgundy = 9F1D35 
	47  Color: Puce = CC8899 --->Color: Queen Pink = E8CC07 --->Color: Wenge = 645452 
	48  Color: Vivid Violet = 9F00FF 
	49  Color: Soft Purple = A66FB5 
	50  Color: Rainshower = EDFEFF 
	53  Color: Pea Green = 8EAB12 
	54  Color: Ocean = 017B92 
	55  Color: Purple Rain = 4B308D 
	56  Color: New York Pink = D7837F --->Color: Ucla Blue = 536895 --->Color: Water = 96ABA5 
	60  Color: Tufts Blue = 417DC1 
	61  Color: Yellow Brown = B79400 
	62  Color: Pale Red = D9544D 
	63  Color: Sangria = 92000A 
	65  Color: Tealish Green = 0CDC73 
	66  Color: Skobeloff = 007474 
	67  Color: Teal Deer = 99E6B3 
	68  Color: Purple Red = 990147 --->Color: Watermelon = FD4659 
	69  Color: Poop Green = 6F7C00 
	70  Color: Pastel Lavender = E0B0FF 
	71  Color: Vivid Auburn = 922724 
	72  Color: Neon Yellow = CFFF04 
	73  Color: Purpleish = 98568D 
	74  Color: Old Burgundy = 43302E 
	77  Color: Tea = 65AB7C --->Color: Weird Green = 3AE57F 
	78  Color: Raw Sienna = 9A6200 --->Color: Rajah = FBAB60 
	79  Color: Powder Blue (web) = B0E0E6 --->Color: Vivid Carmine Pink = FF5771 
	80  Color: Pale Canary Yellow = FFFF99 --->Color: Palatinate Purple = 682860 
	81  Color: Selective Yellow = FFBA00 --->Color: Spearmint = 1EF876 --->Color: Ugly Pink = CD7584 
	82  Color: Pastel Red = DB5856 --->Color: Ultra Orange = FF6037 
	85  Color: Nightclub = 660045 
	86  Color: Pale Green-yellow = F1E788 
	87  Color: Rust Orange = C45508 
	89  Color: Pale Cerulean = 9BC4E2 
	90  Color: Violet (color Wheel) = 7F00FF 
	95  Color: Red Purple = 820747 
	96  Color: Orangish = FC824A --->Color: Popstar = BE4F62 --->Color: Sunshine Yellow = FFFD37 
	98  Color: Pumpkin = FF7518 --->Color: Panama Blue = B3BCE2 --->Color: Pale = FFF9D0 
	100  Color: Strong Blue = 0C06F7 
	101  Color: Rose White Light = FFFBFB 
	102  Color: Olive Drab = 6F7632 
	104  Color: Wild Watermelon = FC6C85 
	105  Color: Tomato = FF6347 
	106  Color: Vivid Lavender = DF73FF 
	108  Color: Tiffany Blue = 0ABAB5 
	109  Color: Slate = 516572 
	110  Color: Rich Pink-orange = ED999C --->Color: Persian Orange = D99058 --->Color: Yellow-green = 9ACD32 
	112  Color: Pale Rose Light = FFF3FA --->Color: Scuba Blue = D0B2CA --->Color: Seafoam = 80F9AD 
	113  Color: Silver Chalice = ACACAC --->Color: Nice Blue = 107AB0 
	116  Color: Steel Blue = 5A7D9A 
	117  Color: Ruby = E0115F 
	118  Color: Peridot = E6E200 
	119  Color: Quartz = 51484F 
	121  Color: Terracota = CB6843 
	122  Color: Yellow = FFFF33 
	123  Color: Smoky Black = 100C08 
	125  Color: Violine = A10684 
	128  Color: Pastel Brown = 836953 
	129  Color: Neon Fuchsia = FE4164 --->Color: Nasty Green = 70B23F 
	130  Color: Vermillion = F4320C 
	131  Color: True Blue = 0073CF 
	133  Color: Warm Taupe = B29784 
	134  Color: Old Lavender = 796878 
	136  Color: School Bus Yellow = FFD800 --->Color: Vivid Green = 2FEF10 
	138  Color: Purplish = 94568C --->Color: Plum (traditional) = 8E4585 --->Color: Zydeco = 02402C 
	139  Color: Purple/blue = 5D21D0 
	141  Color: Red-violet Eggplant = 990066 --->Color: Vanda = 9842E3 
	142  Color: Tumbleweed = DEAA88 
	143  Color: Rosebloom = E38FB7 --->Color: Olive Yellow = C2B709 --->Color: Utah Crimson = D3003F 
	145  Color: Orange Red = FD411E 
	146  Color: Red (munsell) = F2003C --->Color: Turquoise = 06C2AC 
	147  Color: Steel Teal = 5F8A8B 
	151  Color: Tropical Green = 008B87 
	153  Color: Radioactive Green = 2CFA1F 
	155  Color: Violet Tulle = C693C7 
	157  Color: Vintage Indigo = 664D64 
	159  Color: Swamp Green = 748500 --->Color: Orangish Brown = B25F03 
	160  Color: Pale Sky Blue = BDF6FE --->Color: Zinnwaldite = EBC2AF 
	161  Color: Yaffle Green = CECF72 
	162  Color: Peach Beige = C09396 --->Color: Velvet = 750851 
	165  Color: Space Cadet = 1D2951 
	166  Color: Yellowish Green = B0DD16 
	167  Color: Peachy Pink = FF9A8A 
	168  Color: Rose Violet = C24C92 
	169  Color: Rich Mauve = E285FF 
	170  Color: Rose Dust = 9E5E6F 
	171  Color: Purple Heart = 69359C --->Color: Very Light Green = D1FFBD 
	172  Color: Sage Green = 88B378 
	174  Color: Pastel Gray = CFCFC4 --->Color: White Smoke = F5F5F5 
	179  Color: Verdigris = 43B3AE 
	180  Color: Pale Robin Egg Blue = 96DED1 --->Color: Pea = A4BF20 --->Color: Rose Gold = B76E79 
	181  Color: Sea Blue = 047495 --->Color: Tenn (tawny) = CD5700 
	183  Color: Rich Raspberry = D72D5C --->Color: Topaz = 13BBAF --->Color: Violet Blue = 510AC9 
	184  Color: Putty = BEAE8A 
	185  Color: Red (ncs) = C40233 --->Color: Ultra Pink = FF6FFF 
	186  Color: Pink Purple = DB4BDA 
	187  Color: Sap Green = 5C8B15 --->Color: Puke Brown = 947706 --->Color: Perrywinkle = 8F8CE7 --->Color: Peach Red = F99379 
	188  Color: Tan Brown = AB7E4C --->Color: Orange (ryb) = FB9902 
	191  Color: Screamin' Green = 76FF7A --->Color: Warm Blue = 4B57DB 
	192  Color: Twilight = 4E518B 
	194  Color: Sickly Yellow = D0E429 --->Color: Rich Brilliant Lavender = F1A7FE --->Color: Yellow Ochre = CB9D06 
	195  Color: Vomit Green = 89A203 
	196  Color: Red Orange = FD3C06 --->Color: Windsor Tan = AE6838 
	199  Color: Tyrian Purple = 66023C --->Color: Wisteria = C9A0DC 
	200  Color: Viridian = 1E9167 
	203  Color: Sapphire Blue = 0067A5 
	204  Color: Pinkish = D46A7E 
	207  Color: Raspberry Red = C51D34 
	208  Color: Rich Magenta = CA1F7B --->Color: Racing Green = 014600 
	212  Color: Purpley = 8756E4 
	217  Color: Neon Red = FF073A --->Color: Westminster = 5F00FF 
	218  Color: Pinkish Brown = B17261 --->Color: Peach-yellow = FADFAD 
	219  Color: Snot = ACBB0D --->Color: Warm Brown = 964E02 
	221  Color: Robin's Egg Blue = 98EFF9 --->Color: Royal Blue (web) = 4169E1 
	222  Color: Snow = FFFAFA --->Color: "Persian Plum, Prune" = 701C1C 
	223  Color: Pale Plum = DDA0DD --->Color: Wild Lime = CBD862 
	224  Color: Yellowish = FAEE66 
	225  Color: Ocre = C69C04 
	226  Color: Royal Fuchsia = CA2C92 --->Color: Sandy Taupe = 967117 
	228  Color: Soft Green = 6FC276 
	229  Color: Piss Yellow = DDD618 
	232  Color: Pale Goldenrod = EEE8AA --->Color: Vivid Strawberry = F70077 
	233  Color: Peru = CD853F 
	234  Color: Rusty Orange = CD5909 
	236  Color: Olive Drab 7 = 3C341F --->Color: Orange Yellow = FFAD01 --->Color: Resolution Blue = 002387 --->Color: Portland Orange = FF5A36 
	237  Color: Plaza Taupe = A79E8B 
	238  Color: Old Lace = FDF5E6 
	239  Color: Pale Electric Hollywood Cerise = FFC1E8 
	240  Color: Pale Chestnut = DDADAF 
	243  Color: Rich Harlequin = 3AE500 --->Color: Night Blue = 040348 --->Color: Wild Blue Yonder = A2ADD0 
	244  Color: Paradise Pink = E63E62 --->Color: Twilight Lavender = 8A496B 
	245  Color: Sand Brown = CBA560 
	246  Color: Patina = 639A8F 
	247  Color: Off White = FFFFE4 
	248  Color: Orangered = FE420F 
	249  Color: Pale Mauve = FED0FC 
	253  Color: Radiant Orchid = B163A3 --->Color: Sirocco ) = 718080 
	254  Color: Taos Taupe = BFAA80 
	255  Color: Ocean Boat Blue = 0077BE 
	256  Color: Purply Pink = F075E6 --->Color: Peacock Blue = 016795 
	258  Color: Poop = 7F5E00 
	261  Color: Persimmon = EC5800 
	263  Color: Persian Pink = F77FBE 
	264  Color: Supernova Light = FFE816 --->Color: Orangey Brown = B16002 
	265  Color: Squash = F2AB15 
	268  Color: Pastel Pink = FFBACD --->Color: Yellowy Brown = AE8B0C 
	270  Color: Pea Soup Green = 94A617 --->Color: Persian Green = 00A693 --->Color: Wild Strawberry = FF43A4 
	272  Color: Phthalo Green = 123524 
	273  Color: Stone = ADA587 
	274  Color: Stormy Blue = 507B9C --->Color: Peru Tan = 7F3A02 
	276  Color: Swedish Azure = 005B99 --->Color: Rosewood = 65000B 
	280  Color: Terracotta = CA6641 
	282  Color: Persian Red = CC3333 
	284  Color: Robin Egg Blue = 8AF1FE --->Color: Sand Yellow = FCE166 
	285  Color: Orange-red = FF4500 --->Color: Yellow Tan = FFE36E --->Color: Yellowish Orange = FFAB0F 
	286  Color: Venetian Red = C80815 
	288  Color: Oxford Blue = 002147 
	289  Color: Red Violet = 9E0168 --->Color: Peach Gray = ECD5C5 --->Color: Pale Green = C7FDB5 --->Color: Sunny Lime = E2EE83 
	290  Color: Purplish Blue = 601EF9 
	291  Color: Russet = 80461B 
	295  Color: Rich Black = 004040 --->Color: Princeton Orange = FF8F00 
	297  Color: Neon Carrot = FF9933 
	298  Color: Pale Violet Red = DB7093 
	300  Color: Rosy Brown = BC8F8F 
	301  Color: Sonic Silver = 757575 
	302  Color: Saddle Brown = 8B4513 --->Color: Sea = 3C9992 
	307  Color: Rich Electric Blue = 0892D0 --->Color: Taupe Gray = 8B8589 
	308  Color: Sky Magenta = CF71AF 
	310  Color: Royal Heath = AB3472 --->Color: Very Light Blue = D5FFFF 
	311  Color: Shiraz = B20931 --->Color: Pastel Yellow = FFFE71 
	312  Color: Sandy Brown = C4A661 
	313  Color: Spring Green = 00FF7F --->Color: Sienna = 882D17 
	314  Color: Peach Sand = C1B6B3 
	316  Color: Off Yellow = F1F33F 
	317  Color: Starship = ECF245 --->Color: Scarlet = FF2000 
	319  Color: Red-orange = FF3F34 --->Color: Pale Yellow = FFFF84 
	320  Color: Rich Purple = 720058 --->Color: Reddish Brown = 7F2B0A 
	321  Color: Paars = AA00FF --->Color: Rose Pearl = F03865 --->Color: Violent Violet = 290C5E 
	322  Color: Torch Red = FD0E35 
	325  Color: Spring Bud = A7FC00 
	326  Color: North Texas Green = 059033 
	327  Color: Purple Plum = 9C5186 --->Color: Rich Carmine Red = EB003C 
	328  Color: Ocher = BF9B0C 
	332  Color: Old Rose = C87F89 
	334  Color: Strong Pink = FF0789 --->Color: Periwinkle = 8E82FE 
	335  Color: Shamrock = 01B44C 
	336  Color: Seashell = FFF5EE 
	341  Color: Psychedelic Purple = DF00FF 
	342  Color: Purple (munsell) = 9F00C5 
	343  Color: Puke = A5A502 
	344  Color: Raspberry Sorbet = CC3A71 
	345  Color: Nadeshiko Pink = F6ADC6 
	349  Color: Ugly Yellow = D0C101 
	350  Color: Pale Rose = FDC1C5 --->Color: Steel Pink = CC33CC 
	353  Color: Titanium Yellow = EEE600 --->Color: Shamrock Green = 02C14D 
	354  Color: Orange Tan = FAA76C 
	355  Color: Peach Rust = C86D51 --->Color: Plum = 843179 
	357  Color: Sea Green = 20B2AA 
	358  Color: Pigment Violet = 9400D3 --->Color: Neon Green = 0CFF0C 
	359  Color: Royal Purple = 4B006E --->Color: Night Shadz = AA375A --->Color: Red (ryb) = FE2712 
	363  Color: Rich Blue = 021BF9 
	365  Color: Wistful Mauve = 976F7B 
	367  Color: Purple Magic = 693B71 
	368  Color: Raspberry Rose = B3446C --->Color: Neon Purple = BC13FE --->Color: Pale Turquoise = A5FBD5 --->Color: Purpley Blue = 5F34E7 
	369  Color: University Of California Gold = B78727 --->Color: Very Dark Blue = 000133 
	370  Color: Salmon = FF8C69 
	371  Color: Sandstone = C9AE74 --->Color: Violet (ryb) = 8601AF 
	372  Color: Papaya Whip = FFEFD5 --->Color: Pacific Blue = 1CA9C9 --->Color: Terra Cotta = C9643B 
	373  Color: Purple/pink = D725DE --->Color: Yellow (ncs) = FFD300 
	374  Color: Tangelo = F94D00 
	376  Color: Purple Taupe = 50404D 
	377  Color: Pale Cyan = B7FFFA 
	378  Color: Tuscany = C09999 
	380  Color: Spiro Disco Ball = 0FC0FC 
	381  Color: Quicksilver = A6A6A6 
	382  Color: Vomit = A2A415 
	385  Color: Sapphire = 2138AB 
	387  Color: Parchment = FEFCAF 
	388  Color: Really Light Blue = D4FFFF 
	389  Color: Slate Green = 658D6D --->Color: Toupe = C7AC7D 
	390  Color: Pale Lime Green = B1FF65 --->Color: Very Light Purple = F6CEFC 
	392  Color: Wine Dregs = 673147 
	393  Color: Pharlap = A3807B 
	394  Color: Puke Yellow = C2BE0E --->Color: Timberwolf = DBD7D2 
	396  Color: Peach Tan = B4745E 
	397  Color: Rose Vale = AB4E52 
	398  Color: Pear = D1E231 
	400  Color: Poop Brown = 7A5901 
	401  Color: Roman Silver = 838996 --->Color: Navy = 01153E 
	402  Color: Pink Sherbet = F78FA7 --->Color: Sepia = 985E2B --->Color: Ufo Green = 3CD070 
	403  Color: Pale Blue = D0FEFE 
	404  Color: Steel Grey = 6F828A --->Color: Orangeish = FD8D49 
	406  Color: Pixie Green = C0D8B6 --->Color: Pale Light Green = B1FC99 
	408  Color: Rabbit Eye = FF0033 
	409  Color: Vivid Cerise = DA1D81 
	410  Color: Rose Taupe = 905D5D --->Color: Pink/purple = EF1DE7 
	412  Color: Red-violet = C71585 
	413  Color: St. Patrick's Blue = 23297A 
	415  Color: Twilight Mauve = 896F73 
	416  Color: Silver Sand = BFC1C2 
	417  Color: Violet Pink = FB5FFC 
	418  Color: Purple = 800080 --->Color: Traffic Purple = A03472 
	419  Color: Onyx = 353839 --->Color: Pale Olive Green = B1D27B --->Color: Unicorn = 9F91CF 
	420  Color: Pale Lime = BEFD73 
	421  Color: Rich Orange = FF681F --->Color: Rose White = FFF6F5 --->Color: Yale Blue = 0F4D92 
	422  Color: Up Maroon = 7B1113 --->Color: Vivid Tangerine = FF9980 
	425  Color: Warm Pink = FB5581 
	426  Color: Pale Aqua = B8FFEB --->Color: Pullman Brown = 644117 
	427  Color: Prussian Blue = 004577 
	428  Color: Pale Light French Lavender = D8D0F5 
	429  Color: Wintergreen Dream = 56887D 
	430  Color: Ruby Red = 9B111E --->Color: Very Pale Green = CFFDBC 
	433  Color: Red (pigment) = ED1C24 --->Color: Online Lime = 4B8740 
	434  Color: Pale Teal = 82CBB2 
	435  Color: Orchid = DA70D6 
	437  Color: Pinkish Purple = D648D7 
	438  Color: Purply = 983FB2 --->Color: Sickly Green = 94B21C --->Color: Powder Blue = B1D1FC 
	439  Color: Old Silver = 848482 --->Color: Ugly Green = 7A9703 
	440  Color: Shadow = 8A795D 
	442  Color: Sage = 87AE73 --->Color: Tealish = 24BCA8 --->Color: Sabria Pink = FC0585 
	443  Color: Orangey Yellow = FDB915 
	444  Color: Xanadu = 738678 
	446  Color: Selago = F0EEFD --->Color: Sick Green = 9DB92C 
	449  Color: Pale Blush = F4BBCF --->Color: Regalia = 522D80 
	451  Color: Seaweed = 18D17B 
	456  Color: Ocean Green = 3D9973 --->Color: Pistachio = 93C572 --->Color: Rosewood Light = B00049 
	457  Color: Perfume = D0BEF8 
	460  Color: Ucla Gold = FFB300 --->Color: Yellow/green = C8FD3D 
	461  Color: Upsdell Red = AE2029 
	462  Color: Purple Brown = 673A3F 
	464  Color: Orchid Mist = C3A6B1 --->Color: Shit Green = 758000 --->Color: Process Yellow = FFEF00 
	466  Color: Purple Mountain Majesty = 9678B6 
	468  Color: Sunny Yellow = FFF917 
	469  Color: Studio = 714AB2 --->Color: Very Dark Green = 062E03 
	471  Color: Seance = 731E8F 
	472  Color: Smitten = C84186 --->Color: Rose Quartz = AA98A9 
	473  Color: Very Dark Purple = 2A0134 
	476  Color: Soft Blue = 6488EA --->Color: Violet Eggplant = 991199 
	478  Color: Rosa = FE86A4 
	479  Color: Warm Grey = 978A84 
	480  Color: Patina Light = AFD0CA 
	481  Color: Polished Pine = 5DA493 --->Color: Rosy Brown Light = E2CACA 
	482  Color: Rose = FF007F 
	483  Color: Purplish Brown = 6B4247 --->Color: Telemagenta = D72D6D 
	485  Color: Periwinkle Blue = 8F99FB --->Color: Silver Pink = C4AEAD 
	486  Color: Yellowgreen = BBF90F 
	487  Color: Olive Green = 677A04 
	488  Color: Pearl = EAE0C8 
	490  Color: Veronica = A020F0 
	493  Color: Olivine = 9AB973 
	494  Color: Pakistan Green = 006600 --->Color: Silver = C0C0C0 --->Color: Tropical Rain Forest = 00755E 
	495  Color: Purple Pizzazz = FE4EDA 
	496  Color: Pale Italian Apricot = FFE6E6 
	497  Color: Yellowish Brown = 9B7A01 
	498  Color: Outer Space = 414A4C --->Color: Safety Orange (blaze Orange) = FF6700 
	499  Color: Pine Green = 0A481E --->Color: Satin Sheen Gold = CBA135 --->Color: Orange Brown = BE6400 --->Color: Shadow Lime = D4E29B 
	500  Color: United Nations Blue = 5B92E5 
	501  Color: Violet Red = A50055 
	502  Color: Very Light Brown = D3B683 
	504  Color: Purple Reign = 54446C --->Color: Royal = 0C1793 
	506  Color: True Green = 089404 
	507  Color: Purple Blue = 632DE9 
	508  Color: Pearly Purple = B768A2 
	510  Color: Pale Lavender = EECFFE --->Color: Rust Brown = 8B3103 
	511  Color: Orange (color Wheel) = FF7F00 --->Color: Process Cyan = 00B7EB --->Color: Tree Green = 2A7E19 
	514  Color: Usafa Blue = 004F98 
	515  Color: Sunny Orange = FC5110 --->Color: Slate Blue = 5B7C99 
	516  Color: Raspberry Radiance = 82305A --->Color: Orangey Red = FA4224 
	517  Color: Sandy = F1DA7A 
	518  Color: Sugar Plum = 914E75 --->Color: Violet Purple = 926EAE 
	519  Color: Purpleish Blue = 6140EF --->Color: Orange = F97306 --->Color: Rich Tyrian Purple = 9E0E40 
	521  Color: Neon Blue = 04D9FF --->Color: Outrageous Orange = FF6E4A 
	523  Color: Royal Azure = 0038A8 --->Color: Pink Flamingo = FF66FF 
	524  Color: Purplish Pink = CE5DAE 
	526  Color: Purplish Red = B0054B --->Color: Turquoise Blue = 06B1C4 --->Color: Tuscan Red = 7C4848 
	527  Color: Rose Bonbon = F9429E --->Color: Sandstorm = ECD540 --->Color: Yellow Green = C0FB2D 
	528  Color: Pinkish Red = F10C45 
	529  Color: Saffron = F4C430 
	530  Color: Piggy Pink = FDDDE6 --->Color: Red = FF0000 
	531  Color: Navy Blue = 001146 
	534  Color: Pale Taupe = BC987E --->Color: Ultra Green = 66FF66 
	536  Color: Rich Carmine = D70040 --->Color: Padua = ADE6C4 
	537  Color: Taupe Brown = 674C47 --->Color: Windows Blue = 3778BF 
	538  Color: Pinkish Orange = FF724C --->Color: Reddish Purple = 910951 --->Color: Rust Red = AA2704 
	539  Color: Peach Schnapps = FFDCD6 
	542  Color: Pictorial Carmine = C30B4E --->Color: Ube = 8878C3 --->Color: Usumbara Chameleon Harlequin = 50B708 
	543  Color: Ultramarine Blue = 1805DB 
	544  Color: Orange Peel = FF9F00 --->Color: Vegas Gold = C5B358 --->Color: Very Light Pink = FFF4F2 
	546  Color: Reddy Brown = 6E1005 --->Color: Thulian Pink = DE6FA1 --->Color: Rose Neyron = FF0057 
	547  Color: Yellow (ryb) = FEFE33 
	548  Color: Opera Mauve = CA82AF --->Color: Sky = 82CAFC 
	549  Color: Simply Taupe = ABA092 
	550  Color: Shit = 7F5F00 
	551  Color: Ocean Blue = 03719C 
	552  Color: Rich Lilac = B666D2 --->Color: Seafoam Blue = 78D1B6 
	554  Color: Rocket Metallic = 8A7F8D --->Color: Zinnwaldite Brown = 2C1608 
	555  Color: Raspberry Wine = B63157 
	558  Color: Ruddy Pink = E18E96 --->Color: Watusi = FFDDCF 
	560  Color: Pansy Purple = 78184A 
	561  Color: Sunflower Yellow = FFDA03 
	563  Color: Orangish Red = F43605 
	564  Color: Poo = 8F7303 
	566  Color: Teal = 008080 --->Color: Tangerine = FF9408 
	567  Color: Rouge Light = D58EB5 --->Color: Pale Salmon = FFB19A 
	569  Color: Pale Spring Bud = ECEBBD --->Color: Wild Orchid = D770A2 
	570  Color: Peach Puff = FFDAB9 
	573  Color: Spanish Crimson = E51A4C 
	575  Color: Tea Green = BDF8A3 
	577  Color: Taupe = 483C32 
	578  Color: Teal Blue = 01889F --->Color: Purplish Grey = 7A687F 
	581  Color: Navajo White = FFDEAD --->Color: Violet-blue = 324AB2 
	586  Color: Radical Red = FF355E 
	588  Color: White = FFFFFF --->Color: Yellow Mist = FFFFE0 
	590  Color: Seafoam Green = 7AF9AB --->Color: Shocking Pink = FE02A2 
	591  Color: Waterspout = A4F4F9 
	594  Color: Pastel Green = B0FF9D --->Color: Rifle Green = 414833 --->Color: Poo Brown = 885F01 
	597  Color: Urobilin = E1AD21 
	599  Color: Stormcloud = 4F666A 
	602  Color: Purpley Pink = C83CB9 
	603  Color: Spruce = 0A5F38 --->Color: Steel = 738595 --->Color: Red-brown = A52A2A 
	604  Color: Non-photo Blue = A4DDED 
	607  Color: Pastel Purple = CAA0FF 
	610  Color: Raindrop = 33FFCC --->Color: Star Command Blue = 007BBB --->Color: Queen Blue = 436B95 
	611  Color: Snot Green = 9DC100 
	612  Color: Pigment Green = 00A550 --->Color: Umber = 635147 --->Color: Violet = 8F00FF 
	613  Color: Persian Lilac = C17E91 
	615  Color: Peach-orange = FFCC99 --->Color: Pale Purple = B790D4 
	619  Color: Old Pink = C77986 --->Color: Tickle Me Pink = FC89AC --->Color: Zomp = 39A78E 
	620  Color: Pale Brown = B1916E --->Color: Reddish Pink = FE2C54 --->Color: Zaffre = 0014A8 
	621  Color: Vulgar Purple = 3E2F84 
	625  Color: Sandy Yellow = FDEE73 
	626  Color: Signal Violet = 924E7D 
	627  Color: Rich Maroon = B03060 --->Color: Pansy = 7700FF --->Color: Vermilion = F34234 
	629  Color: Platinum = E5E4E2 
	632  Color: Peach Cream = FAD6A5 --->Color: Pale Lilac = E4CBFF 
	633  Color: New Silver = BFB8A5 --->Color: Wintergreen = 20F986 
	634  Color: Pinky Purple = C94CBE 
	635  Color: Red Wine = 8C0034 
	636  Color: Pear Sorbet = F4EED7 --->Color: Vivid Plum = 9400A5 
	637  Color: Pale Pink = FFCFDC --->Color: Ultramarine = 120A8F --->Color: Yellow Orange = FFAE42 
	638  Color: Turkish Rose = B57281 
	639  Color: Plum Purple = 4E0550 --->Color: Reddish Orange = F8481C --->Color: Toxic Green = 61DE2A 
	641  Color: Purple Wine = 8E3975 --->Color: Violet-red = F7468A 
	643  Color: Ou Crimson = 990000 --->Color: Ukrainian Azure = 42ADDE 
	644  Color: Ugly Blue = 31668A 
	645  Color: Ugly Purple = A442A0 
	651  Color: Thistle = D8BFD8 --->Color: Vivid Purple = 9900FA 
	652  Color: Royal Blue = 0504AA 
	653  Color: Puke Green = 9AAE07 --->Color: Rich Apricot = FAB5F7 --->Color: Pale Lime Yellow = EAEDA6 
	654  Color: Tan Green = A9BE70 --->Color: Olivetone = 716E10 --->Color: Rose Red = BE013C --->Color: Smokey Topaz = 933D41 
	655  Color: Slate Gray = 708090 --->Color: Raspberry Pink = E25098 
	656  Color: Purpley Grey = 947E94 --->Color: Pink Lace = FFDDF4 --->Color: Pink Red = F5054F 
	658  Color: Vivid Electric Blue = 00A5D2 
	659  Color: Seaweed Green = 35AD6B 
	660  Color: Phthalo Blue = 000F89 --->Color: Safety Orange = FF6600 
	661  Color: Vibrant Blue = 0339F8 
	662  Color: Persian Indigo = 32127A 
	664  Color: Toolbox = 746CC0 --->Color: Vietnamese Mauve = 993366 
	666  Color: Royal Maroon = 5A3839 
	667  Color: Sinopia = CB410B 
	668  Color: Vivid Orchid = CC00FF --->Color: Warm Purple = 952E8F 
	669  Color: Pale Olive = B9CC81 --->Color: Wine = 722F37 
	670  Color: Red Brown = 8B2E16 
	672  Color: Powder Pink = FFB2D0 --->Color: Rosy Pink = F6688E 
	673  Color: "Tangerine Yellow, Usc Gold" = FFCC00 --->Color: Turtle Green = 75B84F 
	674  Color: Tiger's Eye = E08D3C --->Color: Reddish Grey = 997570 
	679  Color: Pinky = FC86AA 
	680  Color: Rich Periwinkle = 9999FF 
	681  Color: Strawberry = FB2943 
	683  Color: Tea Rose = F4C2C2 --->Color: Pale Peach = FFE5AD 
	684  Color: Sunflower = FFC512 
	685  Color: Off Blue = 5684AE --->Color: Palatinate Blue = 273BE2 
	687  Color: Sacramento State Green = 00563F 
	689  Color: Sun Yellow = FFDF22 
	691  Color: Ruddy Brown = BB6528 --->Color: Pale Silver = C9C0BB --->Color: Rouge Red = E44165 --->Color: Pale Grey = FDFDFE 
	696  Color: Peach Bisque = A87C6D 
	699  Color: Pink Light = FFE4E9 --->Color: Winter Pear = 8A9A5B 
	700  Color: Sand = C2B280 
	702  Color: Poison Green = 40FD14 --->Color: Pig Pink = E78EA5 
	703  Color: Pale Magenta = D767AD 
	704  Color: Process Magenta = FF0090 --->Color: Vibrant Purple = AD03DE 
	705  Color: Pink Pearl = E7ACCF 
	708  Color: Pastel Orange = FF964F 
	710  Color: Soft Pink = FDB0C0 
	712  Color: Razzmatazz = E3256B --->Color: Olive = 6E750E 
	714  Color: Unbleached Silk = FFDDCA 
	716  Color: Pale Orange = FFA756 
	718  Color: Prince Fan Purple = 6600B7 --->Color: Ua Red = D9004C --->Color: Vibrant Green = 0ADD08 
	720  Color: Rich Lavender = A76BCF --->Color: Rose Ebony = 674846 
	722  Color: Petrol = 005F6A 
	725  Color: Pearl Aqua = 88D8C0 --->Color: Sunglow = FFCC33 
	726  Color: Peach = FFE5B4 
	728  Color: Pinkish Grey = C8ACA9 --->Color: Yellow (munsell) = EFCC00 
	729  Color: Supernova = FFC901 --->Color: Straw = E4D96F --->Color: Vomit Yellow = C7C10C 
	731  Color: Pale Persian Lilac = D597AE 
	732  Color: Tomato Red = EC2D01 
	734  Color: Yellowy Green = BFF128 
	735  Color: Red Pink = FA2A55 --->Color: Tuscan Tan = A67B5B 
	737  Color: Pinkish Tan = D99B82 --->Color: Yellowish Tan = FCFC81 
	738  Color: Swamp = 698339 
	739  Color: Tan = D1B26F 
	740  Color: Pastel Magenta = F49AC2 
	741  Color: Purple Pink = E03FD8 --->Color: Seal Brown = 321414 --->Color: Rust = B7410E 
	742  Color: Victoria Plum = 002C39 
	745  Color: Pale Amaranth Pink = DDBEC3 
	748  Color: Raw Umber = A75E09 --->Color: Ultra Blue = A3E3ED 
	750  Color: Striking Purple = 98508E --->Color: Pale Blue-green = 00DDDD 
	751  Color: Office Green = 008000 
	752  Color: Pale Copper = DA8A67 
	753  Color: Nyanza = E9FFDB --->Color: Purpleish Pink = DF4EC8 --->Color: Water Blue = 0E87CC 
	754  Color: Robin's Egg = 6DEDFD --->Color: Wine Red = 7B0323 
	755  Color: Neon Pink = FE019A 
	760  Color: Tokyo Purple = 5A004A --->Color: Twilight Blue = 0A437A 
	763  Color: Pine = 2B5D34 
	764  Color: Pontiff = AF00FF 
	768  Color: Pink Champagne = F1DDCF 
	769  Color: Pink = FF81C0 --->Color: Napier Green = 3B7E00 
	770  Color: Rusty Red = AF2F0D --->Color: Ugly Brown = 7D7103 
	771  Color: Warm Black = 004242 
	773  Color: Orange Pink = FF6F52 --->Color: Persian Rose = FE28A2 --->Color: Peach Blossom Pink = EA9399 
	776  Color: Sheen Green = 8FD400 
	779  Color: Primary Blue = 0804F9 
	780  Color: Pinky Red = FC2647 
	781  Color: Raspberry = B00149 
	786  Color: Ua Blue = 0033AA 
	787  Color: Spanish Carmine = D10047 --->Color: Pearl Violet = 8683A1 
	788  Color: Pumpkin Orange = FB7D07 --->Color: Reddish = C44240 --->Color: Off Green = 6BA353 
	789  Color: Old Gold = CFB53B --->Color: Washed Out Green = BCF5A6 
	790  Color: Pale Cornflower Blue = ABCDEF 
	792  Color: Orange (web Color) = FFA500 
	795  Color: Purple Grey = 866F85 --->Color: Rubine Red = D10056 --->Color: Slime Green = 99CC04 --->Color: Shit Brown = 7B5804 
	796  Color: Ochre = CC7722 --->Color: Sky Blue = 75BBFD --->Color: Turquoise Green = 04F489 
 */

