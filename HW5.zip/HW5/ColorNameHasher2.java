class ColorNameHasher2 implements Hasher<Color>
{

	/** 
	 * Hashes the Color by its name using radix 37.
     * @param  elem  holds a Color parameter.
     * @return an integer that is the hash value of the name of the Color parameter, but hashed with radix 37.
     */
	@Override
	public int hash(Color elem) {
		
		String name = elem.getName();//name->holds the name of the color. 
		int hashValue = 0;;//hashValue->holds the hash value of the name.
	
		for(int i = 0; i < name.length(); i++)
		{
			hashValue = (hashValue * 37) + name.charAt(i);
		}
	 	
		return hashValue;
	}
}
