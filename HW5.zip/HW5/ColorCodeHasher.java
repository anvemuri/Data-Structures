class ColorCodeHasher implements Hasher<Color>
{
	/** 
	 * Returns the code of the parameter.
     * @param  elem  holds a Color.
     * @return an integer that is the code of the Color parameter.
     */
	@Override
	public int hash(Color elem) {
		
		return elem.getCode(); 
	}
	
}